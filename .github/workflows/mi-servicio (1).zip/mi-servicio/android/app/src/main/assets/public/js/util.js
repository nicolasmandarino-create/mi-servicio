/* Mi Servicio – utilidades */
(function (MS) {
  'use strict';

  MS.$ = function (sel, root) { return (root || document).querySelector(sel); };
  MS.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  function append(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { append(el, x); }); }
    else if (c instanceof Node) el.appendChild(c);
    else el.appendChild(document.createTextNode(String(c)));
  }

  /** Crea un elemento: h('div', {class:'x', onclick: fn, dataset:{a:1}}, ...hijos) */
  MS.h = function (tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v == null || v === false) return;
        if (k === 'class') el.className = v;
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'text') el.textContent = v;
        else if (k === 'dataset') Object.assign(el.dataset, v);
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (v === true) el.setAttribute(k, '');
        else el.setAttribute(k, v);
      });
    }
    for (var i = 2; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  };

  MS.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  MS.uid = function () {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  };

  MS.clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };

  MS.debounce = function (fn, ms) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, ms);
    };
  };

  /** Texto sin tildes y en minúsculas, para buscar. */
  MS.norm = function (s) {
    return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  };

  MS.formatBytes = function (n) {
    if (!n || n < 1024) return (n || 0) + ' B';
    if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(n < 10485760 ? 1 : 0).replace('.', ',') + ' MB';
    return (n / 1073741824).toFixed(2).replace('.', ',') + ' GB';
  };

  /* ---------- Fechas (siempre en hora local, formato AAAA-MM-DD) ---------- */
  var DIAS = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
  var MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  MS.todayISO = function () {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  };
  MS.parseISO = function (s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || '');
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  };
  /** "mar 24 nov 2026" */
  MS.formatDate = function (s) {
    var d = MS.parseISO(s);
    if (!d) return '';
    return DIAS[d.getDay()] + ' ' + d.getDate() + ' ' + MESES[d.getMonth()] + ' ' + d.getFullYear();
  };
  /** "24 nov 2026" */
  MS.formatDateShort = function (s) {
    var d = MS.parseISO(s);
    if (!d) return '';
    return d.getDate() + ' ' + MESES[d.getMonth()] + ' ' + d.getFullYear();
  };
  MS.relativeDate = function (s) {
    var d = MS.parseISO(s);
    if (!d) return '';
    var t = MS.parseISO(MS.todayISO());
    var days = Math.round((t - d) / 86400000);
    if (days === 0) return 'Hoy';
    if (days === 1) return 'Ayer';
    if (days === -1) return 'Mañana';
    if (days < 0) return 'En ' + (-days) + ' días';
    if (days < 30) return 'Hace ' + days + ' días';
    if (days < 365) { var m = Math.round(days / 30); return 'Hace ' + m + (m === 1 ? ' mes' : ' meses'); }
    var a = Math.floor(days / 365);
    return 'Hace ' + a + (a === 1 ? ' año' : ' años');
  };

  MS.formatCoords = function (lat, lng) {
    return lat.toFixed(5) + ', ' + lng.toFixed(5);
  };

  /* ---------- Plataforma ---------- */
  MS.isNative = function () {
    var c = window.Capacitor;
    return !!(c && typeof c.isNativePlatform === 'function' && c.isNativePlatform());
  };
  /** iPhone/iPad (incluye iPadOS, que se presenta como Mac con pantalla táctil). */
  MS.isIOS = function () {
    var ua = navigator.userAgent || '';
    return /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && (navigator.maxTouchPoints || 0) > 1);
  };
  /** true cuando la web se abrió desde el ícono de la pantalla de inicio (modo aplicación). */
  MS.isStandalone = function () {
    return !!(navigator.standalone || (window.matchMedia && matchMedia('(display-mode: standalone)').matches));
  };
  var pluginCache = {};
  MS.plugin = function (name) {
    var c = window.Capacitor;
    if (!c) return null;
    if (pluginCache[name]) return pluginCache[name];
    try {
      var p = (c.Plugins && c.Plugins[name]) || (typeof c.registerPlugin === 'function' ? c.registerPlugin(name) : null);
      if (p) pluginCache[name] = p;
      return p || null;
    } catch (e) { return null; }
  };
  MS.vibrate = function (ms) {
    try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* sin vibración */ }
  };

  /**
   * URL de Google Maps con las coordenadas de destino. En Android abre la app
   * de Google Maps (enlace universal); en la APK (Capacitor) se lanza como Intent.
   */
  MS.mapsUrl = function (lat, lng) {
    return 'https://www.google.com/maps/dir/?api=1&destination=' + lat.toFixed(6) + ',' + lng.toFixed(6);
  };
  /** URL de Apple Maps (iPhone/iPad): abre la app Mapas con la ruta hacia el destino. */
  MS.appleMapsUrl = function (lat, lng) {
    return 'https://maps.apple.com/?daddr=' + lat.toFixed(6) + ',' + lng.toFixed(6) + '&dirflg=d';
  };
  MS.openUrl = function (url) {
    var a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };
  MS.openMaps = function (lat, lng) {
    // iPhone/iPad (versión web): se ofrece elegir entre Google Maps y Apple Maps.
    if (!MS.isNative() && MS.isIOS() && MS.ui && MS.ui.pickMaps) { MS.ui.pickMaps(lat, lng); return; }
    MS.openUrl(MS.mapsUrl(lat, lng));
  };

  /* ---------- Pequeño emisor de eventos ---------- */
  MS.emitter = function () {
    var map = {};
    return {
      on: function (ev, fn) { (map[ev] = map[ev] || []).push(fn); return function () { map[ev] = map[ev].filter(function (f) { return f !== fn; }); }; },
      emit: function (ev, a, b) { (map[ev] || []).slice().forEach(function (fn) { try { fn(a, b); } catch (e) { console.error(e); } }); }
    };
  };

})(window.MS = window.MS || {});
