/* Mi Servicio – vistas: alta de persona, ficha con historial y lista de personas */
(function (MS) {
  'use strict';

  var h = MS.h, ui = MS.ui, store = MS.store;

  function nextFrame() {
    return new Promise(function (r) { requestAnimationFrame(function () { requestAnimationFrame(r); }); });
  }
  var sheetHead = ui.sheetHead;
  function coordsLine(lat, lng) {
    return h('p', { class: 'coords' }, h('span', { html: MS.icon('place', 16) }), MS.formatCoords(lat, lng));
  }

  /** Campo "Territorio" (número del 1 al 99, opcional). Solo admite dígitos; read() valida y devuelve { ok, value }. */
  function territoryField(value) {
    var f = ui.field({ label: 'Territorio (1 a 99)', value: value ? String(value) : '', inputmode: 'numeric', maxlength: 2, enterkeyhint: 'next' });
    f.input.addEventListener('input', function () {
      var clean = f.input.value.replace(/\D/g, '').slice(0, 2);
      if (clean !== f.input.value) f.input.value = clean;
    });
    f.read = function () {
      var t = f.input.value.trim();
      if (!t) return { ok: true, value: null };
      var n = parseInt(t, 10);
      if (!(n >= 1 && n <= 99)) { f.setError('Ingrese un número del 1 al 99.'); return { ok: false, value: null }; }
      return { ok: true, value: n };
    };
    return f;
  }
  /** Etiqueta "Territorio 33" (ficha y listado). */
  function territoryChip(n) {
    return h('span', { class: 'terr-chip' }, h('span', { html: MS.icon('tag', 14) }), 'Territorio ' + n);
  }

  /**
   * "No en casa": se fue a ver a la persona y no se la encontró. Queda en el historial con la fecha de hoy
   * (con "Deshacer"). Un doble toque seguido no registra dos veces.
   */
  var lastNoHomeTap = { id: null, at: 0 };
  function markNoHome(personId) {
    var now = Date.now();
    if (lastNoHomeTap.id === personId && now - lastNoHomeTap.at < 1500) return null;
    lastNoHomeTap = { id: personId, at: now };
    var n = store.addNote(personId, { kind: 'nohome', date: MS.todayISO(), text: '' });
    if (!n) return null;
    MS.vibrate(12);
    ui.snack('Registrado: no estaba en casa (' + MS.formatDate(n.date) + ')', {
      action: { label: 'Deshacer', onClick: function () { store.removeNote(personId, n.id); } }
    });
    return n;
  }

  /* =====================================================================
   * Alta de persona (hoja inferior modal con pin temporal)
   * ===================================================================== */
  function openNewPerson(pos) {
    var stage = 'primera', saved = false, sheet = null;
    MS.mapCtl.showTempPin(pos.lng, pos.lat, stage);

    var nameF = ui.field({ label: 'Nombre', required: true, autocapitalize: 'words', maxlength: 120, enterkeyhint: 'next' });
    var refF = ui.field({ label: 'Dirección / Referencia', placeholder: 'Ej.: Casa portón verde', maxlength: 200, enterkeyhint: 'next' });
    var terrF = territoryField();
    var chips = ui.stageChips(stage, function (v) { stage = v; MS.mapCtl.setTempStage(v); MS.vibrate(8); }, 'Categoría de visita');
    var dateF = ui.field({ label: 'Fecha de la visita', type: 'date', value: MS.todayISO() });
    var noteF = ui.field({ label: 'Nota de la visita', multiline: true, rows: 2, placeholder: 'Qué se conversó, qué quedó pendiente…' });

    function dirty() { return !!(nameF.value.trim() || refF.value.trim() || terrF.value.trim() || noteF.value.trim()); }

    function save() {
      var name = nameF.value.trim();
      if (!name) {
        nameF.setError('Ingrese el nombre de la persona.');
        nameF.input.focus();
        return;
      }
      var terr = terrF.read();
      if (!terr.ok) { terrF.input.focus(); return; }
      store.addPerson({
        name: name, ref: refF.value, territory: terr.value, stage: stage, lat: pos.lat, lng: pos.lng,
        date: dateF.value || MS.todayISO(), text: noteF.value
      });
      saved = true;
      sheet.close(true).then(function () { ui.snack('Persona guardada'); });
    }

    var form = h('form', { class: 'sheet-form', novalidate: true, onsubmit: function (e) { e.preventDefault(); save(); } },
      sheetHead('Nueva persona', function () { sheet.close(); }, { sub: coordsLine(pos.lat, pos.lng) }),
      nameF.el,
      refF.el,
      terrF.el,
      h('div', { class: 'form-label' }, 'Categoría de visita'),
      chips.el,
      dateF.el,
      noteF.el,
      h('div', { class: 'sheet-actions sticky' },
        ui.button({ variant: 'text', label: 'Cancelar', onClick: function () { sheet.close(); } }),
        ui.button({ variant: 'filled', label: 'Guardar', icon: 'check', type: 'submit' }))
    );

    sheet = ui.openSheet({
      title: 'Nueva persona', content: form, soft: true, compact: true,
      beforeClose: function () {
        if (saved || !dirty()) return true;
        return ui.dialog({
          title: '¿Descartar esta persona?', text: 'Se perderán los datos que ingresó.',
          confirmLabel: 'Descartar', cancelLabel: 'Seguir editando', danger: true
        });
      },
      onClose: function () { MS.mapCtl.clearTempPin(); MS.mapCtl.resetPadding(); }
    });
    nextFrame().then(function () { MS.mapCtl.focusAbove(pos.lng, pos.lat, sheet.height(), 0); });
  }

  /* =====================================================================
   * Ficha de la persona: datos, etapa, nueva nota e historial
   * ===================================================================== */
  function openDetail(id, opts) {
    opts = opts || {};
    if (!store.getPerson(id)) return;
    MS.mapCtl.setSelected(id);

    var sheet = null, unsub = null;
    var state = { editing: false, editNoteId: null };
    function person() { return store.getPerson(id); }

    var headEl = h('div', { class: 'detail-head' });
    var actionsEl = h('div', { class: 'detail-actions' });
    var stageEl = h('section', { class: 'detail-section' });
    var historyEl = h('section', { class: 'detail-section' });
    var footEl = h('div', { class: 'detail-foot' });

    /* ----- cabecera (datos y edición) ----- */
    function renderHeader() {
      var p = person(); if (!p) return;
      var st = MS.stageById(p.stage);
      headEl.textContent = '';
      if (!state.editing) {
        headEl.setAttribute('data-sheet-drag', '');
        headEl.append(
          h('div', { class: 'avatar', dataset: { stage: p.stage }, html: MS.icon(st.icon, 24) }),
          h('div', { class: 'head-text' },
            h('h2', { class: 'sheet-title' }, p.name),
            p.ref ? h('p', { class: 'head-sub' }, p.ref) : h('p', { class: 'head-sub muted' }, 'Sin dirección ni referencia'),
            p.territory ? h('p', { class: 'head-terr' }, territoryChip(p.territory)) : null),
          ui.iconButton({ icon: 'edit', label: 'Editar datos', onClick: function () { state.editing = true; renderHeader(); } }),
          ui.iconButton({ icon: 'close', label: 'Cerrar', onClick: function () { sheet.close(); } })
        );
      } else {
        headEl.removeAttribute('data-sheet-drag');
        var nf = ui.field({ label: 'Nombre', value: p.name, required: true, autocapitalize: 'words', maxlength: 120 });
        var rf = ui.field({ label: 'Dirección / Referencia', value: p.ref, maxlength: 200 });
        var tf = territoryField(p.territory);
        var saveEdit = function () {
          if (!nf.value.trim()) { nf.setError('Ingrese el nombre de la persona.'); nf.input.focus(); return; }
          var terr = tf.read();
          if (!terr.ok) { tf.input.focus(); return; }
          state.editing = false;
          store.updatePerson(id, { name: nf.value, ref: rf.value, territory: terr.value });
          ui.snack('Datos actualizados');
        };
        headEl.append(h('form', { class: 'edit-person', novalidate: true, onsubmit: function (e) { e.preventDefault(); saveEdit(); } },
          nf.el, rf.el, tf.el,
          h('div', { class: 'sheet-actions' },
            ui.button({ variant: 'text', label: 'Cancelar', onClick: function () { state.editing = false; renderHeader(); } }),
            ui.button({ variant: 'filled', label: 'Guardar', icon: 'check', type: 'submit' }))));
      }
    }

    /* ----- botones de acción: Ir / Maps, No en casa y Ver en el mapa ----- */
    function renderActions() {
      var p = person(); if (!p) return;
      actionsEl.textContent = '';
      actionsEl.appendChild(ui.button({ variant: 'filled', label: 'Ir / Maps', icon: 'directions', onClick: function () { MS.openMaps(person().lat, person().lng); } }));
      actionsEl.appendChild(ui.button({ variant: 'tonal', label: 'No en casa', icon: 'door', class: 'btn-nohome', onClick: function () { markNoHome(id); } }));
      if (opts.fromList) {
        actionsEl.appendChild(ui.button({ variant: 'tonal', label: 'Ver en el mapa', icon: 'map', onClick: function () {
          sheet.close().then(function (ok) { if (ok) MS.app.showOnMap(id); });
        } }));
      }
    }

    /* ----- etapa (selector rápido) ----- */
    var chipsApi = null;
    function renderStage() {
      var p = person(); if (!p) return;
      content.dataset.stage = p.stage;
      if (chipsApi) { chipsApi.set(p.stage); return; }
      stageEl.textContent = '';
      chipsApi = ui.stageChips(p.stage, function (v) {
        store.updatePerson(id, { stage: v });       // el marcador cambia de color al instante
      }, 'Etapa de la persona');
      stageEl.append(h('h3', { class: 'section-title' }, 'Etapa'), chipsApi.el);
    }

    /* ----- formulario rápido para una nueva nota con fecha ----- */
    var addDate = ui.field({ label: 'Fecha', type: 'date', value: MS.todayISO() });
    var addText = ui.field({ label: 'Nueva nota', multiline: true, rows: 2, placeholder: 'Qué pasó en esta visita…' });
    var addForm = h('form', { class: 'detail-section add-note', novalidate: true, onsubmit: function (e) {
      e.preventDefault();
      var text = addText.value.trim();
      if (!text) { addText.setError('Escriba una nota para registrar la visita.'); addText.input.focus(); return; }
      store.addNote(id, { date: addDate.value || MS.todayISO(), text: text });
      addText.value = '';
      addDate.value = MS.todayISO();
      ui.snack('Visita agregada al historial');
    } },
      h('h3', { class: 'section-title' }, 'Registrar nueva visita'),
      addDate.el, addText.el,
      h('div', { class: 'sheet-actions' }, ui.button({ variant: 'filled', label: 'Agregar nota', icon: 'add', type: 'submit' }))
    );

    /* ----- historial cronológico ----- */
    function noteItem(p, n) {
      var nohome = store.isNoHome(n);
      var li = h('li', { class: 'note' + (nohome ? ' nohome' : ''), dataset: { id: n.id } });
      li.append(h('div', { class: 'note-rail', 'aria-hidden': 'true' }, h('span', { class: 'note-dot' })));
      var body = h('div', { class: 'note-body' });
      li.append(body);

      if (state.editNoteId === n.id) {
        var df = ui.field({ label: 'Fecha', type: 'date', value: n.date });
        var tf = ui.field({ label: nohome ? 'Comentario (opcional)' : 'Nota', multiline: true, rows: nohome ? 2 : 3, value: n.text });
        body.append(h('form', { class: 'note-edit', novalidate: true, onsubmit: function (e) {
          e.preventDefault();
          state.editNoteId = null;
          store.updateNote(id, n.id, { date: df.value || n.date, text: tf.value });
        } },
          df.el, tf.el,
          h('div', { class: 'sheet-actions' },
            ui.button({ variant: 'text', label: 'Cancelar', onClick: function () { state.editNoteId = null; renderHistory(); } }),
            ui.button({ variant: 'filled', label: 'Guardar', icon: 'check', type: 'submit' }))));
        return li;
      }
      body.append(
        h('div', { class: 'note-top' },
          h('div', { class: 'note-when' },
            h('span', { class: 'note-date' }, MS.formatDate(n.date)),
            h('span', { class: 'note-rel' }, MS.relativeDate(n.date))),
          h('div', { class: 'note-actions' },
            ui.iconButton({ icon: 'edit', label: nohome ? 'Editar registro' : 'Editar nota', size: 20, onClick: function () { state.editNoteId = n.id; renderHistory(); } }),
            ui.iconButton({ icon: 'delete', label: nohome ? 'Eliminar registro' : 'Eliminar nota', size: 20, onClick: function () { removeNote(n.id); } }))),
        nohome ? h('p', { class: 'note-nohome' }, h('span', { html: MS.icon('door', 18) }), 'No en casa') : null,
        n.text ? h('p', { class: 'note-text' }, n.text) : (nohome ? null : h('p', { class: 'note-text muted' }, 'Visita sin nota'))
      );
      return li;
    }
    function removeNote(noteId) {
      var snap = store.removeNote(id, noteId);
      if (!snap) return;
      ui.snack(store.isNoHome(snap.note) ? 'Registro eliminado' : 'Nota eliminada', { action: { label: 'Deshacer', onClick: function () { store.restoreNote(id, snap); } } });
    }
    function renderHistory() {
      var p = person(); if (!p) return;
      var order = store.getSetting('notesOrder') === 'asc' ? 'asc' : 'desc';
      var notes = store.sortedNotes(p, order);
      historyEl.textContent = '';
      var toggle = h('button', { type: 'button', class: 'text-toggle ripple', 'aria-label': 'Cambiar el orden del historial', onclick: function () {
        store.setSetting('notesOrder', order === 'desc' ? 'asc' : 'desc');
        renderHistory();
      } }, h('span', { html: MS.icon('swap', 18) }), order === 'desc' ? 'Más recientes primero' : 'Más antiguas primero');
      historyEl.append(
        h('div', { class: 'section-row' },
          h('h3', { class: 'section-title' }, 'Historial de visitas', h('span', { class: 'count' }, String(notes.length))),
          notes.length > 1 ? toggle : null),
        notes.length ? h('ol', { class: 'timeline' }, notes.map(function (n) { return noteItem(p, n); }))
          : h('p', { class: 'muted' }, 'Todavía no hay visitas registradas.')
      );
    }

    /* ----- eliminar persona ----- */
    function renderFoot() {
      footEl.textContent = '';
      footEl.append(ui.button({ variant: 'text', danger: true, label: 'Eliminar persona', icon: 'delete', onClick: function () {
        var p = person(); if (!p) return;
        ui.dialog({
          title: '¿Eliminar a ' + p.name + '?',
          text: 'Se borrarán también ' + (p.notes.length === 1 ? 'su único registro' : 'sus ' + p.notes.length + ' registros') + ' del historial.',
          confirmLabel: 'Eliminar', danger: true
        }).then(function (ok) {
          if (!ok) return;
          sheet.close(true).then(function () {
            var snap = store.removePerson(id);
            if (snap) ui.snack('Persona eliminada', { action: { label: 'Deshacer', onClick: function () { store.restorePerson(snap); } } });
          });
        });
      } }));
    }

    var content = h('div', { class: 'detail' }, headEl, coordsLine(person().lat, person().lng), actionsEl, stageEl, addForm, historyEl, footEl);
    renderHeader(); renderActions(); renderStage(); renderHistory(); renderFoot();

    sheet = ui.openSheet({
      title: 'Ficha de ' + person().name, content: content, className: 'sheet-detail', soft: !opts.fromList, compact: !opts.fromList,
      onClose: function () {
        if (unsub) unsub();
        MS.mapCtl.setSelected(null);
        MS.mapCtl.resetPadding();
      }
    });
    unsub = store.on('change', function (e) {
      if (e.type !== 'bulk' && e.id !== id) return;
      if (!person()) { sheet.close(true); return; }
      if (!state.editing) renderHeader();
      renderStage();
      renderHistory();
    });
    var p0 = person();
    nextFrame().then(function () { if (!opts.fromList) MS.mapCtl.focusAbove(p0.lng, p0.lat, sheet.height(), 15); });
    return sheet;
  }

  /* =====================================================================
   * Pestaña "Personas": lista, búsqueda en tiempo real y filtros por etapa
   * ===================================================================== */
  var People = (function () {
    var state = { q: '', stage: 'all' };
    var el = {};
    var visible = false;

    function normChar(c) { return c.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); }
    /** Resalta (sin tildes ni mayúsculas) las palabras buscadas dentro de un texto. */
    function highlight(text, tokens) {
      text = text || '';
      if (!tokens.length || !text) return document.createTextNode(text);
      var norm = '', map = [], i, k;
      for (i = 0; i < text.length; i++) {
        var n = normChar(text[i]);
        for (k = 0; k < n.length; k++) { norm += n[k]; map.push(i); }
      }
      var marks = [];
      for (i = 0; i < text.length; i++) marks.push(false);
      tokens.forEach(function (t) {
        var from = 0, idx;
        while ((idx = norm.indexOf(t, from)) >= 0) {
          for (var j = idx; j < idx + t.length; j++) marks[map[j]] = true;
          from = idx + t.length;
        }
      });
      var frag = document.createDocumentFragment(), buf = '', on = false;
      function flush() {
        if (!buf) return;
        frag.appendChild(on ? h('mark', null, buf) : document.createTextNode(buf));
        buf = '';
      }
      for (i = 0; i < text.length; i++) {
        if (marks[i] !== on) { flush(); on = marks[i]; }
        buf += text[i];
      }
      flush();
      return frag;
    }
    function snippetOf(text, tokens) {
      if (text.length <= 120) return text;
      var norm = MS.norm(text), idx = -1;
      for (var i = 0; i < tokens.length && idx < 0; i++) idx = norm.indexOf(tokens[i]);
      var start = Math.max(0, (idx < 0 ? 0 : idx) - 40);
      return (start > 0 ? '…' : '') + text.slice(start, start + 120) + (start + 120 < text.length ? '…' : '');
    }

    function build(container) {
      el.search = h('input', { class: 'search-input', type: 'search', placeholder: 'Buscar por nombre, referencia o nota', 'aria-label': 'Buscar personas', autocomplete: 'off', enterkeyhint: 'search' });
      el.clear = ui.iconButton({ icon: 'close', label: 'Borrar búsqueda', size: 20, class: 'search-clear', onClick: function () { el.search.value = ''; state.q = ''; render(); el.search.focus(); } });
      el.clear.hidden = true;
      el.filters = h('div', { class: 'filters', role: 'radiogroup', 'aria-label': 'Filtrar por etapa' });
      el.count = h('span', { class: 'list-count' });
      el.sortBtn = h('button', { type: 'button', class: 'text-toggle ripple', onclick: function () {
        store.setSetting('peopleSort', store.getSetting('peopleSort') === 'name' ? 'recent' : 'name');
        render();
      } });
      el.list = h('ul', { class: 'cards' });
      el.empty = h('div', { class: 'empty' });
      el.scroll = h('div', { class: 'list-scroll' }, el.list, el.empty);

      var top = h('header', { class: 'topbar' },
        h('div', { class: 'topbar-row' },
          h('h1', { class: 'topbar-title' }, 'Personas'),
          ui.iconButton({ icon: 'settings', label: 'Ajustes', onClick: function () { MS.settings.open(); } })),
        h('label', { class: 'searchbar' }, h('span', { class: 'search-ic', html: MS.icon('search', 22) }), el.search, el.clear),
        el.filters,
        h('div', { class: 'list-meta' }, el.count, el.sortBtn));
      container.append(top, el.scroll);

      var onSearch = MS.debounce(function () { state.q = el.search.value; render(); }, 60);
      el.search.addEventListener('input', function () { el.clear.hidden = !el.search.value; onSearch(); });

      el.list.addEventListener('click', function (e) {
        var card = e.target.closest('.card');
        if (!card) return;
        var pid = card.dataset.id;
        if (e.target.closest('.go-maps')) {
          var p = store.getPerson(pid);
          if (p) MS.openMaps(p.lat, p.lng);
          return;
        }
        if (e.target.closest('.go-nohome')) { markNoHome(pid); return; }
        openDetail(pid, { fromList: true });
      });
      el.list.addEventListener('keydown', function (e) {
        if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('card')) {
          e.preventDefault();
          openDetail(e.target.dataset.id, { fromList: true });
        }
      });
    }

    function renderFilters() {
      var counts = store.countByStage();
      el.filters.textContent = '';
      var opts = [{ id: 'all', label: 'Todas', icon: null }].concat(MS.STAGES);
      opts.forEach(function (o) {
        var b = h('button', { type: 'button', class: 'chip ripple' + (state.stage === o.id ? ' on' : ''), role: 'radio', 'aria-checked': state.stage === o.id ? 'true' : 'false', dataset: { stage: o.id } });
        b.innerHTML = (state.stage === o.id && o.id === 'all' ? '<span class="chip-ic">' + MS.icon('check', 18) + '</span>' : (o.icon ? '<span class="chip-ic">' + MS.icon(o.icon, 18) + '</span>' : '')) +
          '<span>' + MS.esc(o.label) + '</span><span class="chip-count">' + (counts[o.id] || 0) + '</span>';
        b.addEventListener('click', function () { state.stage = o.id; render(); });
        el.filters.appendChild(b);
      });
    }

    function card(item, tokens) {
      var p = item.person, st = MS.stageById(p.stage), last = store.lastVisit(p);
      var nVisits = store.visitCount(p), nohome = store.noHomeInfo(p);
      var visits = nVisits + (nVisits === 1 ? ' visita' : ' visitas');
      return h('li', { class: 'card ripple', dataset: { id: p.id, stage: p.stage }, tabindex: '0', role: 'button',
        'aria-label': p.name + ', ' + st.label + (p.territory ? ', territorio ' + p.territory : '') + (nohome ? ', no estaba en casa la última vez' : '') },
        h('div', { class: 'card-main' },
          h('div', { class: 'avatar', html: MS.icon(st.icon, 24) }),
          h('div', { class: 'card-text' },
            h('div', { class: 'card-top' },
              h('div', { class: 'card-title' }, highlight(p.name, tokens)),
              last ? h('span', { class: 'card-when', title: MS.formatDate(last) }, MS.relativeDate(last)) : null),
            p.ref ? h('div', { class: 'card-sub' }, h('span', { class: 'sub-ic', html: MS.icon('place', 16) }), h('span', { class: 'sub-text' }, highlight(p.ref, tokens))) : null,
            h('div', { class: 'card-meta' },
              h('span', { class: 'tag' }, st.label),
              p.territory ? territoryChip(p.territory) : null,
              h('span', { class: 'visits' }, h('span', { html: MS.icon('history', 16) }), visits),
              nohome ? h('span', { class: 'nohome-chip', title: 'Última vez: ' + MS.formatDate(nohome.date) },
                h('span', { html: MS.icon('door', 14) }), nohome.count > 1 ? 'No estaba en casa ×' + nohome.count : 'No estaba en casa') : null))),
        item.snippet ? h('div', { class: 'card-snippet' },
          h('span', { class: 'snip-date' }, MS.formatDateShort(item.snippet.date)), ' ',
          highlight(snippetOf(snippetText(item.snippet), tokens), tokens)) : null,
        h('div', { class: 'card-actions' },
          ui.button({ variant: 'text', label: 'No en casa', icon: 'door', class: 'go-nohome sm' }),
          ui.button({ variant: 'tonal', label: 'Ir / Maps', icon: 'directions', class: 'go-maps sm' }))
      );
    }
    /** Texto con el que una nota aparece en el fragmento de una búsqueda. */
    function snippetText(n) {
      return store.isNoHome(n) ? 'No en casa' + (n.text ? ' · ' + n.text : '') : n.text;
    }

    function render() {
      if (!el.list) return;
      var tokens = MS.norm(state.q).split(/\s+/).filter(Boolean);
      var results = store.search(state.q, state.stage);
      var total = store.people.length;
      renderFilters();
      el.count.textContent = (results.length === total ? total : results.length + ' de ' + total) + (total === 1 ? ' persona' : ' personas');
      el.sortBtn.innerHTML = MS.icon('swap', 18) + (store.getSetting('peopleSort') === 'name' ? 'Orden: A–Z' : 'Orden: más recientes');
      el.list.textContent = '';
      results.forEach(function (it) { el.list.appendChild(card(it, tokens)); });

      el.empty.textContent = '';
      el.empty.hidden = results.length > 0;
      if (!results.length) {
        if (!total) {
          el.empty.append(
            h('div', { class: 'empty-ic', html: MS.icon('pin-drop', 48) }),
            h('h2', null, 'Aún no hay personas registradas'),
            h('p', null, 'Toque cualquier punto del mapa para registrar a la primera persona.'),
            ui.button({ variant: 'filled', label: 'Ir al mapa', icon: 'map', onClick: function () { MS.app.showTab('map'); } }));
        } else {
          el.empty.append(
            h('div', { class: 'empty-ic', html: MS.icon('search', 48) }),
            h('h2', null, 'Sin resultados'),
            h('p', null, 'Pruebe con otro nombre, referencia o palabra de las notas, o cambie el filtro de etapa.'));
        }
      }
    }

    return {
      build: build,
      render: render,
      setVisible: function (v) { visible = v; if (v) render(); },
      refresh: function () { if (visible) render(); }
    };
  })();

  MS.views = { openNewPerson: openNewPerson, openDetail: openDetail, people: People };

})(window.MS = window.MS || {});
