/* Mi Servicio – utilidades */
(function (MS) {
  'use strict';

  MS.$ = function (sel, root) { return (root || document).querySelector(sel); };
  MS.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  function append(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach(function (x) { append(el, x); }); }
    else if (c instanceof Node) el.appendChild(c);
    else el.appendChild(document.createTextNode(String(c)));
  }

  /** Agrega hijos a un elemento ya creado, ignorando null/undefined/false (a diferencia de Element.append, que escribiría «null»). */
  MS.put = function (el) {
    for (var i = 1; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  };

  /** Crea un elemento: h('div', {class:'x', onclick: fn, dataset:{a:1}}, ...hijos) */
  MS.h = function (tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v == null || v === false) return;
        if (k === 'class') el.className = v;
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'text') el.textContent = v;
        else if (k === 'dataset') Object.assign(el.dataset, v);
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (v === true) el.setAttribute(k, '');
        else el.setAttribute(k, v);
      });
    }
    for (var i = 2; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  };

  MS.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  MS.uid = function () {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  };

  MS.clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };

  MS.debounce = function (fn, ms) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, ms);
    };
  };

  /** Texto sin tildes y en minúsculas, para buscar. */
  MS.norm = function (s) {
    return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  };

  MS.formatBytes = function (n) {
    if (!n || n < 1024) return (n || 0) + ' B';
    if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
    if (n < 1073741824) return (n / 1048576).toFixed(n < 10485760 ? 1 : 0).replace('.', ',') + ' MB';
    return (n / 1073741824).toFixed(2).replace('.', ',') + ' GB';
  };

  /* ---------- Fechas (siempre en hora local, formato AAAA-MM-DD) ---------- */
  var DIAS = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
  var MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
  function pad(n) { return (n < 10 ? '0' : '') + n; }

  MS.todayISO = function () {
    var d = new Date();
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  };
  MS.parseISO = function (s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || '');
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  };
  /** "mar 24 nov 2026" */
  MS.formatDate = function (s) {
    var d = MS.parseISO(s);
    if (!d) return '';
    return DIAS[d.getDay()] + ' ' + d.getDate() + ' ' + MESES[d.getMonth()] + ' ' + d.getFullYear();
  };
  /** "24 nov 2026" */
  MS.formatDateShort = function (s) {
    var d = MS.parseISO(s);
    if (!d) return '';
    return d.getDate() + ' ' + MESES[d.getMonth()] + ' ' + d.getFullYear();
  };
  MS.relativeDate = function (s) {
    var d = MS.parseISO(s);
    if (!d) return '';
    var t = MS.parseISO(MS.todayISO());
    var days = Math.round((t - d) / 86400000);
    if (days === 0) return 'Hoy';
    if (days === 1) return 'Ayer';
    if (days === -1) return 'Mañana';
    if (days < 0) return 'En ' + (-days) + ' días';
    if (days < 30) return 'Hace ' + days + ' días';
    if (days < 365) { var m = Math.round(days / 30); return 'Hace ' + m + (m === 1 ? ' mes' : ' meses'); }
    var a = Math.floor(days / 365);
    return 'Hace ' + a + (a === 1 ? ' año' : ' años');
  };

  /* ---------- Hora (siempre local, formato HH:MM de 24 h) ---------- */
  MS.nowTime = function () {
    var d = new Date();
    return pad(d.getHours()) + ':' + pad(d.getMinutes());
  };
  MS.validTime = function (s) { return typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s); };
  /** "HH:MM" de un instante (milisegundos) en hora local. */
  MS.timeOf = function (ms) {
    var d = new Date(ms);
    return isFinite(d.getTime()) ? pad(d.getHours()) + ':' + pad(d.getMinutes()) : '';
  };
  /** "AAAA-MM-DD" de un instante (milisegundos) en hora local. */
  MS.dateOf = function (ms) {
    var d = new Date(ms);
    return isFinite(d.getTime()) ? d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) : '';
  };

  MS.formatCoords = function (lat, lng) {
    return lat.toFixed(5) + ', ' + lng.toFixed(5);
  };

  /* ---------- Plataforma ---------- */
  MS.isNative = function () {
    var c = window.Capacitor;
    return !!(c && typeof c.isNativePlatform === 'function' && c.isNativePlatform());
  };
  /** iPhone/iPad (incluye iPadOS, que se presenta como Mac con pantalla táctil). */
  MS.isIOS = function () {
    var ua = navigator.userAgent || '';
    return /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && (navigator.maxTouchPoints || 0) > 1);
  };
  /** true cuando la web se abrió desde el ícono de la pantalla de inicio (modo aplicación). */
  MS.isStandalone = function () {
    return !!(navigator.standalone || (window.matchMedia && matchMedia('(display-mode: standalone)').matches));
  };
  var pluginCache = {};
  MS.plugin = function (name) {
    var c = window.Capacitor;
    if (!c) return null;
    if (pluginCache[name]) return pluginCache[name];
    try {
      var p = (c.Plugins && c.Plugins[name]) || (typeof c.registerPlugin === 'function' ? c.registerPlugin(name) : null);
      if (p) pluginCache[name] = p;
      return p || null;
    } catch (e) { return null; }
  };
  MS.vibrate = function (ms) {
    try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* sin vibración */ }
  };

  /**
   * URL de Google Maps con las coordenadas de destino. En Android abre la app
   * de Google Maps (enlace universal); en la APK (Capacitor) se lanza como Intent.
   */
  MS.mapsUrl = function (lat, lng) {
    return 'https://www.google.com/maps/dir/?api=1&destination=' + lat.toFixed(6) + ',' + lng.toFixed(6);
  };
  /** Enlace que abre Google Maps con un pin en el lugar (para compartir por mensaje). */
  MS.mapsPinUrl = function (lat, lng) {
    return 'https://www.google.com/maps/search/?api=1&query=' + lat.toFixed(6) + ',' + lng.toFixed(6);
  };
  /** URL de Apple Maps (iPhone/iPad): abre la app Mapas con la ruta hacia el destino. */
  MS.appleMapsUrl = function (lat, lng) {
    return 'https://maps.apple.com/?daddr=' + lat.toFixed(6) + ',' + lng.toFixed(6) + '&dirflg=d';
  };
  MS.openUrl = function (url) {
    var a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };
  MS.openMaps = function (lat, lng) {
    // iPhone/iPad (versión web): se ofrece elegir entre Google Maps y Apple Maps.
    if (!MS.isNative() && MS.isIOS() && MS.ui && MS.ui.pickMaps) { MS.ui.pickMaps(lat, lng); return; }
    MS.openUrl(MS.mapsUrl(lat, lng));
  };

  /** Copia un texto al portapapeles. Devuelve una promesa con true/false. */
  function copyText(text) {
    function legacy() {
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
        document.body.appendChild(ta);
        ta.select();
        var ok = document.execCommand('copy');
        ta.remove();
        return ok;
      } catch (e) { return false; }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return legacy(); });
    }
    return Promise.resolve(legacy());
  }
  /**
   * Comparte un texto con el menú del sistema (WhatsApp, Mensajes, correo…). Sin menú disponible, lo copia.
   * Devuelve una promesa con 'shared' | 'cancel' | 'copied' | 'error'.
   */
  MS.shareText = function (o) {
    var text = o.text, title = o.title || '';
    function fallbackCopy() { return copyText(text).then(function (ok) { return ok ? 'copied' : 'error'; }); }
    if (MS.isNative()) {
      var Share = MS.plugin('Share');
      if (Share && Share.share) {
        return Promise.resolve(Share.share({ title: title, text: text, dialogTitle: o.dialogTitle || title }))
          .then(function () { return 'shared'; })
          .catch(function (e) { return /cancel/i.test(String((e && (e.message || e.name)) || e)) ? 'cancel' : fallbackCopy(); });
      }
    }
    if (navigator.share) {
      return Promise.resolve(navigator.share({ title: title, text: text }))
        .then(function () { return 'shared'; })
        .catch(function (e) { return e && e.name === 'AbortError' ? 'cancel' : fallbackCopy(); });
    }
    return fallbackCopy();
  };

  /* ---------- Pequeño emisor de eventos ---------- */
  MS.emitter = function () {
    var map = {};
    return {
      on: function (ev, fn) { (map[ev] = map[ev] || []).push(fn); return function () { map[ev] = map[ev].filter(function (f) { return f !== fn; }); }; },
      emit: function (ev, a, b) { (map[ev] || []).slice().forEach(function (fn) { try { fn(a, b); } catch (e) { console.error(e); } }); }
    };
  };

})(window.MS = window.MS || {});
