/* Mi Servicio – almacenamiento local (IndexedDB) */
(function (MS) {
  'use strict';

  var NAME = 'mi-servicio';
  var VERSION = 1;
  var dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve) {
      if (!window.indexedDB) { resolve(null); return; }
      var req;
      try { req = indexedDB.open(NAME, VERSION); } catch (e) { resolve(null); return; }
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
        if (!db.objectStoreNames.contains('tiles')) db.createObjectStore('tiles');
        if (!db.objectStoreNames.contains('tmeta')) {
          var m = db.createObjectStore('tmeta');
          m.createIndex('t', 't');
        }
      };
      req.onsuccess = function () {
        var db = req.result;
        db.onversionchange = function () { db.close(); };
        resolve(db);
      };
      req.onerror = function () { resolve(null); };
      req.onblocked = function () { resolve(null); };
    });
    return dbPromise;
  }

  /** Ejecuta fn(...stores) dentro de una transacción. Si fn devuelve un IDBRequest, se resuelve con su resultado. */
  function tx(storeNames, mode, fn) {
    return open().then(function (db) {
      if (!db) return Promise.reject(new Error('sin-indexeddb'));
      return new Promise(function (resolve, reject) {
        var t = db.transaction(storeNames, mode);
        var stores = storeNames.map(function (n) { return t.objectStore(n); });
        var result;
        t.oncomplete = function () { resolve(result); };
        t.onerror = function () { reject(t.error); };
        t.onabort = function () { reject(t.error || new Error('abortada')); };
        var ret = fn.apply(null, stores);
        if (ret && typeof ret === 'object' && 'onsuccess' in ret) {
          ret.onsuccess = function () { result = ret.result; };
        } else {
          result = ret;
        }
      });
    });
  }

  /* ---------- Clave/valor (con respaldo en localStorage si IndexedDB no está) ---------- */
  var kv = {
    get: function (key, fallback) {
      return tx(['kv'], 'readonly', function (s) { return s.get(key); })
        .then(function (v) { return v === undefined ? fallback : v; })
        .catch(function () {
          try { var raw = localStorage.getItem('ms:' + key); return raw == null ? fallback : JSON.parse(raw); }
          catch (e) { return fallback; }
        });
    },
    set: function (key, value) {
      return tx(['kv'], 'readwrite', function (s) { s.put(value, key); })
        .catch(function () {
          try { localStorage.setItem('ms:' + key, JSON.stringify(value)); } catch (e) { /* sin espacio */ }
        });
    },
    del: function (key) {
      return tx(['kv'], 'readwrite', function (s) { s.delete(key); }).catch(function () {});
    }
  };

  /* ---------- Teselas del mapa ----------
   * tiles: clave "z/x/y" -> { d: ArrayBuffer, z: 0|1 (1 = comprimido con gzip) }
   * tmeta: clave "z/x/y" -> { t: marca de tiempo, s: tamaño guardado, p: 1 si pertenece a una zona descargada }
   */
  var tiles = {
    get: function (key) {
      return tx(['tiles'], 'readonly', function (s) { return s.get(key); }).catch(function () { return undefined; });
    },
    meta: function (key) {
      return tx(['tmeta'], 'readonly', function (s) { return s.get(key); }).catch(function () { return undefined; });
    },
    put: function (key, rec, size, pinned) {
      return tx(['tiles', 'tmeta'], 'readwrite', function (st, sm) {
        st.put(rec, key);
        if (pinned) { sm.put({ t: Date.now(), s: size, p: 1 }, key); return; }
        // Una tesela automática nunca "desfija" una que ya pertenece a una zona descargada.
        var r = sm.get(key);
        r.onsuccess = function () {
          sm.put({ t: Date.now(), s: size, p: r.result && r.result.p ? 1 : 0 }, key);
        };
      });
    },
    setPinned: function (keys, flag) {
      if (!keys.length) return Promise.resolve();
      return tx(['tmeta'], 'readwrite', function (sm) {
        keys.forEach(function (k) {
          var r = sm.get(k);
          r.onsuccess = function () {
            var v = r.result;
            if (v) { v.p = flag ? 1 : 0; sm.put(v, k); }
          };
        });
      });
    },
    remove: function (keys) {
      if (!keys.length) return Promise.resolve();
      return tx(['tiles', 'tmeta'], 'readwrite', function (st, sm) {
        keys.forEach(function (k) { st.delete(k); sm.delete(k); });
      });
    },
    /** Estadísticas: cantidad y bytes, separando zonas descargadas y caché automática. */
    stats: function () {
      var out = { count: 0, bytes: 0, pinned: { count: 0, bytes: 0 }, auto: { count: 0, bytes: 0 } };
      return tx(['tmeta'], 'readonly', function (sm) {
        var req = sm.openCursor();
        req.onsuccess = function () {
          var c = req.result;
          if (!c) return;
          var v = c.value, g = v.p ? out.pinned : out.auto;
          g.count++; g.bytes += v.s || 0; out.count++; out.bytes += v.s || 0;
          c.continue();
        };
      }).then(function () { return out; }).catch(function () { return out; });
    },
    /** Deja como máximo `max` teselas automáticas (no fijadas), borrando las más antiguas. */
    evict: function (max) {
      return tx(['tiles', 'tmeta'], 'readwrite', function (st, sm) {
        var list = [];
        var req = sm.openCursor();
        req.onsuccess = function () {
          var c = req.result;
          if (c) { if (!c.value.p) list.push([c.value.t, c.key]); c.continue(); return; }
          var extra = list.length - max;
          if (extra > 0) {
            list.sort(function (a, b) { return a[0] - b[0]; });
            for (var i = 0; i < extra; i++) { st.delete(list[i][1]); sm.delete(list[i][1]); }
          }
        };
      }).catch(function () {});
    },
    clearAuto: function () {
      return tx(['tiles', 'tmeta'], 'readwrite', function (st, sm) {
        var req = sm.openCursor();
        req.onsuccess = function () {
          var c = req.result;
          if (!c) return;
          if (!c.value.p) { st.delete(c.key); c.delete(); }
          c.continue();
        };
      }).catch(function () {});
    }
  };

  MS.db = { open: open, kv: kv, tiles: tiles };

})(window.MS = window.MS || {});
