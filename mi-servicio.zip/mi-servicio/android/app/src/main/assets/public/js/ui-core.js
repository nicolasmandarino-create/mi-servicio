/* Mi Servicio – componentes de interfaz Material 3: capas con botón "atrás", hojas inferiores,
 * diálogos, snackbar, ripple, campos de texto y chips. */
(function (MS) {
  'use strict';

  var h = MS.h;

  /* =====================================================================
   * Capas (hojas, diálogos, pestaña Personas) integradas con el historial,
   * para que el botón "atrás" de Android las cierre una por una.
   * ===================================================================== */
  var stack = [];
  var ignorePop = 0;
  var waiters = [];
  var seq = 0;

  function sync() { document.documentElement.classList.toggle('has-layer', stack.length > 0); }
  function finish(layer) {
    var i = stack.indexOf(layer);
    if (i >= 0) stack.splice(i, 1);
    sync();
    if (layer.teardown) { try { layer.teardown(); } catch (e) { console.error(e); } }
  }

  var layers = {
    push: function (layer) {
      layer.id = ++seq;
      stack.push(layer);
      sync();
      try { history.pushState({ ms: layer.id }, ''); } catch (e) { /* sin historial */ }
      return layer;
    },
    /** Cierre iniciado por la interfaz. Resuelve true si se cerró, false si lo impidió beforeClose. */
    request: function (layer, force) {
      if (stack.indexOf(layer) < 0) return Promise.resolve(false);
      var pre = (!force && layer.beforeClose) ? layer.beforeClose() : true;
      return Promise.resolve(pre).then(function (ok) {
        if (ok === false) return false;
        if (stack.indexOf(layer) < 0) return true;
        var isTop = stack[stack.length - 1] === layer;
        finish(layer);
        if (!isTop) return true;
        return new Promise(function (resolve) {
          ignorePop++;
          waiters.push(resolve);
          history.back();
          setTimeout(function () {
            var i = waiters.indexOf(resolve);
            if (i >= 0) { waiters.splice(i, 1); resolve(true); }
          }, 500);
        });
      });
    },
    top: function () { return stack[stack.length - 1] || null; },
    size: function () { return stack.length; }
  };
  MS.layers = layers;

  window.addEventListener('popstate', function () {
    if (ignorePop > 0) {
      ignorePop--;
      var w = waiters.shift();
      if (w) w(true);
      return;
    }
    var top = stack[stack.length - 1];
    if (!top) return;
    Promise.resolve(top.beforeClose ? top.beforeClose() : true).then(function (ok) {
      if (ok === false) { try { history.pushState({ ms: top.id }, ''); } catch (e) { /* nada */ } return; }
      finish(top);
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { var t = layers.top(); if (t && t.dismissible !== false) layers.request(t); }
  });

  function root() { return document.getElementById('layers'); }

  /* =====================================================================
   * Hoja inferior modal
   * ===================================================================== */
  function enableDrag(sheet, scrim, onDismiss) {
    var startY = 0, dy = 0, dragging = false, t0 = 0;
    sheet.addEventListener('pointerdown', function (e) {
      var grip = e.target.closest && e.target.closest('.sheet-grab, [data-sheet-drag]');
      if (!grip || (e.pointerType === 'mouse' && e.button > 0)) return;
      if (e.target.closest('button, a, input, textarea, select')) return;   // los botones de la cabecera reciben su toque normalmente
      dragging = true; startY = e.clientY; dy = 0; t0 = performance.now();
      sheet.classList.add('dragging');
      try { grip.setPointerCapture(e.pointerId); } catch (err) { /* nada */ }
    });
    sheet.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      dy = Math.max(0, e.clientY - startY);
      sheet.style.transform = 'translateY(' + dy + 'px)';
      scrim.style.opacity = String(Math.max(0, 1 - dy / Math.max(1, sheet.offsetHeight)));
    });
    function end() {
      if (!dragging) return;
      dragging = false;
      sheet.classList.remove('dragging');
      scrim.style.opacity = '';
      var v = dy / Math.max(1, performance.now() - t0);
      if (dy > sheet.offsetHeight * 0.3 || (v > 0.7 && dy > 40)) {
        Promise.resolve(onDismiss()).then(function (closed) { if (closed === false) sheet.style.transform = ''; });
      } else {
        sheet.style.transform = '';
      }
    }
    sheet.addEventListener('pointerup', end);
    sheet.addEventListener('pointercancel', end);
  }

  /**
   * opts: { title, content (Node), className, beforeClose(), onClose(), dismissible }
   * Devuelve { el, scroll, close(), setContent(node), height() }
   */
  function openSheet(opts) {
    var scrim = h('div', { class: 'scrim' + (opts.soft ? ' soft' : '') });
    var grab = h('div', { class: 'sheet-grab', 'aria-hidden': 'true' }, h('span', { class: 'sheet-handle' }));
    var scroll = h('div', { class: 'sheet-scroll' });
    var sheet = h('section', {
      class: 'sheet' + (opts.compact ? ' sheet-compact' : '') + (opts.className ? ' ' + opts.className : ''),
      role: 'dialog', 'aria-modal': 'true', 'aria-label': opts.title || '', tabindex: '-1'
    }, grab, scroll);
    // Si la hoja trae una barra fija de botones, el área de desplazamiento no deja margen abajo: la barra queda pegada al borde inferior.
    function markBar() { scroll.classList.toggle('has-bar', !!scroll.querySelector('.sheet-actions.sticky')); }
    if (opts.content) { scroll.appendChild(opts.content); markBar(); }
    root().appendChild(scrim);
    root().appendChild(sheet);
    var prevFocus = document.activeElement;

    requestAnimationFrame(function () {
      requestAnimationFrame(function () { scrim.classList.add('on'); sheet.classList.add('on'); });
    });

    var layer = layers.push({
      dismissible: opts.dismissible,
      beforeClose: opts.beforeClose,
      teardown: function () {
        scrim.classList.remove('on');
        sheet.classList.remove('on');
        sheet.style.transform = '';
        scrim.style.opacity = '';
        setTimeout(function () { scrim.remove(); sheet.remove(); }, 340);
        if (prevFocus && prevFocus.focus) { try { prevFocus.focus({ preventScroll: true }); } catch (e) { /* nada */ } }
        if (opts.onClose) opts.onClose();
      }
    });
    var api = {
      el: sheet,
      scroll: scroll,
      layer: layer,
      close: function (force) { return layers.request(layer, force); },
      setContent: function (node) { scroll.textContent = ''; scroll.appendChild(node); markBar(); scroll.scrollTop = 0; },
      height: function () { return sheet.getBoundingClientRect().height; }
    };
    if (opts.dismissible !== false) scrim.addEventListener('click', function () { api.close(); });
    enableDrag(sheet, scrim, function () { return api.close(); });
    return api;
  }

  /* =====================================================================
   * Diálogo de confirmación (Material 3)
   * ===================================================================== */
  function dialog(o) {
    return new Promise(function (resolve) {
      var settled = false;
      var scrim = h('div', { class: 'scrim' });
      var titleId = 'dlg-' + MS.uid();
      var cancel = o.cancelLabel === null ? null : h('button', { type: 'button', class: 'btn btn-text ripple' }, o.cancelLabel || 'Cancelar');
      var ok = h('button', { type: 'button', class: 'btn btn-text ripple' + (o.danger ? ' danger' : '') }, o.confirmLabel || 'Aceptar');
      var dlg = h('div', { class: 'dialog', role: 'alertdialog', 'aria-modal': 'true', 'aria-labelledby': titleId },
        h('h2', { class: 'dialog-title', id: titleId }, o.title),
        o.text ? h('p', { class: 'dialog-text' }, o.text) : null,
        o.content || null,
        h('div', { class: 'dialog-actions' }, cancel, ok));
      root().appendChild(scrim);
      root().appendChild(dlg);
      requestAnimationFrame(function () { requestAnimationFrame(function () { scrim.classList.add('on'); dlg.classList.add('on'); }); });

      var layer = layers.push({
        teardown: function () {
          scrim.classList.remove('on'); dlg.classList.remove('on');
          setTimeout(function () { scrim.remove(); dlg.remove(); }, 260);
          if (!settled) { settled = true; resolve(false); }
        }
      });
      function done(v) {
        if (settled) return;
        settled = true;
        layers.request(layer, true).then(function () { resolve(v); });
      }
      ok.addEventListener('click', function () { done(true); });
      if (cancel) cancel.addEventListener('click', function () { done(false); });
      scrim.addEventListener('click', function () { done(false); });
      setTimeout(function () { try { ok.focus({ preventScroll: true }); } catch (e) { /* nada */ } }, 60);
    });
  }

  /* =====================================================================
   * Snackbar
   * ===================================================================== */
  var snackTimer = null;
  function snack(message, opts) {
    opts = opts || {};
    var rootEl = document.getElementById('snackbar');
    clearTimeout(snackTimer);
    rootEl.textContent = '';
    var bar = h('div', { class: 'snack', role: 'status' }, h('span', { class: 'snack-text' }, message));
    function hide() {
      bar.classList.remove('on');
      setTimeout(function () { if (bar.parentNode) bar.remove(); }, 220);
    }
    if (opts.action) {
      bar.appendChild(h('button', {
        type: 'button', class: 'snack-action ripple',
        onclick: function () { clearTimeout(snackTimer); hide(); opts.action.onClick(); }
      }, opts.action.label));
    }
    rootEl.appendChild(bar);
    requestAnimationFrame(function () { bar.classList.add('on'); });
    snackTimer = setTimeout(hide, opts.duration || 4500);
  }

  /* =====================================================================
   * Ripple (efecto de toque)
   * ===================================================================== */
  document.addEventListener('pointerdown', function (e) {
    var t = e.target.closest && e.target.closest('.ripple');
    if (!t || t.disabled) return;
    var r = t.getBoundingClientRect();
    var size = Math.max(r.width, r.height) * 2;
    var s = document.createElement('span');
    s.className = 'ripple-fx';
    s.style.cssText = 'width:' + size + 'px;height:' + size + 'px;left:' + (e.clientX - r.left - size / 2) + 'px;top:' + (e.clientY - r.top - size / 2) + 'px';
    t.appendChild(s);
    s.addEventListener('animationend', function () { s.remove(); });
  }, { passive: true });

  /* =====================================================================
   * Botones, campos y chips
   * ===================================================================== */
  function button(o) {
    var b = h('button', {
      type: o.type || 'button',
      class: 'btn btn-' + (o.variant || 'filled') + ' ripple' + (o.danger ? ' danger' : '') + (o.class ? ' ' + o.class : ''),
      'aria-label': o.ariaLabel
    });
    if (o.icon) b.insertAdjacentHTML('beforeend', MS.icon(o.icon, 18));
    if (o.label) b.appendChild(document.createTextNode(o.label));
    if (o.onClick) b.addEventListener('click', o.onClick);
    return b;
  }
  function iconButton(o) {
    var b = h('button', {
      type: 'button', class: 'icon-btn ripple' + (o.variant ? ' ' + o.variant : '') + (o.class ? ' ' + o.class : ''),
      'aria-label': o.label, title: o.label
    });
    b.innerHTML = MS.icon(o.icon, o.size || 24);
    if (o.onClick) b.addEventListener('click', o.onClick);
    return b;
  }

  /* ---------- Campos de varias líneas y teclado en pantalla ---------- */

  /**
   * Altura máxima de un cuadro de texto: lo que la hoja puede mostrar de una vez (sin contar el asa ni la barra fija
   * de botones), para que el cuadro entero —y el cursor— quede siempre a la vista. Con teclado abierto queda poco espacio.
   */
  function textareaMax(ta) {
    var room = window.innerHeight * 0.45;
    var sheet = ta.closest('.sheet'), sc = ta.closest('.sheet-scroll');
    if (sheet && sc) {
      var maxH = parseFloat(getComputedStyle(sheet).maxHeight);
      var bar = sc.querySelector('.sheet-actions.sticky');
      if (maxH > 0) room = maxH - (sheet.firstElementChild ? sheet.firstElementChild.offsetHeight : 28) - (bar ? bar.offsetHeight : 0) - 24;
    }
    return Math.round(MS.clamp(room, 120, 320));
  }

  /** Ajusta la altura del cuadro al texto; pasado el máximo, el texto se desplaza por dentro. */
  function fitTextarea(ta) {
    if (!ta.isConnected || !ta.clientWidth) return;            // todavía no está dibujado: no hay nada que medir
    var sc = ta.closest('.sheet-scroll'), st = sc ? sc.scrollTop : 0;
    ta.style.height = 'auto';
    var want = ta.scrollHeight, max = textareaMax(ta);
    ta.style.height = Math.min(want, max) + 'px';
    ta.style.overflowY = want > max ? 'auto' : 'hidden';
    if (sc) sc.scrollTop = st;                                  // medir no debe mover la hoja
  }

  /**
   * Deja el elemento a la vista dentro de la hoja: por encima del teclado y de la barra fija
   * "Cancelar / Guardar". Si es más alto que el espacio libre, muestra su final (donde se escribe).
   */
  function keepVisible(el) {
    var sc = el && el.isConnected && el.closest ? el.closest('.sheet-scroll') : null;
    if (!sc) return;
    var s = sc.getBoundingClientRect(), r = el.getBoundingClientRect();
    var bar = sc.querySelector('.sheet-actions.sticky');
    var top = s.top + 8, bottom = Math.min(s.bottom, bar ? bar.getBoundingClientRect().top : s.bottom) - 8;
    if (r.height > bottom - top || r.bottom > bottom) sc.scrollTop += r.bottom - bottom;
    else if (r.top < top) sc.scrollTop -= top - r.top;
  }

  /** Hace que un <textarea> crezca mientras se escribe. Devuelve { fit } para recalcular tras cambiar el valor. */
  function autoGrow(ta) {
    ta.setAttribute('data-grow', '');
    function later() { requestAnimationFrame(function () { requestAnimationFrame(function () { fitTextarea(ta); }); }); }
    ta.addEventListener('input', function () {
      fitTextarea(ta);
      if (document.activeElement === ta) keepVisible(ta.closest('.field') || ta);
    });
    later();                                                    // al crearse aún no está en el documento
    return { fit: function () { fitTextarea(ta); } };
  }

  // Al abrir o cerrar el teclado (o girar el teléfono) cambia el espacio disponible: se reajustan los cuadros y el campo activo.
  var refit = MS.debounce(function () {
    MS.$$('textarea.field-input[data-grow]').forEach(fitTextarea);
    var a = document.activeElement;
    if (a && a.matches && a.matches('.field-input')) keepVisible(a.closest('.field') || a);
  }, 90);
  window.addEventListener('resize', refit);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', refit);
  document.addEventListener('focusin', refit);
  document.addEventListener('focusout', refit);

  /**
   * Campo de texto "filled" de Material 3 con etiqueta flotante.
   * o: { label, value, type, multiline, rows, placeholder, required, maxlength, autocomplete, inputmode, helper }
   */
  function field(o) {
    var id = 'f-' + MS.uid();
    var input = h(o.multiline ? 'textarea' : 'input', {
      class: 'field-input', id: id, placeholder: o.placeholder != null ? o.placeholder : ' ',
      type: o.multiline ? null : (o.type || 'text'),
      rows: o.multiline ? (o.rows || 3) : null, maxlength: o.maxlength,
      autocomplete: o.autocomplete || 'off', inputmode: o.inputmode, autocapitalize: o.autocapitalize,
      required: o.required ? true : null, enterkeyhint: o.enterkeyhint
    });
    if (o.value != null) input.value = o.value;
    var grow = o.multiline ? autoGrow(input) : null;
    var helper = h('span', { class: 'field-helper', id: id + '-h' }, o.helper || '');
    var el = h('div', { class: 'field' + (o.multiline ? ' multiline' : '') + (o.type === 'date' || o.type === 'time' ? ' static' : '') + (o.placeholder ? ' static' : '') },
      input, h('label', { class: 'field-label', for: id }, o.label + (o.required ? ' *' : '')), helper);
    input.setAttribute('aria-describedby', id + '-h');
    var normalHelper = o.helper || '';
    var api = {
      el: el, input: input,
      get value() { return input.value; },
      set value(v) { input.value = v; if (grow) grow.fit(); },
      setError: function (msg) {
        el.classList.add('error'); helper.textContent = msg; input.setAttribute('aria-invalid', 'true');
      },
      clearError: function () {
        el.classList.remove('error'); helper.textContent = normalHelper; input.removeAttribute('aria-invalid');
      }
    };
    input.addEventListener('input', function () { if (el.classList.contains('error')) api.clearError(); });
    // Con teclado en pantalla la hoja se achica: se vuelve a encuadrar el campo mientras el teclado termina de abrirse.
    input.addEventListener('focus', function () {
      [60, 350, 700].forEach(function (ms) {
        setTimeout(function () { if (document.activeElement === input) keepVisible(el); }, ms);
      });
    });
    return api;
  }

  /**
   * Selector de etapa: tres fichas exclusivas. Cada ficha muestra el mismo color e ícono
   * que tendrá el marcador en el mapa.
   */
  function stageChips(value, onChange, label) {
    var wrap = h('div', { class: 'stage-tiles', role: 'radiogroup', 'aria-label': label || 'Etapa' });
    MS.STAGES.forEach(function (st) {
      var b = h('button', { type: 'button', class: 'stage-tile ripple', role: 'radio', 'aria-checked': 'false', dataset: { stage: st.id } });
      b.innerHTML = '<span class="tile-disc">' + MS.icon(st.icon, 22) + '</span><span class="tile-label">' + MS.esc(st.label) + '</span>';
      b.addEventListener('click', function () {
        if (value === st.id) return;
        set(st.id);
        if (onChange) onChange(st.id);
      });
      wrap.appendChild(b);
    });
    function set(v) {
      value = v;
      MS.$$('.stage-tile', wrap).forEach(function (b) {
        var on = b.dataset.stage === v;
        b.classList.toggle('on', on);
        b.setAttribute('aria-checked', on ? 'true' : 'false');
      });
    }
    set(value);
    return { el: wrap, set: set, get value() { return value; } };
  }

  /** Cabecera de una hoja: título, botón cerrar y (opcional) botón "volver". También sirve para arrastrar la hoja. */
  function sheetHead(title, onClose, opts) {
    opts = opts || {};
    return h('div', { class: 'sheet-head', 'data-sheet-drag': '' },
      opts.back ? iconButton({ icon: 'back', label: 'Volver', onClick: opts.back }) : null,
      h('div', { class: 'sheet-headtext' }, h('h2', { class: 'sheet-title' }, title), opts.sub || null),
      iconButton({ icon: 'close', label: 'Cerrar', onClick: onClose }));
  }

  /** iPhone/iPad: elegir con qué aplicación se abre la ruta (Google Maps o Apple Maps). */
  function pickMaps(lat, lng) {
    var sheet = null;
    // El enlace se abre dentro del mismo toque (Safari bloquea las ventanas que se abren con demora) y después se cierra la hoja.
    function pick(url) { MS.openUrl(url); sheet.close(true); }
    var content = h('div', { class: 'maps-pick' },
      sheetHead('Ir a la ubicación', function () { sheet.close(); }),
      h('p', { class: 'muted' }, 'Elija con qué aplicación abrir la ruta.'),
      h('div', { class: 'sheet-form' },
        button({ variant: 'filled', icon: 'directions', label: 'Google Maps', onClick: function () { pick(MS.mapsUrl(lat, lng)); } }),
        button({ variant: 'tonal', icon: 'directions', label: 'Apple Maps', onClick: function () { pick(MS.appleMapsUrl(lat, lng)); } })));
    sheet = openSheet({ title: 'Ir a la ubicación', compact: true, content: content });
  }

  MS.ui = {
    pickMaps: pickMaps,
    openSheet: openSheet,
    dialog: dialog,
    snack: snack,
    button: button,
    iconButton: iconButton,
    field: field,
    autoGrow: autoGrow,
    keepVisible: keepVisible,
    stageChips: stageChips,
    sheetHead: sheetHead
  };

})(window.MS = window.MS || {});
