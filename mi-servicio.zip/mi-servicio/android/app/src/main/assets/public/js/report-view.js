/* Mi Servicio – pestaña «Mi informe»: resumen del mes, calendario, meta (15, 30, 50 o 100 h) y carga de horas.
 *
 * Una sola fuente de verdad para los estudios: las visitas marcadas como estudio en la ficha de cada persona
 * (MS.store). Cargar «Hice un estudio este día» acá crea esa misma visita en la ficha (con su nota), y una visita a un
 * estudio anotada desde el mapa o desde Personas aparece acá sin hacer nada. Las horas y las asignaciones aprobadas
 * viven en MS.report. */
(function (MS) {
  'use strict';

  var h = MS.h, ui = MS.ui, store = MS.store, report = MS.report;
  var el = {};
  var view = { ym: '', mode: 'summary', day: null, today: '', visible: false };

  function today() { return MS.todayISO(); }
  var MINUS = '\u2212';
  function dur(min) { return min < 0 ? MINUS + MS.formatDuration(-min) : MS.formatDuration(min); }
  /** Con signo explícito: «+30 min» / «−30 min». */
  function signed(min) { return (min < 0 ? MINUS : '+') + MS.formatDuration(Math.abs(min)); }
  /** Total grande: los números se destacan y las unidades (h, min) van más chicas; el texto leído no cambia. */
  function durBig(min) {
    return dur(min).split(/(\d+)/).filter(Boolean).map(function (t) { return /^\d+$/.test(t) || t === MINUS ? t : h('span', { class: 'u' }, t); });
  }
  /** Mayúscula inicial (el nombre del mes va en minúscula, salvo al empezar una oración). */
  function cap(t) { return t.charAt(0).toUpperCase() + t.slice(1); }
  function plural(n, one, many) { return n + ' ' + (n === 1 ? one : many); }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function dayISO(ym, d) { return ym + '-' + pad2(d); }
  function initials(name) {
    var w = String(name || '').trim().split(/\s+/).filter(Boolean);
    if (!w.length) return '?';
    return (w[0].charAt(0) + (w.length > 1 ? w[w.length - 1].charAt(0) : w[0].charAt(1))).toUpperCase();
  }
  function byName(a, b) { return a.name.localeCompare(b.name, 'es', { sensitivity: 'base' }); }
  function ic(name, size) { return h('span', { class: 'ic-wrap', html: MS.icon(name, size || 20) }); }

  /* Si pasó la medianoche mientras la app estaba abierta: hoy cambió y, si se miraba el mes en curso, se pasa al nuevo. */
  function syncToday() {
    var t = today();
    if (t === view.today) return;
    if (!view.ym || view.ym === MS.monthKey(view.today)) view.ym = MS.monthKey(t);
    view.today = t;
    view.day = null;
  }
  function isCurrent() { return view.ym === MS.monthKey(view.today); }
  /** Día que se muestra en el calendario: el elegido; si no hay (o es de otro mes), hoy, el primero con registros o el 1. */
  function ensureDay() {
    if (view.day && MS.monthKey(view.day) === view.ym) return view.day;
    if (isCurrent()) return (view.day = view.today);
    var n = MS.daysInMonth(view.ym), i;
    for (i = 1; i <= n; i++) if (dayHasRecords(dayISO(view.ym, i))) return (view.day = dayISO(view.ym, i));
    return (view.day = dayISO(view.ym, 1));
  }
  function dayHasRecords(iso) {
    return report.minutesOn(iso) > 0 || report.extrasOn(iso).length > 0 || store.studyVisits(iso).length > 0;
  }
  function monthStudies(ym) { return store.studyVisits(ym + '-01', dayISO(ym, MS.daysInMonth(ym))); }

  /* =====================================================================
   * Meta: cuatro opciones (15, 30, 50 o 100 horas)
   * ===================================================================== */
  function goalTiles(selected, onPick, opts) {
    opts = opts || {};
    var n = MS.daysInMonth(view.ym);
    var wrap = h('div', { class: 'goal-grid' + (opts.row ? ' row' : ''), role: 'radiogroup', 'aria-label': 'Meta de horas del mes' });
    MS.GOALS.forEach(function (hrs) {
      var on = hrs === selected;
      var b = h('button', { type: 'button', class: 'goal-tile ripple' + (on ? ' on' : ''), role: 'radio', 'aria-checked': on ? 'true' : 'false', dataset: { goal: String(hrs) },
        'aria-label': hrs + ' horas', onclick: function () { onPick(hrs); } },
        h('span', { class: 'goal-check', html: MS.icon('check', 20) }),
        h('span', { class: 'goal-num' }, String(hrs)),
        h('span', { class: 'goal-unit' }, 'horas'),
        h('span', { class: 'goal-hint' }, '≈ ' + dur(Math.round(hrs * 60 / n)) + ' por día'));
      wrap.appendChild(b);
    });
    return wrap;
  }

  function openGoal() {
    var cur = report.goalFor(view.ym), sheet = null, ym = view.ym;
    var tiles = goalTiles(cur && cur.h, function (hrs) {
      report.setGoal(ym, hrs);
      MS.vibrate(8);
      sheet.close(true).then(function () { ui.snack('Meta de ' + MS.monthName(ym) + ': ' + hrs + ' horas'); });
    });
    sheet = ui.openSheet({
      title: 'Meta de horas', compact: true,
      content: h('div', { class: 'goal-sheet' },
        ui.sheetHead('Meta de horas', function () { sheet.close(); }, { sub: h('p', { class: 'muted' }, MS.monthLabel(ym)) }),
        tiles,
        h('p', { class: 'muted goal-note' }, 'Elija cuántas horas quiere hacer este mes. Se mantiene en los meses siguientes hasta que la cambie.'))
    });
  }

  /* =====================================================================
   * Resumen
   * ===================================================================== */
  function goalCard() {
    var p = report.progress(view.ym, view.today);
    var card = h('section', { class: 'rp-card rp-goal', 'aria-label': 'Meta del mes' });
    var kicker = h('div', { class: 'rp-kicker' }, h('span', { html: MS.icon('flag', 18) }), 'Meta del mes');
    card.append(h('div', { class: 'rp-goal-top' }, kicker,
      p.goal ? ui.button({ variant: 'tonal', label: p.goal.h + ' h', icon: 'edit', class: 'rp-goal-btn', ariaLabel: 'Cambiar la meta: ' + p.goal.h + ' horas', onClick: openGoal }) : null));
    card.append(h('div', { class: 'rp-total' },
      h('div', { class: 'rp-total-num' }, durBig(p.doneMin)),
      p.goal ? h('div', { class: 'rp-total-pct' }, p.pct + ' %') : null));

    if (!p.goal) {
      card.append(h('p', { class: 'muted rp-pick' }, 'Elija cuántas horas quiere hacer en ' + MS.monthName(view.ym) + ':'),
        goalTiles(null, function (hrs) { report.setGoal(view.ym, hrs); MS.vibrate(8); }, { row: true }));
      return card;
    }

    var fill = h('div', { class: 'rp-bar-fill' });
    card.append(h('div', { class: 'rp-bar', role: 'progressbar', 'aria-label': 'Avance hacia la meta', 'aria-valuemin': '0', 'aria-valuemax': String(p.goalMin),
      'aria-valuenow': String(Math.max(0, Math.min(p.doneMin, p.goalMin))), 'aria-valuetext': dur(p.doneMin) + ' de ' + dur(p.goalMin) }, fill));
    var pct = Math.round(p.ratio * 1000) / 10;
    requestAnimationFrame(function () { requestAnimationFrame(function () { fill.style.width = pct + '%'; }); });

    var pastMonth = p.daysLeft === 0;
    if (p.reached) {
      card.append(h('div', { class: 'rp-remain' },
        h('div', { class: 'rp-remain-main rp-done' }, h('span', { html: MS.icon('check', 22) }), '¡Meta cumplida!'),
        p.overMin > 0 ? h('div', { class: 'rp-remain-side' }, 'Superó la meta por ' + dur(p.overMin)) : null));
    } else {
      card.append(h('div', { class: 'rp-remain' },
        h('div', { class: 'rp-remain-main' }, (pastMonth ? 'Faltaron ' : 'Faltan ') + dur(p.remainMin)),
        pastMonth ? null : h('div', { class: 'rp-remain-side' }, p.daysLeft === 1 ? 'Queda 1 día' : 'Quedan ' + p.daysLeft + ' días')));
      if (!pastMonth) {
        var last = p.daysLeft === 1 && isCurrent();
        card.append(h('div', { class: 'rp-pace' }, h('span', { html: MS.icon('clock', 18) }),
          h('span', null, 'Para llegar: ', h('b', null, dur(p.perDayMin) + (last ? ' hoy' : ' por día')))));
      }
    }
    return card;
  }

  function extrasCard() {
    var list = report.extrasInMonth(view.ym).slice().reverse();
    var total = report.extrasMinutes(view.ym);
    var card = h('section', { class: 'rp-card rp-extras', 'aria-label': 'Asignaciones aprobadas' });
    card.append(h('div', { class: 'rp-extra-head' },
      h('div', null, h('div', { class: 'rp-extra-title' }, 'Asignaciones aprobadas'), h('div', { class: 'rp-sub' }, 'No suman a la meta')),
      list.length ? h('div', { class: 'rp-extra-sum' }, h('div', { class: 'rp-extra-title' }, dur(total)), h('div', { class: 'rp-sub' }, plural(list.length, 'registrada', 'registradas'))) : null));
    if (!list.length) {
      card.append(h('p', { class: 'rp-empty' }, 'Todavía no cargó ninguna este mes. Use «Cargar horas» y elija «Horas extras».'));
      return card;
    }
    list.forEach(function (x) {
      card.append(h('button', { type: 'button', class: 'rp-row ripple', onclick: function () { openLoad({ extraId: x.id }); },
        'aria-label': 'Editar asignación: ' + (x.text || 'sin descripción') + ', ' + dur(x.m) },
        h('span', { class: 'rp-disc extra', html: MS.icon('check', 20) }),
        h('span', { class: 'rp-row-text' },
          h('span', { class: 'rp-row-title wrap', style: { display: 'block' } }, x.text || 'Asignación aprobada'),
          h('span', { class: 'rp-sub', style: { display: 'block' } }, MS.longDate(x.date))),
        h('span', { class: 'rp-row-val' }, dur(x.m))));
    });
    return card;
  }

  /**
   * Comparte el informe del mes (menú de compartir del teléfono). Si se eligió cómo redondear las horas ('up' | 'down'), queda
   * registrado: el mes siguiente arranca con la diferencia. Si no se llega a enviar (se cancela), el redondeo no queda registrado.
   */
  function shareReport(ym, dir, prevDir) {
    if (dir) report.setRound(ym, dir);
    var next = MS.addMonths(ym, 1);
    MS.shareText({ title: 'Informe de ' + MS.monthName(ym), text: report.reportText(ym), dialogTitle: 'Enviar informe' }).then(function (r) {
      if (r === 'cancel' || r === 'error') {
        if (dir) report.setRound(ym, prevDir || null);
        if (r === 'error') ui.snack('No se pudo compartir el informe.');
        return;
      }
      var carryMsg = dir ? ' ' + cap(MS.monthName(next)) + ' empieza con ' + signed(report.roundInfo(ym)[dir].carry) + '.' : '';
      if (r === 'copied') ui.snack('No se pudo abrir el menú para compartir: el informe quedó copiado. Péguelo donde quiera enviarlo.' + carryMsg, { duration: 7000 });
      else if (dir) ui.snack('Informe enviado.' + carryMsg, { duration: 6000 });
    });
  }

  /** Las horas se envían redondas: se elige hacia arriba o hacia abajo y se ve qué horas se informan y cómo empieza el mes siguiente. */
  function openRound(ym) {
    var info = report.roundInfo(ym), prevDir = info.mode, next = MS.addMonths(ym, 1), sheet = null;
    function tile(dir, label) {
      var o = info[dir], on = info.mode === dir;
      return h('button', { type: 'button', class: 'goal-tile round-tile ripple' + (on ? ' on' : ''), role: 'radio', 'aria-checked': on ? 'true' : 'false', dataset: { round: dir },
        'aria-label': label + ': ' + o.h + (o.h === 1 ? ' hora' : ' horas') + '. ' + cap(MS.monthName(next)) + ' empieza con ' + (o.carry < 0 ? 'menos ' : 'más ') + MS.formatDuration(Math.abs(o.carry)),
        onclick: function () { shareReport(ym, dir, prevDir); sheet.close(true); } },
        h('span', { class: 'goal-check', html: MS.icon('check', 20) }),
        h('span', { class: 'round-dir' }, label),
        h('span', { class: 'goal-num' }, String(o.h)),
        h('span', { class: 'goal-unit' }, o.h === 1 ? 'hora' : 'horas'),
        h('span', { class: 'goal-hint' }, cap(MS.monthName(next)) + ' empieza con ' + signed(o.carry)));
    }
    sheet = ui.openSheet({
      title: 'Redondear las horas', compact: true,
      content: h('div', { class: 'goal-sheet round-sheet' },
        ui.sheetHead('Redondear las horas', function () { sheet.close(); }, { sub: h('p', { class: 'muted' }, MS.monthLabel(ym) + ': ' + dur(info.total)) }),
        h('div', { class: 'goal-grid', role: 'radiogroup', 'aria-label': 'Redondeo de las horas' }, tile('up', 'Hacia arriba'), tile('down', 'Hacia abajo')),
        h('p', { class: 'muted goal-note' }, 'El informe se envía con horas redondas y la diferencia pasa al mes siguiente. Las horas extras (actividades teocráticas) se envían tal cual, sin redondear.'))
    });
  }

  function sendReport() {
    var ym = view.ym;
    if (report.roundInfo(ym).needsChoice) openRound(ym);
    else shareReport(ym, null, null);   // horas enteras: no hay nada que redondear
  }

  /** «Informe del mes»: muestra tal cual el texto que se envía (la misma función arma las dos cosas). */
  function sendCard() {
    var ym = view.ym, info = report.roundInfo(ym), card = h('section', { class: 'rp-card rp-send', 'aria-label': 'Informe del mes' });
    var note = null;
    if (info.needsChoice) {
      note = info.mode
        ? 'Redondeo hacia ' + (info.mode === 'up' ? 'arriba' : 'abajo') + ': ' + MS.monthName(MS.addMonths(ym, 1)) + ' empieza con ' + signed(info[info.mode].carry) + '.'
        : 'Al enviar elegirá cómo redondear las horas: hacia arriba o hacia abajo.';
    }
    card.append(
      h('div', { class: 'rp-kicker' }, h('span', { html: MS.icon('report', 18) }), 'Informe de ' + MS.monthName(ym)),
      h('p', { class: 'rp-sub' }, 'Los estudios cuentan personas, no visitas. Las horas extras no se redondean.'),
      h('p', { class: 'rp-send-text' }, report.reportText(ym)),
      note ? h('p', { class: 'rp-sub rp-send-note' }, note) : null,
      ui.button({ variant: 'filled', label: 'Enviar informe', icon: 'share', class: 'rp-send-btn', onClick: sendReport }));
    return card;
  }

  function summary() {
    var wrap = h('div', { class: 'rp-stack' });
    wrap.append(goalCard());
    var carry = report.carryInfo(view.ym);
    if (carry) {
      wrap.append(h('div', { class: 'rp-line rp-carry' }, h('span', { html: MS.icon('swap', 20) }),
        h('span', null, 'Arrastre de ' + MS.monthName(carry.from) + ': ', h('b', null, signed(carry.min)), ' (redondeo hacia ' + (carry.dir === 'up' ? 'arriba' : 'abajo') + ')')));
    }
    if (isCurrent()) {
      var m = report.minutesOn(view.today);
      wrap.append(h('div', { class: 'rp-line' }, h('span', { html: MS.icon('calendar', 20) }),
        h('span', null, 'Hoy, ' + MS.weekdayName(view.today) + ' ' + Number(view.today.slice(8)) + ': ', m ? h('b', null, dur(m)) : 'sin horas cargadas')));
    }
    var st = monthStudies(view.ym);
    if (st.length) {
      var people = {};
      st.forEach(function (e) { people[e.person.id] = 1; });
      var np = Object.keys(people).length;
      wrap.append(h('div', { class: 'rp-line' }, h('span', { html: MS.icon('book', 20) }),
        h('span', null, 'Estudios en ' + MS.monthName(view.ym) + ': ', h('b', null, plural(np, 'persona', 'personas')), ', ' + plural(st.length, 'visita', 'visitas'))));
    }
    wrap.append(extrasCard());
    if (view.ym <= view.today.slice(0, 7)) wrap.append(sendCard());   // un mes que todavía no empezó no tiene informe para enviar
    return wrap;
  }

  /* =====================================================================
   * Calendario
   * ===================================================================== */
  function heatLevel(m) { return m <= 0 ? 0 : m <= 90 ? 1 : m <= 150 ? 2 : m <= 210 ? 3 : 4; }

  function dayLabel(iso, min, studies, extras) {
    var parts = [MS.weekdayName(iso) + ' ' + Number(iso.slice(8)) + ' de ' + MS.monthName(iso.slice(0, 7))];
    if (min) parts.push(dur(min));
    if (studies) parts.push(studies === 1 ? 'un estudio' : studies + ' estudios');
    if (extras) parts.push(extras === 1 ? 'una asignación aprobada' : extras + ' asignaciones aprobadas');
    return parts.join(', ');
  }

  function calendar() {
    var p = report.progress(view.ym, view.today), sel = ensureDay();
    var wrap = h('div', { class: 'rp-calendar' });

    // Avance del mes (resumido)
    var mini = h('div', { class: 'rp-mini' },
      h('div', { class: 'rp-mini-main' }, dur(p.doneMin), p.goal ? h('span', null, ' de ' + p.goal.h + ' h') : null),
      p.goal ? h('div', { class: 'rp-mini-side' }, p.reached ? '¡Meta cumplida!' : (p.daysLeft === 0 ? 'Faltaron ' : 'Faltan ') + dur(p.remainMin))
        : h('div', { class: 'rp-mini-side' }, ui.button({ variant: 'text', label: 'Elegir meta', onClick: openGoal })));
    wrap.append(mini);
    var carry = report.carryInfo(view.ym);
    if (carry) wrap.append(h('p', { class: 'rp-sub rp-mini-carry' }, 'Incluye ' + signed(carry.min) + ' de ' + MS.monthName(carry.from) + ' (redondeo).'));
    if (p.goal) {
      var fill = h('div', { class: 'rp-bar-fill' });
      wrap.append(h('div', { class: 'rp-bar thin', role: 'progressbar', 'aria-label': 'Avance hacia la meta', 'aria-valuemin': '0', 'aria-valuemax': String(p.goalMin),
        'aria-valuenow': String(Math.max(0, Math.min(p.doneMin, p.goalMin))), 'aria-valuetext': dur(p.doneMin) + ' de ' + dur(p.goalMin) }, fill));
      var pct = Math.round(p.ratio * 1000) / 10;
      requestAnimationFrame(function () { requestAnimationFrame(function () { fill.style.width = pct + '%'; }); });
    }

    // Cuadrícula: la semana empieza el lunes
    wrap.append(h('div', { class: 'rp-week', 'aria-hidden': 'true' }, ['L', 'M', 'M', 'J', 'V', 'S', 'D'].map(function (d) { return h('span', null, d); })));
    var n = MS.daysInMonth(view.ym), first = MS.parseISO(view.ym + '-01');
    var offset = (first.getDay() + 6) % 7;
    var days = h('div', { class: 'rp-days', role: 'group', 'aria-label': 'Días de ' + MS.monthLabel(view.ym) });
    var i;
    for (i = 0; i < offset; i++) days.appendChild(h('div', { class: 'rp-cell', 'aria-hidden': 'true' }));
    var studyDays = {};
    monthStudies(view.ym).forEach(function (e) { studyDays[e.note.date] = (studyDays[e.note.date] || 0) + 1; });
    var extraDays = {};
    report.extrasInMonth(view.ym).forEach(function (x) { extraDays[x.date] = (extraDays[x.date] || 0) + 1; });
    for (i = 1; i <= n; i++) {
      var iso = dayISO(view.ym, i), m = report.minutesOn(iso), ns = studyDays[iso] || 0, ne = extraDays[iso] || 0;
      var cls = 'rp-day ripple' + (iso === view.today ? ' today' : '') + (iso > view.today ? ' future' : '') + (iso === sel ? ' sel' : '');
      var b = h('button', { type: 'button', class: cls, dataset: { date: iso, heat: String(heatLevel(m)) }, 'aria-pressed': iso === sel ? 'true' : 'false', 'aria-label': dayLabel(iso, m, ns, ne) },
        h('span', { class: 'rp-day-n' }, String(i)),
        h('span', { class: 'rp-day-h' }, m ? MS.formatClock(m) : ' '),
        ns ? h('span', { class: 'rp-mark study', 'aria-hidden': 'true' }) : null,
        ne ? h('span', { class: 'rp-mark extra', 'aria-hidden': 'true' }) : null);
      days.appendChild(h('div', { class: 'rp-cell' }, b));
    }
    days.addEventListener('click', function (e) {
      var b = e.target.closest('.rp-day');
      if (!b) return;
      view.day = b.dataset.date;
      MS.vibrate(6);
      var keep = el.scroll.scrollTop;
      renderBody();
      el.scroll.scrollTop = keep;
    });
    wrap.append(days);

    // Leyenda
    wrap.append(h('div', { class: 'rp-legend' },
      h('span', { class: 'rp-legend-item' }, h('span', { class: 'rp-legend-dot study' }), 'Estudio'),
      h('span', { class: 'rp-legend-item' }, h('span', { class: 'rp-legend-dot extra' }), 'Asignación aprobada'),
      h('span', { class: 'rp-legend-scale' }, 'Menos', [1, 2, 3, 4].map(function (l) { return h('span', { class: 'rp-legend-sw', dataset: { heat: String(l) } }); }), 'Más')));

    wrap.append(dayDetail(sel));
    return wrap;
  }

  function dayDetail(iso) {
    var min = report.minutesOn(iso), studies = store.studyVisits(iso), extras = report.extrasOn(iso);
    var card = h('section', { class: 'rp-card rp-detail', 'aria-label': MS.longDate(iso) });
    card.append(h('div', { class: 'rp-detail-head' },
      h('div', null,
        h('div', { class: 'rp-detail-title' }, MS.longDate(iso)),
        h('div', { class: 'rp-sub rp-detail-sum' }, 'Suma a la meta: ', h('b', null, min ? dur(min) : 'sin horas'))),
      ui.iconButton({ icon: 'edit', label: 'Cargar o editar las horas de este día', onClick: function () { openLoad({ date: iso }); } })));

    if (!min && !studies.length && !extras.length) {
      card.append(h('div', { class: 'rp-detail-empty' },
        h('p', { class: 'muted' }, 'No hay registros este día.'),
        ui.button({ variant: 'tonal', label: 'Cargar horas de este día', icon: 'add', onClick: function () { openLoad({ date: iso }); } })));
      return card;
    }
    if (min) {
      card.append(h('div', { class: 'rp-drow' }, h('span', { class: 'rp-disc sm time', html: MS.icon('clock', 16) }),
        h('span', { class: 'rp-row-text' }, h('span', { class: 'rp-row-title', style: { display: 'block' } }, h('b', null, 'Horas del mes'))),
        h('span', { class: 'rp-row-val' }, dur(min))));
    }
    studies.forEach(function (e) {
      var t = store.noteTime(e.note), line = (t ? t + (e.note.text ? ' · ' : '') : '') + (e.note.text || '').split('\n')[0];
      card.append(h('button', { type: 'button', class: 'rp-drow ripple', onclick: function () { MS.views.openDetail(e.person.id, { fromList: true }); },
        'aria-label': 'Estudio con ' + e.person.name + (line ? ': ' + line : '') + '. Abrir la ficha' },
        h('span', { class: 'rp-disc sm study', html: MS.icon('book', 16) }),
        h('span', { class: 'rp-row-text' },
          h('span', { class: 'rp-row-title', style: { display: 'block' } }, h('b', null, 'Estudio'), ' con ' + e.person.name),
          line ? h('span', { class: 'rp-drow-note' }, line) : null),
        h('span', { class: 'rp-drow-go', html: MS.icon('chevron', 20) })));
    });
    extras.forEach(function (x) {
      card.append(h('button', { type: 'button', class: 'rp-drow ripple', onclick: function () { openLoad({ extraId: x.id }); },
        'aria-label': 'Editar asignación: ' + (x.text || 'sin descripción') + ', ' + dur(x.m) },
        h('span', { class: 'rp-disc sm extra', html: MS.icon('check', 16) }),
        h('span', { class: 'rp-row-text' },
          h('span', { class: 'rp-row-title', style: { display: 'block' } }, h('b', null, x.text || 'Asignación aprobada')),
          h('span', { class: 'rp-drow-note' }, 'Asignación aprobada · no suma')),
        h('span', { class: 'rp-row-val' }, dur(x.m))));
    });
    return card;
  }

  /* =====================================================================
   * Cargar horas / horas extras / estudios
   * ===================================================================== */
  function digitsField(label) {
    var f = ui.field({ label: label, inputmode: 'numeric', maxlength: 2, placeholder: '0', enterkeyhint: 'next' });
    f.input.addEventListener('input', function () {
      var clean = f.input.value.replace(/\D/g, '').slice(0, 2);
      if (clean !== f.input.value) f.input.value = clean;
    });
    return f;
  }

  function openLoad(opts) {
    opts = opts || {};
    var editing = opts.extraId ? report.getExtra(opts.extraId) : null;
    if (opts.extraId && !editing) return;
    var mode = editing ? 'extras' : (opts.mode || 'hours');
    var sheet = null, saved = false, touched = false;

    var dateF = ui.field({ label: 'Fecha', type: 'date', value: editing ? editing.date : (opts.date || view.today) });
    var hoursF = digitsField('Horas'), minF = digitsField('Minutos');
    var descF = ui.field({ label: 'Descripción', multiline: true, rows: 2, maxlength: report.MAX_TEXT, placeholder: 'Ej.: Reunión de capacitación', value: editing ? editing.text : '' });
    var counter = h('span', { class: 'num' }, '0 / ' + report.MAX_TEXT);
    var sumLabel = h('div', { class: 'rp-sumrow-label' }), sumVal = h('div', { class: 'rp-sumrow-val' });
    var replaceNote = h('p', { class: 'rp-count', style: { paddingTop: '0' } });
    var banner = h('div', { class: 'rp-banner', role: 'note' }, h('span', { html: MS.icon('info', 20) }),
      h('span', null, h('b', null, 'No suman a la meta del mes.'), ' Quedan anotadas como asignación aprobada.'));
    var studyEl = h('div', { class: 'study-block' });
    var study = { on: false, picks: {}, notes: {}, error: '' };

    function iso() { return dateF.value || view.today; }
    function readNum(f, max, msg) {
      var raw = f.input.value.trim();
      var n = raw === '' ? 0 : parseInt(raw, 10);
      if (!(n >= 0 && n <= max)) { f.setError(msg); return null; }
      return n;
    }
    function total() {
      var hh = parseInt(hoursF.input.value, 10) || 0, mm = parseInt(minF.input.value, 10) || 0;
      return hh * 60 + mm;
    }
    function setTotal(m) {
      hoursF.input.value = m > 0 ? String(Math.floor(m / 60)) : '';
      minF.input.value = m > 0 ? String(m % 60) : '';
    }
    /** Lo que ya había cargado ese día (en «Horas del mes») se muestra de entrada; el total que se guarda lo reemplaza. */
    function prefill() {
      if (touched) return;
      if (editing) setTotal(editing.m);
      else if (mode === 'hours') setTotal(report.minutesOn(iso()));
      else setTotal(0);
    }
    function updateSummary() {
      var t = total();
      sumLabel.textContent = mode === 'hours' ? 'Suma a la meta' : 'No suma a la meta';
      sumVal.textContent = dur(t);
      var prev = report.minutesOn(iso());
      var show = mode === 'hours' && prev > 0 && t !== prev;
      replaceNote.hidden = !show;
      replaceNote.textContent = show ? 'Ese día ya había ' + dur(prev) + ' cargadas: se reemplazan por este total.' : '';
      counter.textContent = descF.value.length + ' / ' + report.MAX_TEXT;
    }

    /* ----- estudio: lista de personas y notas ----- */
    function existingStudies() { return store.studyVisits(iso()); }
    function candidates() {
      var done = {};
      existingStudies().forEach(function (e) { done[e.person.id] = 1; });
      return store.people.filter(function (p) { return p.stage === 'estudio' && !done[p.id]; }).sort(byName);
    }
    function noteField(p) {
      if (!study.notes[p.id]) study.notes[p.id] = ui.field({ label: 'Nota de la visita con ' + p.name, multiline: true, rows: 2, placeholder: 'Qué se estudió, qué quedó pendiente… (opcional)' });
      return study.notes[p.id];
    }
    function renderStudy() {
      var ex = existingStudies(), cands = candidates();
      // Las personas elegidas que ya no son opción (p. ej. al cambiar la fecha) se descartan.
      Object.keys(study.picks).forEach(function (id) { if (!cands.some(function (p) { return p.id === id; })) delete study.picks[id]; });
      studyEl.textContent = '';
      if (ex.length) {
        studyEl.append(h('div', { class: 'study-done' }, ex.map(function (e) {
          return h('div', { class: 'study-done-item' }, h('span', { html: MS.icon('check', 18) }), h('span', null, h('b', null, e.person.name), ' · ya está en su ficha'));
        })));
      }
      var sw = ui.switchRow({
        title: ex.length ? 'Agregar otro estudio' : 'Hice un estudio este día', sub: 'Elegir de la lista de estudios', icon: 'book', checked: study.on,
        onChange: function (v) { study.on = v; study.error = ''; renderStudy(); if (v) setTimeout(function () { ui.keepVisible(studyEl); }, 30); }
      });
      studyEl.append(sw.el);
      if (!study.on) return;
      var body = h('div', { class: 'study-body' }), fields = [];
      if (!cands.length) {
        body.append(h('p', { class: 'study-none' }, store.people.some(function (p) { return p.stage === 'estudio'; })
          ? 'Todas las personas en la etapa Estudio ya tienen una visita registrada ese día.'
          : 'Todavía no hay personas en la etapa Estudio. Cambie la etapa desde la ficha de la persona (en Personas o en el mapa) y aparecerá acá.'));
      } else {
        body.append(h('div', { class: 'study-label' }, '¿Con quién?'));
        var chips = h('div', { class: 'pchips', role: 'group', 'aria-label': 'Personas con estudio' });
        cands.forEach(function (p) {
          var on = !!study.picks[p.id];
          chips.appendChild(h('button', { type: 'button', class: 'pchip ripple' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false', dataset: { id: p.id },
            onclick: function () { study.picks[p.id] = !study.picks[p.id]; if (!study.picks[p.id]) delete study.picks[p.id]; study.error = ''; renderStudy(); } },
            h('span', { class: 'pc-av', 'aria-hidden': 'true' }, initials(p.name)),
            h('span', { class: 'pc-ck', html: MS.icon('check', 18) }),
            h('span', { class: 'pc-name' }, p.name)));
        });
        body.append(chips);
        cands.filter(function (p) { return study.picks[p.id]; }).forEach(function (p) {
          var f = noteField(p);
          body.append(h('div', { class: 'study-note' }, f.el));
          fields.push(f);
        });
        if (study.error) body.append(h('p', { class: 'study-none', role: 'alert', style: { fontWeight: '700' } }, study.error));
      }
      studyEl.append(body);
      fields.forEach(function (f) { f.value = f.value; });       // recalcula la altura de cada cuadro ya dibujado
    }

    /* ----- modo: horas del mes / horas extras ----- */
    function applyMode() {
      var extras = mode === 'extras';
      banner.hidden = !extras;
      descWrap.hidden = !extras;
      studyEl.hidden = extras;
      MS.$$('.seg', segEl).forEach(function (b) {
        var on = b.dataset.mode === mode;
        b.classList.toggle('on', on);
        b.setAttribute('aria-checked', on ? 'true' : 'false');
      });
      prefill();
      updateSummary();
    }
    var segEl = h('div', { class: 'segmented', role: 'radiogroup', 'aria-label': 'Tipo de horas' });
    [{ id: 'hours', label: 'Horas del mes' }, { id: 'extras', label: 'Horas extras' }].forEach(function (o) {
      var b = h('button', { type: 'button', class: 'seg ripple', role: 'radio', 'aria-checked': 'false', dataset: { mode: o.id } },
        h('span', { class: 'seg-ic', html: MS.icon('check', 18) }), h('span', null, o.label));
      b.addEventListener('click', function () { if (mode === o.id) return; mode = o.id; applyMode(); });
      segEl.appendChild(b);
    });
    var descWrap = h('div', null, descF.el, h('div', { class: 'rp-count' }, h('span', null, 'Una línea corta alcanza'), counter));

    [hoursF, minF].forEach(function (f) { f.input.addEventListener('input', function () { touched = true; updateSummary(); }); });
    descF.input.addEventListener('input', updateSummary);
    var onDate = function () { prefill(); renderStudy(); updateSummary(); };
    dateF.input.addEventListener('change', onDate);
    dateF.input.addEventListener('input', onDate);

    /* ----- guardar ----- */
    function save() {
      var day = iso();
      if (!MS.parseISO(day)) { dateF.setError('Elija una fecha válida.'); return; }
      var hh = readNum(hoursF, 24, 'Las horas van de 0 a 24.');
      if (hh == null) { hoursF.input.focus(); return; }
      var mm = readNum(minF, 59, 'Los minutos van de 0 a 59.');
      if (mm == null) { minF.input.focus(); return; }
      var t = hh * 60 + mm;
      if (t > report.MAX_DAY) { hoursF.setError('Un día no puede pasar de 24 h.'); hoursF.input.focus(); return; }

      if (mode === 'extras') {
        if (t <= 0) { hoursF.setError('Ingrese las horas o los minutos.'); hoursF.input.focus(); return; }
        saved = true;
        view.ym = MS.monthKey(day); view.day = day;              // la vista pasa al día guardado antes del redibujado
        if (editing) {
          var before = { date: editing.date, m: editing.m, text: editing.text };
          report.updateExtra(editing.id, { date: day, m: t, text: descF.value });
          sheet.close(true).then(function () { ui.snack('Asignación actualizada', { action: { label: 'Deshacer', onClick: function () { report.updateExtra(editing.id, before); } } }); });
        } else {
          var x = report.addExtra({ date: day, m: t, text: descF.value });
          sheet.close(true).then(function () { ui.snack('Asignación aprobada guardada: ' + dur(t), { action: { label: 'Deshacer', onClick: function () { if (x) report.removeExtra(x.id); } } }); });
        }
        return;
      }

      var picks = study.on ? Object.keys(study.picks).filter(function (id) { return study.picks[id]; }) : [];
      if (study.on && !picks.length && candidates().length) {
        study.error = 'Elija con quién fue el estudio, o apague «Hice un estudio este día».';
        renderStudy();
        ui.keepVisible(studyEl);
        return;
      }
      var prev = report.minutesOn(day);
      if (t === prev && !picks.length) {
        if (t === 0) { hoursF.setError('Ingrese las horas y los minutos, o elija un estudio.'); hoursF.input.focus(); return; }
        saved = true;
        sheet.close(true);                                       // sin cambios
        return;
      }
      view.ym = MS.monthKey(day); view.day = day;
      if (t !== prev) report.setMinutes(day, t);
      var created = [];
      picks.forEach(function (pid) {
        var f = study.notes[pid], n = store.addNote(pid, { date: day, time: '', text: f ? f.value : '', study: true });
        if (n) created.push({ pid: pid, nid: n.id, name: store.getPerson(pid).name });
      });
      saved = true;

      var msg = [];
      if (t !== prev) msg.push(t ? 'Horas guardadas: ' + dur(t) : 'Horas del día quitadas');
      if (created.length === 1) msg.push('estudio con ' + created[0].name + ' agregado a su ficha');
      else if (created.length > 1) msg.push(created.length + ' estudios agregados a sus fichas');
      var text = msg.join(' · ');
      text = text.charAt(0).toUpperCase() + text.slice(1);
      sheet.close(true).then(function () {
        ui.snack(text, { duration: 6000, action: { label: 'Deshacer', onClick: function () {
          created.forEach(function (c) { store.removeNote(c.pid, c.nid); });
          if (t !== prev) report.setMinutes(day, prev);
        } } });
      });
    }

    function dirty() {
      if (touched || Object.keys(study.picks).length > 0) return true;
      if (editing) return descF.value !== editing.text || dateF.value !== editing.date;
      return !!descF.value.trim();
    }

    var actions = h('div', { class: 'sheet-actions sticky' },
      editing ? ui.button({ variant: 'text', danger: true, label: 'Eliminar', icon: 'delete', class: 'rp-del', onClick: function () {
        var snap = report.removeExtra(editing.id);
        if (!snap) return;
        saved = true;
        sheet.close(true).then(function () { ui.snack('Asignación eliminada', { action: { label: 'Deshacer', onClick: function () { report.restoreExtra(snap); } } }); });
      } }) : null,
      ui.button({ variant: 'text', label: 'Cancelar', onClick: function () { sheet.close(); } }),
      ui.button({ variant: 'filled', label: 'Guardar', icon: 'check', type: 'submit' }));

    var title = editing ? 'Asignación aprobada' : 'Cargar horas';
    var form = h('form', { class: 'sheet-form load-sheet', novalidate: true, onsubmit: function (e) { e.preventDefault(); save(); } },
      ui.sheetHead(title, function () { sheet.close(); }),
      editing ? null : segEl,
      banner,
      dateF.el,
      h('div', { class: 'field-row' }, hoursF.el, minF.el),
      descWrap,
      studyEl,
      replaceNote,
      h('div', { class: 'rp-sumrow' }, sumLabel, sumVal),
      actions);

    applyMode();
    renderStudy();
    updateSummary();
    sheet = ui.openSheet({
      title: title, content: form,
      beforeClose: function () {
        if (saved || !dirty()) return true;
        return ui.dialog({ title: '¿Descartar lo que cargó?', text: 'Se perderán los datos que ingresó.', confirmLabel: 'Descartar', cancelLabel: 'Seguir editando', danger: true });
      }
    });
  }

  /* =====================================================================
   * Pantalla
   * ===================================================================== */
  function renderHead() {
    el.monthLabel.firstChild.textContent = MS.monthLabel(view.ym);
    el.monthNow.hidden = isCurrent();
    el.monthLabel.setAttribute('aria-label', MS.monthLabel(view.ym) + (isCurrent() ? '' : '. Tocar para volver al mes actual'));
    MS.$$('.seg', el.seg).forEach(function (b) {
      var on = b.dataset.mode === view.mode;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
  }
  function renderBody() {
    el.body.textContent = '';
    el.body.append(view.mode === 'calendar' ? calendar() : summary());
  }
  function syncFab() { if (el.fab) el.fab.classList.toggle('compact', el.scroll.scrollTop > 24); }
  function render() {
    if (!el.body) return;
    syncToday();
    var keep = el.scroll.scrollTop;
    renderHead();
    renderBody();
    el.scroll.scrollTop = keep;
    syncFab();
  }
  function setMonth(ym) {
    if (ym === view.ym) return;
    view.ym = ym;
    view.day = null;
    el.scroll.scrollTop = 0;
    render();
  }
  function setMode(mode) {
    if (view.mode === mode) return;
    view.mode = mode;
    el.scroll.scrollTop = 0;
    render();
  }

  function build(container) {
    view.today = today();
    view.ym = MS.monthKey(view.today);

    el.monthPrev = ui.iconButton({ icon: 'chevron-left', label: 'Mes anterior', onClick: function () { setMonth(MS.addMonths(view.ym, -1)); } });
    el.monthNext = ui.iconButton({ icon: 'chevron', label: 'Mes siguiente', onClick: function () { setMonth(MS.addMonths(view.ym, 1)); } });
    el.monthNow = h('span', { class: 'rp-month-now' }, 'Ir a hoy');
    el.monthLabel = h('button', { type: 'button', class: 'rp-month-label', onclick: function () { if (!isCurrent()) setMonth(MS.monthKey(view.today)); } },
      document.createTextNode(''), el.monthNow);
    el.seg = h('div', { class: 'segmented rp-seg', role: 'tablist', 'aria-label': 'Vista de Mi informe' });
    [{ id: 'summary', label: 'Resumen' }, { id: 'calendar', label: 'Calendario' }].forEach(function (o) {
      var b = h('button', { type: 'button', class: 'seg ripple', role: 'tab', 'aria-selected': 'false', dataset: { mode: o.id } },
        h('span', { class: 'seg-ic', html: MS.icon('check', 18) }), h('span', null, o.label));
      b.addEventListener('click', function () { setMode(o.id); });
      el.seg.appendChild(b);
    });
    el.body = h('div', { class: 'rp-body' });
    el.scroll = h('div', { class: 'list-scroll rp-scroll' }, el.body);
    el.fab = h('button', { type: 'button', class: 'fab fab-ext ripple', 'aria-label': 'Cargar horas', onclick: function () {
      openLoad({ date: view.mode === 'calendar' ? ensureDay() : (isCurrent() ? view.today : view.ym + '-01') });
    } }, h('span', { html: MS.icon('add', 24) }), h('span', { class: 'fab-label' }, 'Cargar horas'));
    el.scroll.addEventListener('scroll', syncFab, { passive: true });

    var top = h('header', { class: 'topbar rp-topbar' },
      h('div', { class: 'topbar-row' },
        h('h1', { class: 'topbar-title' }, 'Mi informe'),
        ui.iconButton({ icon: 'settings', label: 'Ajustes', onClick: function () { MS.settings.open(); } })),
      h('div', { class: 'rp-month' }, el.monthPrev, el.monthLabel, el.monthNext),
      el.seg);
    container.append(top, el.scroll, el.fab);
    report.on('change', function () { if (view.visible) render(); });
    render();
  }

  MS.views = MS.views || {};
  MS.views.report = {
    build: build,
    render: render,
    openLoad: openLoad,
    setVisible: function (v) { view.visible = v; if (v) render(); },
    refresh: function () { if (view.visible) render(); }
  };

})(window.MS = window.MS || {});
