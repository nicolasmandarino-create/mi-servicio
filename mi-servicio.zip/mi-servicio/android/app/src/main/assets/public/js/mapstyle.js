/* Mi Servicio – estilo del mapa (claro / oscuro) sobre el esquema OpenMapTiles.
 * La estructura de capas viene de mapbase.js; aquí se aplican las paletas, los nombres en español
 * y algunas capas extra (usos del suelo, bordes de calles, números de puerta). */
(function (MS) {
  'use strict';

  var PAL = {
    light: {
      bg: '#f2f0ea', park: '#d2e6c6', wood: '#c8deb8', residential: '#ebe8df',
      grass: '#dbe8d0', farmland: '#e8ebd8', sand: '#efe6cc', wetland: '#d4e5de',
      cemetery: '#d3e3ca', sport: '#cde2c0', school: '#ece3d1', hospital: '#f0dcd8', industrial: '#e6e2d8', commercial: '#ece8dc',
      water: '#a9cbe4', waterway: '#9cc1dc', building: '#e0dacd', buildingLine: '#cbc4b5', path: '#bdb6a7',
      minor: '#ffffff', minorCasing: '#d5d0c3', majorInner: '#ffffff', majorCasing: '#c2bcad',
      primaryInner: '#fde8b0', primaryCasing: '#dcbf7c', motorInner: '#fbd88b', motorCasing: '#d9a74a',
      rail: '#bdb8ad', railDash: '#f5f3ee', boundary: '#a49fb7', ice: '#fafafa', aeroway: '#e4e0d4', aerowayRunway: '#ffffff',
      text: '#45433d', textStrong: '#1f1d19', halo: 'rgba(255,255,255,0.92)', waterText: '#3b6b9c', house: '#6d685d'
    },
    dark: {
      bg: '#1b1d21', park: '#1e2c23', wood: '#1a271f', residential: '#202328',
      grass: '#1f2c24', farmland: '#212a24', sand: '#2b2a25', wetland: '#1d2b2b',
      cemetery: '#202d25', sport: '#22302a', school: '#25292d', hospital: '#2c2527', industrial: '#23262b', commercial: '#25282d',
      water: '#10293e', waterway: '#15344f', building: '#2b2e35', buildingLine: '#383c44', path: '#5a606b',
      minor: '#3b4048', minorCasing: '#141619', majorInner: '#4b515b', majorCasing: '#111316',
      primaryInner: '#6d5e3b', primaryCasing: '#141619', motorInner: '#86713c', motorCasing: '#141619',
      rail: '#4e545d', railDash: '#262a30', boundary: '#6d6a82', ice: '#2b2e35', aeroway: '#262a30', aerowayRunway: '#3b4048',
      text: '#c5c9d0', textStrong: '#e9ecf1', halo: 'rgba(19,21,24,0.92)', waterText: '#78a8d6', house: '#9ba1ab'
    }
  };

  // Nombre en español si existe; si no, el nombre en inglés o el local.
  var NAME = ['coalesce', ['get', 'name:es'], ['get', 'name_en'], ['get', 'name']];

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function baseUrl() { return new URL('./', document.baseURI).href; }

  function build(theme) {
    var dark = theme === 'dark';
    var P = dark ? PAL.dark : PAL.light;
    var layers = clone(MS.baseLayers);
    var byId = {};
    layers.forEach(function (l) { byId[l.id] = l; });

    function paint(id, props) {
      var l = byId[id];
      if (l) l.paint = Object.assign(l.paint || {}, props);
    }
    function indexOf(id) {
      for (var i = 0; i < layers.length; i++) if (layers[i].id === id) return i;
      return -1;
    }
    function insertAfter(id, layer) { var i = indexOf(id); layers.splice(i < 0 ? layers.length : i + 1, 0, layer); byId[layer.id] = layer; }
    function insertBefore(id, layer) { var i = indexOf(id); layers.splice(i < 0 ? layers.length : i, 0, layer); byId[layer.id] = layer; }

    /* ----- colores de las capas existentes ----- */
    paint('background', { 'background-color': P.bg });
    paint('park', { 'fill-color': P.park });
    paint('water', { 'fill-color': P.water });
    paint('landcover_ice_shelf', { 'fill-color': P.ice });
    paint('landcover_glacier', { 'fill-color': P.ice });
    paint('landuse_residential', { 'fill-color': P.residential });
    paint('landcover_wood', { 'fill-color': P.wood });
    paint('waterway', { 'line-color': P.waterway });
    paint('building', { 'fill-color': P.building, 'fill-outline-color': P.buildingLine });
    paint('tunnel_motorway_casing', { 'line-color': P.majorCasing });
    paint('tunnel_motorway_inner', { 'line-color': P.minor, 'line-opacity': 0.7 });
    paint('aeroway-taxiway', { 'line-color': P.aeroway });
    paint('aeroway-runway-casing', { 'line-color': P.aeroway });
    paint('aeroway-area', { 'fill-color': P.aeroway });
    paint('aeroway-runway', { 'line-color': P.aerowayRunway });
    paint('road_area_pier', { 'fill-color': P.bg });
    paint('road_pier', { 'line-color': P.bg });
    paint('highway_path', { 'line-color': P.path, 'line-opacity': 1, 'line-dasharray': [2, 1.5] });
    paint('highway_minor', { 'line-color': P.minor, 'line-opacity': 1 });
    paint('highway_major_casing', { 'line-color': P.majorCasing });
    paint('highway_major_inner', { 'line-color': P.majorInner });
    paint('highway_major_subtle', { 'line-color': P.majorCasing, 'line-opacity': 0.6 });
    ['highway_motorway_casing', 'highway_motorway_bridge_casing'].forEach(function (id) { paint(id, { 'line-color': P.motorCasing }); });
    ['highway_motorway_inner', 'highway_motorway_bridge_inner'].forEach(function (id) { paint(id, { 'line-color': P.motorInner }); });
    paint('highway_motorway_subtle', { 'line-color': P.motorInner, 'line-opacity': 0.8 });
    ['railway', 'railway_transit', 'railway_service'].forEach(function (id) { paint(id, { 'line-color': P.rail }); });
    ['railway_dashline', 'railway_transit_dashline', 'railway_service_dashline'].forEach(function (id) { paint(id, { 'line-color': P.railDash }); });
    ['boundary_3', 'boundary_2', 'boundary_disputed'].forEach(function (id) { paint(id, { 'line-color': P.boundary }); });

    /* ----- etiquetas: nombres en español, colores y halos legibles ----- */
    layers.forEach(function (l) {
      if (l.type !== 'symbol') return;
      var lay = l.layout || (l.layout = {});
      var pnt = l.paint || (l.paint = {});
      if (lay['text-field'] && /"name(_en)?"/.test(JSON.stringify(lay['text-field']))) lay['text-field'] = NAME;
      if (/shield/.test(l.id)) return; // los escudos de ruta conservan su diseño
      var water = /^water/.test(l.id);
      var strong = /^label_(city|country|village|town)/.test(l.id);
      pnt['text-color'] = water ? P.waterText : (strong ? P.textStrong : P.text);
      pnt['text-halo-color'] = P.halo;
      pnt['text-halo-width'] = Math.max(pnt['text-halo-width'] || 0, 1.3);
      pnt['text-halo-blur'] = 0.5;
      // En el tema oscuro los puntos negros de las ciudades no se verían: se quitan.
      if (dark && lay['icon-image'] && /^label_/.test(l.id)) {
        ['icon-image', 'icon-size', 'icon-allow-overlap', 'icon-optional', 'text-offset'].forEach(function (k) { delete lay[k]; });
        lay['text-anchor'] = 'center';
      }
    });
    ['highway-name-path', 'highway-name-minor', 'highway-name-major'].forEach(function (id) {
      if (byId[id]) byId[id].layout['text-size'] = ['interpolate', ['linear'], ['zoom'], 12, 10, 15, 12, 18, 15];
    });

    /* ----- capas extra ----- */
    var SRC = 'openmaptiles';
    insertAfter('park', {
      id: 'landuse_other', type: 'fill', source: SRC, 'source-layer': 'landuse', minzoom: 11,
      filter: ['match', ['get', 'class'], ['cemetery', 'pitch', 'playground', 'stadium', 'track', 'school', 'university', 'college', 'kindergarten', 'hospital', 'industrial', 'railway', 'quarry', 'commercial'], true, false],
      paint: {
        'fill-color': ['match', ['get', 'class'],
          'cemetery', P.cemetery,
          ['pitch', 'playground', 'stadium', 'track'], P.sport,
          ['school', 'university', 'college', 'kindergarten'], P.school,
          'hospital', P.hospital,
          ['industrial', 'railway', 'quarry'], P.industrial,
          'commercial', P.commercial,
          P.bg],
        'fill-opacity': ['interpolate', ['linear'], ['zoom'], 11, 0, 13, 1]
      }
    });
    insertAfter('park', {
      id: 'landcover_grass', type: 'fill', source: SRC, 'source-layer': 'landcover', minzoom: 8,
      filter: ['match', ['get', 'class'], ['grass', 'farmland', 'sand', 'wetland'], true, false],
      paint: {
        'fill-color': ['match', ['get', 'class'], 'grass', P.grass, 'farmland', P.farmland, 'sand', P.sand, 'wetland', P.wetland, P.bg],
        'fill-opacity': ['interpolate', ['linear'], ['zoom'], 8, 0, 10, 1]
      }
    });

    // Borde de las calles menores (mejora el contraste del plano)
    if (byId.highway_minor) {
      var cas = clone(byId.highway_minor);
      cas.id = 'highway_minor_casing';
      cas.minzoom = 13;
      cas.paint = {
        'line-color': P.minorCasing,
        'line-width': ['interpolate', ['exponential', 1.55], ['zoom'], 13, 2.8, 20, 23]
      };
      insertBefore('highway_minor', cas);
    }
    // Rutas principales y troncales con color propio (por encima de las secundarias)
    if (byId.highway_major_casing && byId.highway_major_inner) {
      var geom = byId.highway_major_casing.filter[1];
      var prim = ['all', geom, ['match', ['get', 'class'], ['primary', 'trunk'], true, false]];
      var pc = clone(byId.highway_major_casing);
      pc.id = 'highway_primary_casing'; pc.filter = prim; pc.paint['line-color'] = P.primaryCasing;
      var pi = clone(byId.highway_major_inner);
      pi.id = 'highway_primary_inner'; pi.filter = prim; pi.paint['line-color'] = P.primaryInner;
      insertAfter('highway_major_casing', pc);
      insertAfter('highway_major_inner', pi);
    }

    // Números de puerta (útil para ubicar viviendas al acercar el mapa)
    layers.push({
      id: 'housenumber', type: 'symbol', source: SRC, 'source-layer': 'housenumber', minzoom: 17,
      layout: {
        'text-field': ['to-string', ['get', 'housenumber']],
        'text-font': ['Noto Sans Regular'],
        'text-size': ['interpolate', ['linear'], ['zoom'], 17, 9, 20, 13],
        'text-padding': 2
      },
      paint: { 'text-color': P.house, 'text-halo-color': P.halo, 'text-halo-width': 1.2 }
    });

    var base = baseUrl();
    return {
      version: 8,
      name: 'Mi Servicio (' + theme + ')',
      glyphs: base + 'fonts/{fontstack}/{range}.pbf',
      sprite: base + 'sprites/ofm',
      sources: {
        openmaptiles: {
          type: 'vector',
          tiles: ['ms://{z}/{x}/{y}'],
          minzoom: 0,
          maxzoom: MS.MAP.tileMaxZoom,
          attribution: MS.MAP.attribution
        }
      },
      layers: layers
    };
  }

  MS.mapStyle = { build: build, palette: function (t) { return PAL[t] || PAL.light; } };

})(window.MS = window.MS || {});
