/* Mi Servicio – vistas: alta de persona, ficha con historial y lista de personas */
(function (MS) {
  'use strict';

  var h = MS.h, ui = MS.ui, store = MS.store;

  function nextFrame() {
    return new Promise(function (r) { requestAnimationFrame(function () { requestAnimationFrame(r); }); });
  }
  var sheetHead = ui.sheetHead;
  function coordsLine(lat, lng) {
    return h('p', { class: 'coords' }, h('span', { html: MS.icon('place', 16) }), MS.formatCoords(lat, lng));
  }
  /** Línea «Ubicación actual, precisión ±8 m» del alta con GPS; si la precisión es baja, suma un consejo. */
  function gpsLine(acc) {
    var G = MS.GPS, m = Math.max(1, Math.round(acc || 0));
    var vague = acc > G.vagueAcc, low = acc > G.warnAcc;
    var tip = vague
      ? 'Es muy aproximada: active la «ubicación precisa» de la app en los ajustes del teléfono, o toque el punto exacto en el mapa.'
      : low ? 'Si puede, acérquese a un lugar abierto o toque el punto exacto en el mapa.' : '';
    return h('p', { class: 'coords gps-acc' + (low ? ' low' : '') },
      h('span', { html: MS.icon(low ? 'warning' : 'my-location', 16) }),
      h('span', null, 'Ubicación actual, precisión ±' + m + ' m.', tip ? h('span', { class: 'gps-tip' }, ' ' + tip) : null));
  }

  /** Aviso del alta por dirección: la ubicación sale de un buscador y puede no ser exacta. */
  function approxLine() {
    return h('p', { class: 'coords gps-acc' },
      h('span', { html: MS.icon('info', 16) }),
      h('span', null, 'Ubicación obtenida de la dirección: puede ser aproximada. Verifique el pin en el mapa; si no es el lugar exacto, cierre y toque el punto en el mapa.'));
  }

  /** Campo "Territorio" (número del 1 al 99, opcional). Solo admite dígitos; read() valida y devuelve { ok, value }. */
  function territoryField(value) {
    var f = ui.field({ label: 'Territorio (1 a 99)', value: value ? String(value) : '', inputmode: 'numeric', maxlength: 2, enterkeyhint: 'next' });
    f.input.addEventListener('input', function () {
      var clean = f.input.value.replace(/\D/g, '').slice(0, 2);
      if (clean !== f.input.value) f.input.value = clean;
    });
    f.read = function () {
      var t = f.input.value.trim();
      if (!t) return { ok: true, value: null };
      var n = parseInt(t, 10);
      if (!(n >= 1 && n <= 99)) { f.setError('Ingrese un número del 1 al 99.'); return { ok: false, value: null }; }
      return { ok: true, value: n };
    };
    return f;
  }
  /** Interruptor «Fue un estudio»: la visita cuenta en Mi informe (en ese día) además de figurar en el historial. */
  function studySwitch(checked) {
    return ui.switchRow({ title: 'Fue un estudio', sub: 'Aparece en Mi informe ese día', icon: 'book', checked: checked, class: 'study-switch' });
  }
  /** Fila de dos campos (fecha + hora). */
  function dateTimeRow(dateF, timeF) {
    return h('div', { class: 'field-row' }, dateF.el, timeF.el);
  }
  /** "mar 24 nov 2026, 14:05" (sin la hora si no se conoce). */
  function whenText(n) {
    var t = store.noteTime(n);
    return MS.formatDate(n.date) + (t ? ', ' + t : '');
  }
  /** Etiqueta "Territorio 33" (ficha y listado). */
  function territoryChip(n) {
    return h('span', { class: 'terr-chip' }, h('span', { html: MS.icon('tag', 14) }), 'Territorio ' + n);
  }

  /**
   * "No en casa": se fue a ver a la persona y no se la encontró. Queda en el historial con la fecha y la hora de ahora
   * (con "Deshacer"). Un doble toque seguido no registra dos veces.
   */
  var lastNoHomeTap = { id: null, at: 0 };
  function markNoHome(personId, opts) {
    opts = opts || {};
    var now = Date.now();
    if (lastNoHomeTap.id === personId && now - lastNoHomeTap.at < 1500) return null;
    lastNoHomeTap = { id: personId, at: now };
    var n = store.addNote(personId, { kind: 'nohome', date: opts.date || MS.todayISO(), time: opts.time != null ? opts.time : MS.nowTime(), text: opts.text || '' });
    if (!n) return null;
    MS.vibrate(12);
    ui.snack('Registrado: no estaba en casa (' + whenText(n) + ')', {
      action: { label: 'Deshacer', onClick: function () { store.removeNote(personId, n.id); } }
    });
    return n;
  }

  /**
   * Texto para compartir una persona (WhatsApp, mensajes…): nombre, enlace de la ubicación en Maps, descripción de la casa,
   * territorio, fecha de la última visita (sin las notas; un «No en casa» no cuenta como visita y se indica aparte) y categoría.
   * Lo que no se cargó no aparece.
   */
  function visitText(p) {
    var seen = store.lastRealVisit(p), last = store.lastRecord(p), lines = [];
    lines.push('Nombre: ' + p.name);
    lines.push('Ubicación: ' + MS.mapsPinUrl(p.lat, p.lng));
    if (p.ref) lines.push('Descripción de la casa: ' + p.ref);
    if (p.territory) lines.push('Territorio: ' + p.territory);
    if (seen) lines.push('Última visita: ' + MS.formatDate(seen.date));
    if (last && store.isNoHome(last)) lines.push('No estaba en casa: ' + MS.formatDate(last.date));
    lines.push('Categoría: ' + MS.stageById(p.stage).label);
    return lines.join('\n');
  }

  /* =====================================================================
   * Alta de persona (hoja inferior modal con pin temporal)
   * ===================================================================== */
  function openNewPerson(pos) {
    var stage = 'primera', saved = false, sheet = null;
    MS.mapCtl.showTempPin(pos.lng, pos.lat, stage);

    var nameF = ui.field({ label: 'Nombre', required: true, autocapitalize: 'words', maxlength: 120, enterkeyhint: 'next' });
    var refF = ui.field({ label: 'Dirección / Referencia', placeholder: 'Ej.: Casa portón verde', value: pos.ref || '', maxlength: 200, enterkeyhint: 'next' });
    var terrF = territoryField();
    var chips = ui.stageChips(stage, function (v) {
      stage = v; MS.mapCtl.setTempStage(v); MS.vibrate(8);
      if (studyF.el.hidden === (v === 'estudio')) { studyF.el.hidden = v !== 'estudio'; if (v === 'estudio') studyF.set(true); }
    }, 'Categoría de visita');
    var dateF = ui.field({ label: 'Fecha de la visita', type: 'date', value: MS.todayISO() });
    var timeF = ui.field({ label: 'Hora', type: 'time', value: MS.nowTime() });
    var noteF = ui.field({ label: 'Nota de la visita', multiline: true, rows: 2, placeholder: 'Qué se conversó, qué quedó pendiente…' });
    // Si la persona se carga directamente como estudio, la primera visita cuenta como estudio (se puede destildar).
    var studyF = studySwitch(true);
    studyF.el.hidden = true;

    function dirty() {
      return !!(nameF.value.trim() || terrF.value.trim() || noteF.value.trim() || refF.value.trim() !== (pos.ref || '').trim());
    }

    function save() {
      var name = nameF.value.trim();
      if (!name) {
        nameF.setError('Ingrese el nombre de la persona.');
        nameF.input.focus();
        return;
      }
      var terr = terrF.read();
      if (!terr.ok) { terrF.input.focus(); return; }
      store.addPerson({
        name: name, ref: refF.value, territory: terr.value, stage: stage, lat: pos.lat, lng: pos.lng,
        date: dateF.value || MS.todayISO(), time: timeF.value, text: noteF.value,
        study: stage === 'estudio' ? studyF.checked : undefined
      });
      saved = true;
      sheet.close(true).then(function () { ui.snack('Persona guardada'); });
    }

    var form = h('form', { class: 'sheet-form', novalidate: true, onsubmit: function (e) { e.preventDefault(); save(); } },
      sheetHead('Nueva persona', function () { sheet.close(); }, { sub: h('div', { class: 'coords-block' }, coordsLine(pos.lat, pos.lng), pos.gps ? gpsLine(pos.acc) : null, pos.source === 'address' ? approxLine() : null) }),
      nameF.el,
      refF.el,
      terrF.el,
      h('div', { class: 'form-label' }, 'Categoría de visita'),
      chips.el,
      dateTimeRow(dateF, timeF),
      noteF.el,
      studyF.el,
      h('div', { class: 'sheet-actions sticky' },
        ui.button({ variant: 'text', label: 'Cancelar', onClick: function () { sheet.close(); } }),
        ui.button({ variant: 'filled', label: 'Guardar', icon: 'check', type: 'submit' }))
    );

    sheet = ui.openSheet({
      title: 'Nueva persona', content: form, soft: true, compact: true,
      beforeClose: function () {
        if (saved || !dirty()) return true;
        return ui.dialog({
          title: '¿Descartar esta persona?', text: 'Se perderán los datos que ingresó.',
          confirmLabel: 'Descartar', cancelLabel: 'Seguir editando', danger: true
        });
      },
      onClose: function () { MS.mapCtl.clearTempPin(); MS.mapCtl.resetPadding(); }
    });
    nextFrame().then(function () { MS.mapCtl.focusAbove(pos.lng, pos.lat, sheet.height(), pos.zoom || (pos.gps ? 17 : 0)); });
  }

  /* =====================================================================
   * Ficha de la persona: datos, etapa, nueva nota e historial
   * ===================================================================== */
  function openDetail(id, opts) {
    opts = opts || {};
    if (!store.getPerson(id)) return;
    MS.mapCtl.setSelected(id);

    var sheet = null, unsub = null;
    var state = { editing: false, editNoteId: null, adding: null };
    function person() { return store.getPerson(id); }

    var headEl = h('div', { class: 'detail-head' });
    var actionsEl = h('div', { class: 'detail-actions' });
    var stageEl = h('section', { class: 'detail-section' });
    var visitEl = h('section', { class: 'detail-section visit-bar' });
    var historyEl = h('section', { class: 'detail-section' });
    var footEl = h('div', { class: 'detail-foot' });

    /* ----- cabecera (datos y edición) ----- */
    function renderHeader() {
      var p = person(); if (!p) return;
      var st = MS.stageById(p.stage);
      headEl.textContent = '';
      if (!state.editing) {
        headEl.setAttribute('data-sheet-drag', '');
        headEl.append(
          h('div', { class: 'avatar', dataset: { stage: p.stage }, html: MS.icon(st.icon, 24) }),
          h('div', { class: 'head-text' },
            h('h2', { class: 'sheet-title' }, p.name),
            p.ref ? h('p', { class: 'head-sub' }, p.ref) : h('p', { class: 'head-sub muted' }, 'Sin dirección ni referencia'),
            p.territory ? h('p', { class: 'head-terr' }, territoryChip(p.territory)) : null),
          ui.iconButton({ icon: 'edit', label: 'Editar datos', onClick: function () { state.editing = true; renderHeader(); } }),
          ui.iconButton({ icon: 'close', label: 'Cerrar', onClick: function () { sheet.close(); } })
        );
      } else {
        headEl.removeAttribute('data-sheet-drag');
        var nf = ui.field({ label: 'Nombre', value: p.name, required: true, autocapitalize: 'words', maxlength: 120 });
        var rf = ui.field({ label: 'Dirección / Referencia', value: p.ref, maxlength: 200 });
        var tf = territoryField(p.territory);
        var saveEdit = function () {
          if (!nf.value.trim()) { nf.setError('Ingrese el nombre de la persona.'); nf.input.focus(); return; }
          var terr = tf.read();
          if (!terr.ok) { tf.input.focus(); return; }
          state.editing = false;
          store.updatePerson(id, { name: nf.value, ref: rf.value, territory: terr.value });
          ui.snack('Datos actualizados');
        };
        headEl.append(h('form', { class: 'edit-person', novalidate: true, onsubmit: function (e) { e.preventDefault(); saveEdit(); } },
          nf.el, rf.el, tf.el,
          h('div', { class: 'sheet-actions' },
            ui.button({ variant: 'text', label: 'Cancelar', onClick: function () { state.editing = false; renderHeader(); } }),
            ui.button({ variant: 'filled', label: 'Guardar', icon: 'check', type: 'submit' }))));
      }
    }

    /* ----- botones de acción: Ir / Maps y Ver en el mapa ----- */
    function renderActions() {
      var p = person(); if (!p) return;
      actionsEl.textContent = '';
      actionsEl.appendChild(ui.button({ variant: 'filled', label: 'Ir / Maps', icon: 'directions', onClick: function () { MS.openMaps(person().lat, person().lng); } }));
      if (opts.fromList) {
        actionsEl.appendChild(ui.button({ variant: 'tonal', label: 'Ver en el mapa', icon: 'map', onClick: function () {
          sheet.close().then(function (ok) { if (ok) MS.app.showOnMap(id); });
        } }));
      }
    }

    /* ----- etapa (selector rápido) ----- */
    var chipsApi = null;
    function renderStage() {
      var p = person(); if (!p) return;
      content.dataset.stage = p.stage;
      if (chipsApi) { chipsApi.set(p.stage); return; }
      stageEl.textContent = '';
      chipsApi = ui.stageChips(p.stage, function (v) {
        store.updatePerson(id, { stage: v });       // el marcador cambia de color al instante
      }, 'Etapa de la persona');
      stageEl.append(h('h3', { class: 'section-title' }, 'Etapa'), chipsApi.el);
    }

    /* ----- «No en casa» y «Nueva visita»: el formulario solo se abre al tocar «Nueva visita» ----- */
    function renderVisit() {
      visitEl.textContent = '';
      if (state.adding) { visitEl.append(state.adding.form); return; }
      visitEl.append(h('div', { class: 'visit-actions' },
        ui.button({ variant: 'tonal', label: 'No en casa', icon: 'door', class: 'btn-nohome', onClick: function () { markNoHome(id); } }),
        ui.button({ variant: 'filled', label: 'Nueva visita', icon: 'add', class: 'btn-newvisit', onClick: openAdd })));
    }
    function closeAdd() { state.adding = null; renderVisit(); }
    function openAdd() {
      var dateF = ui.field({ label: 'Fecha', type: 'date', value: MS.todayISO() });
      var timeF = ui.field({ label: 'Hora', type: 'time', value: MS.nowTime() });
      var textF = ui.field({ label: 'Detalle de la visita', multiline: true, rows: 3, placeholder: 'Qué se conversó, qué quedó pendiente… (opcional)' });
      // Con la persona en la etapa Estudio, la visita cuenta como estudio (y aparece en Mi informe) salvo que se destilde.
      var studyF = studySwitch(true);
      studyF.el.hidden = person().stage !== 'estudio';
      var form = h('form', { class: 'add-note', novalidate: true, onsubmit: function (e) {
        e.preventDefault();
        var isStudy = person().stage === 'estudio';
        // El detalle es opcional: sin texto, la visita queda solo con su fecha y hora.
        store.addNote(id, { date: dateF.value || MS.todayISO(), time: timeF.value, text: textF.value, study: isStudy ? studyF.checked : undefined });
        closeAdd();
        ui.snack(isStudy && studyF.checked ? 'Visita agregada al historial y a Mi informe' : 'Visita agregada al historial');
      } },
        h('h3', { class: 'section-title' }, 'Nueva visita'),
        dateTimeRow(dateF, timeF),
        textF.el,
        studyF.el,
        h('div', { class: 'sheet-actions' },
          ui.button({ variant: 'text', label: 'Cancelar', onClick: closeAdd }),
          ui.button({ variant: 'filled', label: 'Guardar visita', icon: 'check', type: 'submit' })));
      state.adding = { form: form, textF: textF, studyF: studyF };
      renderVisit();
      try { textF.input.focus({ preventScroll: true }); } catch (e) { /* nada */ }
    }

    /* ----- historial cronológico ----- */
    function noteItem(p, n) {
      var nohome = store.isNoHome(n);
      var li = h('li', { class: 'note' + (nohome ? ' nohome' : ''), dataset: { id: n.id } });
      li.append(h('div', { class: 'note-rail', 'aria-hidden': 'true' }, h('span', { class: 'note-dot' })));
      var body = h('div', { class: 'note-body' });
      li.append(body);

      if (state.editNoteId === n.id) {
        var df = ui.field({ label: 'Fecha', type: 'date', value: n.date });
        var hf = ui.field({ label: 'Hora', type: 'time', value: store.noteTime(n) });
        var tf = ui.field({ label: nohome ? 'Comentario (opcional)' : 'Nota', multiline: true, rows: nohome ? 2 : 3, value: n.text });
        // «Fue un estudio»: se ofrece en las visitas de personas en la etapa Estudio y en las que ya estaban marcadas.
        var sf = !nohome && (p.stage === 'estudio' || store.isStudy(n)) ? studySwitch(store.isStudy(n)) : null;
        body.append(h('form', { class: 'note-edit', novalidate: true, onsubmit: function (e) {
          e.preventDefault();
          state.editNoteId = null;
          store.updateNote(id, n.id, { date: df.value || n.date, time: hf.value, text: tf.value, study: sf ? sf.checked : undefined });
        } },
          dateTimeRow(df, hf), tf.el, sf ? sf.el : null,
          h('div', { class: 'sheet-actions' },
            ui.button({ variant: 'text', label: 'Cancelar', onClick: function () { state.editNoteId = null; renderHistory(); } }),
            ui.button({ variant: 'filled', label: 'Guardar', icon: 'check', type: 'submit' }))));
        return li;
      }
      MS.put(body,
        h('div', { class: 'note-top' },
          h('div', { class: 'note-when' },
            h('span', { class: 'note-date' }, MS.formatDate(n.date)),
            store.noteTime(n) ? h('span', { class: 'note-time' }, h('span', { html: MS.icon('clock', 16) }), store.noteTime(n)) : null,
            h('span', { class: 'note-rel' }, MS.relativeDate(n.date)),
            store.isStudy(n) ? h('span', { class: 'note-study', title: 'Cuenta en Mi informe' }, h('span', { html: MS.icon('book', 14) }), 'Estudio') : null),
          h('div', { class: 'note-actions' },
            ui.iconButton({ icon: 'edit', label: nohome ? 'Editar registro' : 'Editar nota', size: 20, onClick: function () { state.editNoteId = n.id; renderHistory(); } }),
            ui.iconButton({ icon: 'delete', label: nohome ? 'Eliminar registro' : 'Eliminar nota', size: 20, onClick: function () { removeNote(n.id); } }))),
        nohome ? h('p', { class: 'note-nohome' }, h('span', { html: MS.icon('door', 18) }), 'No en casa') : null,
        n.text ? h('p', { class: 'note-text' }, n.text) : null
      );
      return li;
    }
    function removeNote(noteId) {
      var snap = store.removeNote(id, noteId);
      if (!snap) return;
      ui.snack(store.isNoHome(snap.note) ? 'Registro eliminado' : 'Nota eliminada', { action: { label: 'Deshacer', onClick: function () { store.restoreNote(id, snap); } } });
    }
    function renderHistory() {
      var p = person(); if (!p) return;
      var order = store.getSetting('notesOrder') === 'asc' ? 'asc' : 'desc';
      var notes = store.sortedNotes(p, order);
      historyEl.textContent = '';
      var toggle = h('button', { type: 'button', class: 'text-toggle ripple', 'aria-label': 'Cambiar el orden del historial', onclick: function () {
        store.setSetting('notesOrder', order === 'desc' ? 'asc' : 'desc');
        renderHistory();
      } }, h('span', { html: MS.icon('swap', 18) }), order === 'desc' ? 'Más recientes primero' : 'Más antiguas primero');
      historyEl.append(
        h('div', { class: 'section-row' },
          h('h3', { class: 'section-title' }, 'Historial de visitas', h('span', { class: 'count' }, String(notes.length))),
          notes.length > 1 ? toggle : null),
        notes.length ? h('ol', { class: 'timeline' }, notes.map(function (n) { return noteItem(p, n); }))
          : h('p', { class: 'muted' }, 'Todavía no hay visitas registradas.')
      );
    }

    /* ----- compartir y eliminar persona ----- */
    function shareVisit() {
      var p = person(); if (!p) return;
      MS.shareText({ title: 'Visita a ' + p.name, text: visitText(p), dialogTitle: 'Compartir visita' }).then(function (r) {
        if (r === 'copied') ui.snack('No se pudo abrir el menú para compartir: el texto quedó copiado. Péguelo donde quiera enviarlo.', { duration: 6000 });
        else if (r === 'error') ui.snack('No se pudo compartir la visita.');
      });
    }
    function renderFoot() {
      footEl.textContent = '';
      footEl.append(ui.button({ variant: 'tonal', label: 'Compartir visita', icon: 'share', class: 'btn-share', onClick: shareVisit }));
      footEl.append(ui.button({ variant: 'text', danger: true, label: 'Eliminar persona', icon: 'delete', onClick: function () {
        var p = person(); if (!p) return;
        ui.dialog({
          title: '¿Eliminar a ' + p.name + '?',
          text: 'Se borrarán también ' + (p.notes.length === 1 ? 'su único registro' : 'sus ' + p.notes.length + ' registros') + ' del historial.',
          confirmLabel: 'Eliminar', danger: true
        }).then(function (ok) {
          if (!ok) return;
          sheet.close(true).then(function () {
            var snap = store.removePerson(id);
            if (snap) ui.snack('Persona eliminada', { action: { label: 'Deshacer', onClick: function () { store.restorePerson(snap); } } });
          });
        });
      } }));
    }

    var content = h('div', { class: 'detail' }, headEl, coordsLine(person().lat, person().lng), actionsEl, stageEl, visitEl, historyEl, footEl);
    renderHeader(); renderActions(); renderStage(); renderVisit(); renderHistory(); renderFoot();

    sheet = ui.openSheet({
      title: 'Ficha de ' + person().name, content: content, className: 'sheet-detail', soft: !opts.fromList, compact: !opts.fromList,
      beforeClose: function () {
        // Si hay un detalle escrito que todavía no se guardó, se pregunta antes de cerrar.
        if (!state.adding || !state.adding.textF.value.trim()) return true;
        return ui.dialog({
          title: '¿Descartar la visita?', text: 'Se perderá el detalle que escribió.',
          confirmLabel: 'Descartar', cancelLabel: 'Seguir editando', danger: true
        });
      },
      onClose: function () {
        if (unsub) unsub();
        MS.mapCtl.setSelected(null);
        MS.mapCtl.resetPadding();
      }
    });
    unsub = store.on('change', function (e) {
      if (e.type !== 'bulk' && e.id !== id) return;
      if (!person()) { sheet.close(true); return; }
      if (!state.editing) renderHeader();
      renderStage();
      renderHistory();
      // Si se cambia la etapa con el formulario de visita abierto, el interruptor aparece (o se oculta) en el acto.
      if (state.adding && state.adding.studyF) {
        var isEst = person().stage === 'estudio', sw = state.adding.studyF;
        if (sw.el.hidden === isEst) { sw.el.hidden = !isEst; if (isEst) sw.set(true); }
      }
    });
    var p0 = person();
    nextFrame().then(function () { if (!opts.fromList) MS.mapCtl.focusAbove(p0.lng, p0.lat, sheet.height(), 15); });
    return sheet;
  }

  /* =====================================================================
   * Pestaña "Personas": lista, búsqueda en tiempo real y filtros por etapa
   * ===================================================================== */
  var People = (function () {
    var state = { q: '', stage: 'all' };
    /** Órdenes de la lista (el orden de esta tabla es el de la hoja «Ordenar personas»). */
    var SORTS = [
      { id: 'added', label: 'Más recientes', desc: 'Las últimas agregadas, primero.' },
      { id: 'name', label: 'A–Z', desc: 'Por orden alfabético del nombre.' },
      { id: 'lastvisit', label: 'Últimas visitas', desc: 'Primero la visita más reciente.' },
      { id: 'most', label: 'Más visitadas', desc: 'De más a menos visitas.' },
      { id: 'fewest', label: 'Menos visitadas', desc: 'De menos a más visitas.' }
    ];
    function sortInfo(id) {
      for (var i = 0; i < SORTS.length; i++) if (SORTS[i].id === id) return SORTS[i];
      return SORTS[2];
    }
    /** Hoja con las formas de ordenar; al elegir una se aplica y se cierra. */
    function openSortSheet() {
      var current = sortInfo(store.getSetting('peopleSort')).id, sheet = null;
      var list = h('div', { class: 'sort-list', role: 'radiogroup', 'aria-label': 'Orden de la lista' }, SORTS.map(function (o) {
        var on = o.id === current;
        return h('button', {
          type: 'button', class: 'sort-opt ripple' + (on ? ' on' : ''), role: 'radio', 'aria-checked': on ? 'true' : 'false', dataset: { sort: o.id },
          onclick: function () { store.setSetting('peopleSort', o.id); sheet.close(true); render(); }
        },
          h('span', { class: 'sort-radio', html: MS.icon(on ? 'radio-on' : 'radio-off', 24) }),
          h('span', { class: 'sort-text' }, h('span', { class: 'sort-name' }, o.label), h('span', { class: 'sort-desc' }, o.desc)));
      }));
      sheet = ui.openSheet({
        title: 'Ordenar personas', compact: true,
        content: h('div', { class: 'sort-pick' }, sheetHead('Ordenar personas', function () { sheet.close(); }), list,
          h('p', { class: 'muted sort-note' }, 'Un «No en casa» no cuenta como visita.'))
      });
    }
    var el = {};
    var visible = false;

    function normChar(c) { return c.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); }
    /** Resalta (sin tildes ni mayúsculas) las palabras buscadas dentro de un texto. */
    function highlight(text, tokens) {
      text = text || '';
      if (!tokens.length || !text) return document.createTextNode(text);
      var norm = '', map = [], i, k;
      for (i = 0; i < text.length; i++) {
        var n = normChar(text[i]);
        for (k = 0; k < n.length; k++) { norm += n[k]; map.push(i); }
      }
      var marks = [];
      for (i = 0; i < text.length; i++) marks.push(false);
      tokens.forEach(function (t) {
        var from = 0, idx;
        while ((idx = norm.indexOf(t, from)) >= 0) {
          for (var j = idx; j < idx + t.length; j++) marks[map[j]] = true;
          from = idx + t.length;
        }
      });
      var frag = document.createDocumentFragment(), buf = '', on = false;
      function flush() {
        if (!buf) return;
        frag.appendChild(on ? h('mark', null, buf) : document.createTextNode(buf));
        buf = '';
      }
      for (i = 0; i < text.length; i++) {
        if (marks[i] !== on) { flush(); on = marks[i]; }
        buf += text[i];
      }
      flush();
      return frag;
    }
    function build(container) {
      el.search = h('input', { class: 'search-input', type: 'search', placeholder: 'Buscar por nombre o territorio', 'aria-label': 'Buscar personas por nombre o territorio', autocomplete: 'off', enterkeyhint: 'search' });
      el.clear = ui.iconButton({ icon: 'close', label: 'Borrar búsqueda', size: 20, class: 'search-clear', onClick: function () { el.search.value = ''; state.q = ''; render(); el.search.focus(); } });
      el.clear.hidden = true;
      el.filters = h('div', { class: 'filters', role: 'radiogroup', 'aria-label': 'Filtrar por etapa' });
      el.count = h('span', { class: 'list-count' });
      el.sortBtn = h('button', { type: 'button', class: 'text-toggle ripple btn-sort', 'aria-haspopup': 'dialog', onclick: openSortSheet });
      el.list = h('ul', { class: 'cards' });
      el.empty = h('div', { class: 'empty' });
      el.scroll = h('div', { class: 'list-scroll' }, el.list, el.empty);

      var top = h('header', { class: 'topbar' },
        h('div', { class: 'topbar-row' },
          h('h1', { class: 'topbar-title' }, 'Personas'),
          ui.iconButton({ icon: 'settings', label: 'Ajustes', onClick: function () { MS.settings.open(); } })),
        h('label', { class: 'searchbar' }, h('span', { class: 'search-ic', html: MS.icon('search', 22) }), el.search, el.clear),
        el.filters,
        h('div', { class: 'list-meta' }, el.count, el.sortBtn));
      container.append(top, el.scroll);

      var onSearch = MS.debounce(function () { state.q = el.search.value; render(); }, 60);
      el.search.addEventListener('input', function () { el.clear.hidden = !el.search.value; onSearch(); });

      el.list.addEventListener('click', function (e) {
        var card = e.target.closest('.card');
        if (!card) return;
        var pid = card.dataset.id;
        if (e.target.closest('.go-maps')) {
          var p = store.getPerson(pid);
          if (p) MS.openMaps(p.lat, p.lng);
          return;
        }
        if (e.target.closest('.go-nohome')) { markNoHome(pid); return; }
        openDetail(pid, { fromList: true });
      });
      el.list.addEventListener('keydown', function (e) {
        if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('card')) {
          e.preventDefault();
          openDetail(e.target.dataset.id, { fromList: true });
        }
      });
    }

    function renderFilters() {
      var counts = store.countByStage();
      el.filters.textContent = '';
      var opts = [{ id: 'all', label: 'Todas', icon: null }].concat(MS.STAGES);
      opts.forEach(function (o) {
        var b = h('button', { type: 'button', class: 'chip ripple' + (state.stage === o.id ? ' on' : ''), role: 'radio', 'aria-checked': state.stage === o.id ? 'true' : 'false', dataset: { stage: o.id } });
        b.innerHTML = (state.stage === o.id && o.id === 'all' ? '<span class="chip-ic">' + MS.icon('check', 18) + '</span>' : (o.icon ? '<span class="chip-ic">' + MS.icon(o.icon, 18) + '</span>' : '')) +
          '<span>' + MS.esc(o.label) + '</span><span class="chip-count">' + (counts[o.id] || 0) + '</span>';
        b.addEventListener('click', function () { state.stage = o.id; render(); });
        el.filters.appendChild(b);
      });
    }

    function card(item, tokens) {
      var p = item.person, st = MS.stageById(p.stage), last = store.lastVisit(p);
      var nVisits = store.visitCount(p), nohome = store.noHomeInfo(p);
      var visits = nVisits + (nVisits === 1 ? ' visita' : ' visitas');
      return h('li', { class: 'card ripple', dataset: { id: p.id, stage: p.stage }, tabindex: '0', role: 'button',
        'aria-label': p.name + ', ' + st.label + (p.territory ? ', territorio ' + p.territory : '') + (nohome ? ', no estaba en casa la última vez' : '') },
        h('div', { class: 'card-main' },
          h('div', { class: 'avatar', html: MS.icon(st.icon, 24) }),
          h('div', { class: 'card-text' },
            h('div', { class: 'card-top' },
              h('div', { class: 'card-title' }, highlight(p.name, tokens)),
              last ? h('span', { class: 'card-when', title: MS.formatDate(last) }, MS.relativeDate(last)) : null),
            p.ref ? h('div', { class: 'card-sub' }, h('span', { class: 'sub-ic', html: MS.icon('place', 16) }), h('span', { class: 'sub-text' }, p.ref)) : null,
            h('div', { class: 'card-meta' },
              h('span', { class: 'tag' }, st.label),
              p.territory ? territoryChip(p.territory) : null,
              h('span', { class: 'visits' }, h('span', { html: MS.icon('history', 16) }), visits),
              nohome ? h('span', { class: 'nohome-chip', title: 'Última vez: ' + MS.formatDate(nohome.date) },
                h('span', { html: MS.icon('door', 14) }), nohome.count > 1 ? 'No estaba en casa ×' + nohome.count : 'No estaba en casa') : null))),
        h('div', { class: 'card-actions' },
          ui.button({ variant: 'text', label: 'No en casa', icon: 'door', class: 'go-nohome sm' }),
          ui.button({ variant: 'tonal', label: 'Ir / Maps', icon: 'directions', class: 'go-maps sm' }))
      );
    }
    function render() {
      if (!el.list) return;
      var tokens = store.parseQuery(state.q).words;   // lo que se resalta en el nombre
      var results = store.search(state.q, state.stage);
      var total = store.people.length;
      renderFilters();
      el.count.textContent = (results.length === total ? total : results.length + ' de ' + total) + (total === 1 ? ' persona' : ' personas');
      el.sortBtn.innerHTML = MS.icon('swap', 18) + 'Orden: ' + MS.esc(sortInfo(store.getSetting('peopleSort')).label);
      el.list.textContent = '';
      results.forEach(function (it) { el.list.appendChild(card(it, tokens)); });

      el.empty.textContent = '';
      el.empty.hidden = results.length > 0;
      if (!results.length) {
        if (!total) {
          el.empty.append(
            h('div', { class: 'empty-ic', html: MS.icon('pin-drop', 48) }),
            h('h2', null, 'Aún no hay personas registradas'),
            h('p', null, 'Toque cualquier punto del mapa para registrar a la primera persona, o cárguela por dirección desde Ajustes.'),
            ui.button({ variant: 'filled', label: 'Ir al mapa', icon: 'map', onClick: function () { MS.app.showTab('map'); } }));
        } else {
          el.empty.append(
            h('div', { class: 'empty-ic', html: MS.icon('search', 48) }),
            h('h2', null, 'Sin resultados'),
            h('p', null, 'Pruebe con otro nombre o con el número de territorio, o cambie el filtro de etapa.'));
        }
      }
    }

    return {
      build: build,
      render: render,
      setVisible: function (v) { visible = v; if (v) render(); },
      refresh: function () { if (visible) render(); }
    };
  })();

  MS.views = { openNewPerson: openNewPerson, openDetail: openDetail, people: People, visitText: visitText };

})(window.MS = window.MS || {});
