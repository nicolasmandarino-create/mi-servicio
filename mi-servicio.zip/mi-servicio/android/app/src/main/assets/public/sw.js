/* Mi Servicio – service worker (solo versión web/PWA; la APK no lo registra).
 * Guarda la aplicación para abrirla sin conexión. Las teselas del mapa se guardan aparte, en IndexedDB.
 * Los marcadores entre PRECACHE-START y PRECACHE-END los genera scripts/gen-sw.mjs. */
/*PRECACHE-START*/
const VERSION = 'ms-cfe4d1c56c';
const FILES = [
 "./",
 "css/app.css",
 "css/tokens.css",
 "fonts/Noto%20Sans%20Italic/0-255.pbf",
 "fonts/Noto%20Sans%20Italic/256-511.pbf",
 "fonts/Noto%20Sans%20Italic/512-767.pbf",
 "fonts/Noto%20Sans%20Italic/7680-7935.pbf",
 "fonts/Noto%20Sans%20Italic/8192-8447.pbf",
 "fonts/Noto%20Sans%20Medium/0-255.pbf",
 "fonts/Noto%20Sans%20Medium/256-511.pbf",
 "fonts/Noto%20Sans%20Medium/512-767.pbf",
 "fonts/Noto%20Sans%20Medium/7680-7935.pbf",
 "fonts/Noto%20Sans%20Medium/8192-8447.pbf",
 "fonts/Noto%20Sans%20Regular/0-255.pbf",
 "fonts/Noto%20Sans%20Regular/256-511.pbf",
 "fonts/Noto%20Sans%20Regular/512-767.pbf",
 "fonts/Noto%20Sans%20Regular/7680-7935.pbf",
 "fonts/Noto%20Sans%20Regular/8192-8447.pbf",
 "fonts/app/atkinson-hyperlegible-next-latin-wght-normal.woff2",
 "icons/apple-touch-icon.png",
 "icons/icon-192.png",
 "icons/icon-512.png",
 "icons/icon-background.svg",
 "icons/icon-foreground.svg",
 "icons/icon-maskable-512.png",
 "icons/icon-monochrome.svg",
 "icons/icon.svg",
 "index.html",
 "js/app.js",
 "js/config.js",
 "js/db.js",
 "js/icons.js",
 "js/locate.js",
 "js/map.js",
 "js/mapbase.js",
 "js/mapstyle.js",
 "js/report-view.js",
 "js/report.js",
 "js/settings.js",
 "js/store.js",
 "js/tiles.js",
 "js/ui-core.js",
 "js/util.js",
 "js/views.js",
 "manifest.webmanifest",
 "sprites/ofm.json",
 "sprites/ofm.png",
 "sprites/ofm@2x.json",
 "sprites/ofm@2x.png",
 "vendor/maplibre-gl.css",
 "vendor/maplibre-gl.js"
];
/*PRECACHE-END*/

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(VERSION);
    await cache.addAll(FILES.map((f) => new Request(f, { cache: 'reload' })));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter((n) => n.startsWith('ms-') && n !== VERSION).map((n) => caches.delete(n)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;   // teselas y otros orígenes: los maneja la app
  event.respondWith((async () => {
    const cache = await caches.open(VERSION);
    const hit = await cache.match(req, { ignoreSearch: true });
    if (hit) return hit;
    try {
      const res = await fetch(req);
      if (res && res.ok) cache.put(req, res.clone());
      return res;
    } catch (err) {
      if (req.mode === 'navigate') {
        const shell = await cache.match('./', { ignoreSearch: true }) || await cache.match('index.html');
        if (shell) return shell;
      }
      throw err;
    }
  })());
});
