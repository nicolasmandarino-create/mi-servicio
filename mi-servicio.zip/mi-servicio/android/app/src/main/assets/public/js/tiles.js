/* Mi Servicio – teselas del mapa: caché local, modo sin conexión y descarga de zonas */
(function (MS) {
  'use strict';

  var CFG = MS.MAP;
  var OFF = CFG.offline;

  function online() { return navigator.onLine !== false; }
  function fail(code, extra) { var e = new Error(code); e.code = code; if (extra) Object.assign(e, extra); return e; }

  /* ---------- Plantilla de URL (TileJSON de OpenFreeMap; si no hay red, la última guardada) ---------- */
  var tplPromise = null;
  function resolveTemplate() {
    if (tplPromise) return tplPromise;
    tplPromise = (async function () {
      var saved = await MS.db.kv.get('tileTemplate', null);
      if (online()) {
        var ctl = new AbortController();
        var to = setTimeout(function () { ctl.abort(); }, 7000);
        try {
          var r = await fetch(CFG.tileJson, { signal: ctl.signal, mode: 'cors', credentials: 'omit' });
          if (r.ok) {
            var j = await r.json();
            if (j && j.tiles && j.tiles[0]) { MS.db.kv.set('tileTemplate', j.tiles[0]); return j.tiles[0]; }
          }
        } catch (e) { /* se usa la guardada */ }
        finally { clearTimeout(to); }
      }
      return saved || CFG.fallbackTiles;
    })();
    return tplPromise;
  }
  window.addEventListener('online', function () { tplPromise = null; });

  /* ---------- Compresión (las teselas guardadas ocupan ~3 veces menos) ---------- */
  var HAS_CS = typeof CompressionStream === 'function' && typeof DecompressionStream === 'function';
  function gzip(buf) {
    return new Response(new Blob([buf]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer();
  }
  function gunzip(buf) {
    return new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer();
  }
  /** MapLibre exige datos sin comprimir: si el servidor entrega gzip sin avisarlo, se descomprime acá. */
  async function ensurePlain(buf) {
    var u = new Uint8Array(buf, 0, Math.min(2, buf.byteLength));
    if (HAS_CS && u.length === 2 && u[0] === 0x1f && u[1] === 0x8b) {
      try { return await gunzip(buf); } catch (e) { /* se usa tal cual */ }
    }
    return buf;
  }
  async function pack(buf) {
    if (HAS_CS && buf.byteLength > 600) {
      try {
        var z = await gzip(buf);
        if (z.byteLength < buf.byteLength) return { rec: { d: z, z: 1 }, size: z.byteLength };
      } catch (e) { /* se guarda sin comprimir */ }
    }
    return { rec: { d: buf, z: 0 }, size: buf.byteLength };
  }
  function unpack(rec) { return rec.z ? gunzip(rec.d) : Promise.resolve(rec.d); }

  /* ---------- Descarga de una tesela ---------- */
  async function fetchRemote(z, x, y, signal) {
    var tpl = await resolveTemplate();
    var url = tpl.replace('{z}', z).replace('{x}', x).replace('{y}', y);
    var res = await fetch(url, { signal: signal, mode: 'cors', credentials: 'omit' });
    if (res.status === 404 || res.status === 204) return { buf: new ArrayBuffer(0), wire: 0 };
    if (!res.ok) throw new Error('HTTP ' + res.status);
    var buf = await ensurePlain(await res.arrayBuffer());
    return { buf: buf, wire: Number(res.headers.get('content-length')) || 0 };
  }
  async function fetchRetry(z, x, y, signal) {
    var last;
    for (var i = 0; i < 3; i++) {
      if (signal && signal.aborted) throw fail('aborted');
      try { return await fetchRemote(z, x, y, signal); }
      catch (e) {
        last = e;
        if (signal && signal.aborted) throw fail('aborted');
        await new Promise(function (r) { setTimeout(r, 350 * (i + 1)); });
      }
    }
    throw last;
  }

  /* ---------- Carga de teselas para el mapa (caché primero, red después) ---------- */
  var puts = 0;
  function storeAuto(key, buf) {
    pack(buf)
      .then(function (p) { return MS.db.tiles.put(key, p.rec, p.size, false); })
      .then(function () {
        if (++puts >= 80) { puts = 0; return MS.db.tiles.evict(CFG.autoCacheMaxTiles); }
      })
      .catch(function (e) { if (window.console && console.debug) console.debug('[caché]', e && e.message); /* la caché es opcional */ });
  }
  async function loadTile(z, x, y, signal) {
    var key = z + '/' + x + '/' + y;
    var rec = await MS.db.tiles.get(key);
    if (rec) return unpack(rec);
    if (!online()) throw fail('offline');
    var r = await fetchRemote(z, x, y, signal);
    // MapLibre transfiere el buffer a su worker (queda "detached"): se guarda una copia hecha antes de entregarlo.
    storeAuto(key, r.buf.slice(0));
    return r.buf;
  }

  var registered = false;
  function register(maplibregl) {
    if (registered) return;
    registered = true;
    maplibregl.addProtocol('ms', async function (params, abortController) {
      var m = /^ms:\/\/(\d+)\/(\d+)\/(\d+)/.exec(params.url);
      if (!m) throw new Error('URL de tesela inválida');
      var data = await loadTile(+m[1], +m[2], +m[3], abortController && abortController.signal);
      return { data: data };
    });
  }

  /* ---------- Matemática de teselas ---------- */
  function lon2x(lon, z) {
    var n = Math.pow(2, z);
    return MS.clamp(Math.floor((lon + 180) / 360 * n), 0, n - 1);
  }
  function lat2y(lat, z) {
    lat = MS.clamp(lat, -85.0511, 85.0511);
    var r = lat * Math.PI / 180, n = Math.pow(2, z);
    return MS.clamp(Math.floor((1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * n), 0, n - 1);
  }
  /** b = [oeste, sur, este, norte] */
  function tileRange(b, z) {
    return { x0: lon2x(b[0], z), x1: lon2x(b[2], z), y0: lat2y(b[3], z), y1: lat2y(b[1], z) };
  }
  function countTiles(b, minZ, maxZ) {
    var n = 0;
    for (var z = minZ; z <= maxZ; z++) {
      var r = tileRange(b, z);
      n += (r.x1 - r.x0 + 1) * (r.y1 - r.y0 + 1);
    }
    return n;
  }
  var AVG = { 14: 55000, 13: 45000, 12: 35000 };
  /** Tamaño aproximado (bytes) de una descarga; varía mucho entre zonas urbanas y rurales. */
  function estimateBytes(b, minZ, maxZ) {
    var bytes = 0;
    for (var z = minZ; z <= maxZ; z++) {
      var r = tileRange(b, z);
      bytes += (r.x1 - r.x0 + 1) * (r.y1 - r.y0 + 1) * (AVG[z] || 25000);
    }
    return bytes;
  }
  /** Lista ordenada: de menor a mayor zoom y, dentro de cada zoom, del centro hacia afuera. */
  function plan(b, minZ, maxZ) {
    var list = [], cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
    for (var z = minZ; z <= maxZ; z++) {
      var r = tileRange(b, z), part = [];
      var tcx = lon2x(cx, z) + 0.5, tcy = lat2y(cy, z) + 0.5;
      for (var x = r.x0; x <= r.x1; x++) {
        for (var y = r.y0; y <= r.y1; y++) {
          part.push({ z: z, x: x, y: y, key: z + '/' + x + '/' + y, d: (x + 0.5 - tcx) * (x + 0.5 - tcx) + (y + 0.5 - tcy) * (y + 0.5 - tcy) });
        }
      }
      part.sort(function (a, c) { return a.d - c.d; });
      list = list.concat(part);
    }
    return list;
  }

  /* ---------- Zonas descargadas ---------- */
  var areas = null;
  async function listAreas() {
    if (!areas) areas = await MS.db.kv.get('areas', []);
    return areas.slice();
  }
  async function saveAreas() { await MS.db.kv.set('areas', areas); }

  function inArea(a, z, x, y) {
    if (z < a.minZoom || z > a.maxZoom) return false;
    var r = tileRange(a.bounds, z);
    return x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1;
  }

  /**
   * Descarga una zona. opts = { name, bounds:[o,s,e,n] }. Respeta los límites de OpenFreeMap:
   * hasta 3000 teselas y 50 MB por descarga, 4 solicitudes en paralelo.
   * signal (AbortSignal) permite cancelar; al cancelar se revierte lo descargado.
   */
  async function downloadArea(opts, onProgress, signal) {
    if (!online()) throw fail('offline');
    var maxZ = Math.min(opts.maxZoom || OFF.maxZoom, OFF.maxZoom);
    var list = plan(opts.bounds, OFF.minZoom, maxZ);
    if (list.length > OFF.maxTiles) throw fail('too-big', { count: list.length });
    await listAreas();
    await resolveTemplate();

    var total = list.length, done = 0, bytes = 0, failed = 0, limitHit = false, idx = 0;
    var newKeys = [], pinnedExisting = [];

    async function worker() {
      while (!signal.aborted && !limitHit) {
        var i = idx++;
        if (i >= total) return;
        var t = list[i];
        try {
          var meta = await MS.db.tiles.meta(t.key);
          if (meta) {
            if (!meta.p) pinnedExisting.push(t.key);
          } else {
            var r = await fetchRetry(t.z, t.x, t.y, signal);
            var p = await pack(r.buf);
            await MS.db.tiles.put(t.key, p.rec, p.size, true);
            newKeys.push(t.key);
            bytes += r.wire || p.size;
            if (bytes >= OFF.maxBytes) limitHit = true;
          }
        } catch (e) {
          if (signal.aborted) return;
          failed++;
        }
        done++;
        if (onProgress) onProgress({ done: done, total: total, bytes: bytes, failed: failed });
      }
    }
    var workers = [];
    for (var c = 0; c < OFF.concurrency; c++) workers.push(worker());
    await Promise.all(workers);

    if (signal.aborted) {
      await MS.db.tiles.remove(newKeys);
      throw fail('aborted');
    }
    await MS.db.tiles.setPinned(pinnedExisting, true);

    var partial = limitHit || failed > Math.max(2, total * 0.03);
    var area = {
      id: MS.uid(), name: opts.name, bounds: opts.bounds,
      minZoom: OFF.minZoom, maxZoom: maxZ,
      tiles: done - failed, bytes: bytes, date: Date.now(), partial: partial
    };
    areas.push(area);
    await saveAreas();
    return { area: area, limitHit: limitHit, failed: failed };
  }

  async function removeArea(id) {
    await listAreas();
    var a = null;
    for (var i = 0; i < areas.length; i++) if (areas[i].id === id) { a = areas[i]; areas.splice(i, 1); break; }
    if (!a) return;
    await saveAreas();
    // Se borran las teselas que no pertenecen a ninguna otra zona guardada.
    var keys = plan(a.bounds, a.minZoom, a.maxZoom).filter(function (t) {
      return !areas.some(function (o) { return inArea(o, t.z, t.x, t.y); });
    }).map(function (t) { return t.key; });
    await MS.db.tiles.remove(keys);
  }

  MS.tiles = {
    register: register,
    isOnline: online,
    countTiles: countTiles,
    estimateBytes: estimateBytes,
    listAreas: listAreas,
    downloadArea: downloadArea,
    removeArea: removeArea,
    stats: function () { return MS.db.tiles.stats(); },
    clearAuto: function () { return MS.db.tiles.clearAuto(); }
  };

})(window.MS = window.MS || {});
