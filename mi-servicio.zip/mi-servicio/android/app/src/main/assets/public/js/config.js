/* Mi Servicio – configuración general */
(function (MS) {
  'use strict';

  MS.VERSION = '1.0.0';

  /** Las tres etapas de visita. Los colores son los pedidos para los marcadores. */
  MS.STAGES = [
    { id: 'primera',  label: 'Primera conversación', color: '#3b82f6', icon: 'chat' },
    { id: 'revisita', label: 'Revisita',             color: '#f59e0b', icon: 'replay' },
    { id: 'estudio',  label: 'Estudio',              color: '#10b981', icon: 'book' }
  ];
  MS.stageById = function (id) {
    for (var i = 0; i < MS.STAGES.length; i++) if (MS.STAGES[i].id === id) return MS.STAGES[i];
    return MS.STAGES[0];
  };

  /**
   * Mapa. Teselas vectoriales gratuitas de OpenFreeMap (sin clave, sin registro).
   * Las descargas sin conexión respetan los límites de https://openfreemap.org/tos/ :
   * máx. 3000 teselas y 50 MB por descarga, 4 solicitudes en paralelo,
   * iniciadas por el usuario. Para usar otro proveedor basta con cambiar estos valores.
   */
  MS.MAP = {
    tileJson: 'https://tiles.openfreemap.org/planet',
    fallbackTiles: 'https://tiles.openfreemap.org/planet/latest/{z}/{x}/{y}.pbf',
    tileMaxZoom: 14,      // zoom máximo de las teselas; más allá se sobre-escala (vectorial, sigue nítido)
    maxZoom: 19.5,
    minZoom: 2,
    attribution:
      '<a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> ' +
      '<a href="https://www.openmaptiles.org/" target="_blank" rel="noopener">&copy; OpenMapTiles</a> ' +
      'Data from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>',
    // Vista inicial si no hay ubicación ni vista guardada (Argentina)
    defaultCenter: [-63.6, -38.4],
    defaultZoom: 3.6,
    // Descarga de zonas sin conexión
    offline: {
      maxTiles: 3000,
      maxBytes: 50 * 1024 * 1024,
      concurrency: 4,
      minZoom: 0,
      maxZoom: 14
    },
    // Caché automática de teselas vistas (se eliminan las más antiguas al superar el tope)
    autoCacheMaxTiles: 1200
  };

})(window.MS = window.MS || {});
