/* Mi Servicio – configuración general */
(function (MS) {
  'use strict';

  MS.VERSION = '1.3.0';

  /** Las tres etapas de visita. Los colores son los pedidos para los marcadores. */
  MS.STAGES = [
    { id: 'primera',  label: 'Primera conversación', color: '#3b82f6', icon: 'chat' },
    { id: 'revisita', label: 'Revisita',             color: '#f59e0b', icon: 'replay' },
    { id: 'estudio',  label: 'Estudio',              color: '#10b981', icon: 'book' }
  ];
  MS.stageById = function (id) {
    for (var i = 0; i < MS.STAGES.length; i++) if (MS.STAGES[i].id === id) return MS.STAGES[i];
    return MS.STAGES[0];
  };

  /**
   * "Agregar aquí" (botón de ubicación precisa): se espera hasta tener una posición buena y se usa la mejor disponible.
   * goodAcc: precisión (m) con la que se acepta enseguida; okAcc/softMs: tras ese tiempo se acepta una posición de hasta okAcc m;
   * hardMs: tope de espera desde la primera lectura (se usa la mejor que haya, aunque sea imprecisa); noFixMs: tope si no llega ninguna;
   * minBusyMs: un segundo toque antes de ese tiempo se ignora; warnAcc/vagueAcc: umbrales de los avisos en el formulario.
   */
  MS.GPS = { goodAcc: 12, okAcc: 40, softMs: 9000, hardMs: 22000, noFixMs: 25000, minBusyMs: 1200, warnAcc: 50, vagueAcc: 300 };

  /**
   * Mapa. Teselas vectoriales gratuitas de OpenFreeMap (sin clave, sin registro).
   * Las descargas sin conexión respetan los límites de https://openfreemap.org/tos/ :
   * máx. 3000 teselas y 50 MB por descarga, 4 solicitudes en paralelo,
   * iniciadas por el usuario. Para usar otro proveedor basta con cambiar estos valores.
   */
  MS.MAP = {
    tileJson: 'https://tiles.openfreemap.org/planet',
    fallbackTiles: 'https://tiles.openfreemap.org/planet/latest/{z}/{x}/{y}.pbf',
    tileMaxZoom: 14,      // zoom máximo de las teselas; más allá se sobre-escala (vectorial, sigue nítido)
    maxZoom: 19.5,
    minZoom: 2,
    attribution:
      '<a href="https://openfreemap.org" target="_blank" rel="noopener">OpenFreeMap</a> ' +
      '<a href="https://www.openmaptiles.org/" target="_blank" rel="noopener">&copy; OpenMapTiles</a> ' +
      'Data from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>',
    // Vista inicial si no hay ubicación ni vista guardada (Argentina)
    defaultCenter: [-63.6, -38.4],
    defaultZoom: 3.6,
    // Descarga de zonas sin conexión
    offline: {
      maxTiles: 3000,
      maxBytes: 50 * 1024 * 1024,
      concurrency: 4,
      minZoom: 0,
      maxZoom: 14
    },
    // Caché automática de teselas vistas (se eliminan las más antiguas al superar el tope)
    autoCacheMaxTiles: 1200
  };

})(window.MS = window.MS || {});
