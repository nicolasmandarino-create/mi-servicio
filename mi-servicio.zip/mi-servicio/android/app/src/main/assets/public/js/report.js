/* Mi Servicio – «Mi informe»: horas por día, asignaciones aprobadas y meta mensual (100 % local).
 *
 * Las visitas a estudios NO se guardan acá: viven en la ficha de cada persona (MS.store) y «Mi informe» las lee de ahí.
 * Así hay una sola visita y una sola nota, sin importar desde dónde se cargó (mapa, Personas o Mi informe).
 *
 *   hours:  { 'AAAA-MM-DD': { m: minutos del día, u: última modificación } }   (total del día; las asignaciones no suman)
 *   extras: [ { id, date, m: minutos, text: descripción breve, createdAt, updatedAt } ]   (asignaciones aprobadas)
 *   goals:  { 'AAAA-MM': { h: 15 | 30 | 50 | 100, u } }
 *   rounds: { 'AAAA-MM': { r: 'up' | 'down', u } }   (cómo se redondearon las horas del informe de ese mes; define el arrastre al mes siguiente)
 */
(function (MS) {
  'use strict';

  var ev = MS.emitter();
  var state = { hours: {}, extras: [], goals: {}, rounds: {} };
  var saveTimer = null;
  var MAX_DAY = 24 * 60;          // un día no puede tener más de 24 h
  var MAX_TEXT = 80;              // largo de la descripción de una asignación

  /* ---------- Persistencia ---------- */
  function persistNow() {
    clearTimeout(saveTimer);
    saveTimer = null;
    var payload = { v: 1, savedAt: Date.now(), hours: state.hours, extras: state.extras, goals: state.goals, rounds: state.rounds };
    // Copia síncrona en localStorage: sobrevive si la app se cierra antes de terminar la escritura en IndexedDB.
    try { localStorage.setItem('ms:report', JSON.stringify(payload)); } catch (e) { /* sin espacio */ }
    return MS.db.kv.set('report', payload);
  }
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(persistNow, 120);
  }
  function flush() { if (saveTimer) persistNow(); }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', flush);

  /* ---------- Normalización ---------- */
  function validISO(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !!MS.parseISO(s); }
  function validMonth(s) { return typeof s === 'string' && /^\d{4}-(0[1-9]|1[0-2])$/.test(s); }
  function cleanMinutes(v) {
    var n = Math.round(Number(v));
    return isFinite(n) ? MS.clamp(n, 0, MAX_DAY) : 0;
  }
  function cleanText(v) { return (typeof v === 'string' ? v : '').replace(/\s+/g, ' ').trim().slice(0, MAX_TEXT); }

  function cleanHours(obj) {
    var out = {};
    if (!obj || typeof obj !== 'object') return out;
    Object.keys(obj).forEach(function (k) {
      var e = obj[k], m = e && cleanMinutes(e.m);
      if (validISO(k) && m > 0) out[k] = { m: m, u: Number(e.u) || 0 };
    });
    return out;
  }
  function cleanExtras(arr) {
    var seen = {}, out = [], now = Date.now();
    (Array.isArray(arr) ? arr : []).forEach(function (x) {
      if (!x || typeof x !== 'object' || !validISO(x.date)) return;
      var m = cleanMinutes(x.m);
      if (m <= 0) return;
      var id = (typeof x.id === 'string' ? x.id.slice(0, 40) : '') || MS.uid();
      if (seen[id]) return;
      seen[id] = 1;
      out.push({ id: id, date: x.date, m: m, text: cleanText(x.text), createdAt: Number(x.createdAt) || now, updatedAt: Number(x.updatedAt) || now });
    });
    return out;
  }
  function cleanGoals(obj) {
    var out = {};
    if (!obj || typeof obj !== 'object') return out;
    Object.keys(obj).forEach(function (k) {
      var e = obj[k], hrs = e && Number(e.h);
      if (validMonth(k) && MS.GOALS.indexOf(hrs) >= 0) out[k] = { h: hrs, u: Number(e.u) || 0 };
    });
    return out;
  }

  function cleanRounds(obj) {
    var out = {};
    if (!obj || typeof obj !== 'object') return out;
    Object.keys(obj).forEach(function (k) {
      var e = obj[k];
      if (validMonth(k) && e && (e.r === 'up' || e.r === 'down')) out[k] = { r: e.r, u: Number(e.u) || 0 };
    });
    return out;
  }

  function load() {
    return MS.db.kv.get('report', null).then(function (fromIdb) {
      var fromLs = null;
      try { fromLs = JSON.parse(localStorage.getItem('ms:report')); } catch (e) { /* nada */ }
      var best = null;
      [fromIdb, fromLs].forEach(function (c) {
        if (c && typeof c === 'object' && (!best || (c.savedAt || 0) > (best.savedAt || 0))) best = c;
      });
      if (best) {
        state.hours = cleanHours(best.hours);
        state.extras = cleanExtras(best.extras);
        state.goals = cleanGoals(best.goals);
        state.rounds = cleanRounds(best.rounds);
      }
      if (best && best !== fromIdb) persistNow();   // reparar IndexedDB desde la copia
      ev.emit('loaded');
    });
  }

  /* ---------- Horas del día ---------- */
  function minutesOn(iso) { var e = state.hours[iso]; return e ? e.m : 0; }
  /** Fija el total de horas de un día (reemplaza lo anterior). Con 0 minutos, el día queda sin horas. */
  function setMinutes(iso, m) {
    if (!validISO(iso)) return 0;
    m = cleanMinutes(m);
    if (m > 0) state.hours[iso] = { m: m, u: Date.now() };
    else delete state.hours[iso];
    save();
    ev.emit('change', { type: 'hours', date: iso });
    return m;
  }
  /** Minutos del mes (las asignaciones aprobadas no se suman). */
  function monthMinutes(ym) {
    var total = 0;
    Object.keys(state.hours).forEach(function (k) { if (k.slice(0, 7) === ym) total += state.hours[k].m; });
    return total;
  }
  /** { 'AAAA-MM-DD': minutos } de los días del mes que tienen horas. */
  function monthDays(ym) {
    var out = {};
    Object.keys(state.hours).forEach(function (k) { if (k.slice(0, 7) === ym) out[k] = state.hours[k].m; });
    return out;
  }

  /* ---------- Redondeo de las horas del informe y arrastre al mes siguiente ----------
   * El informe se envía con horas redondas. Al enviarlo se elige redondear hacia arriba o hacia abajo; la diferencia (con signo)
   * pasa al mes siguiente: 100 h 30 min redondeado a 101 → el mes siguiente empieza con −30 min; redondeado a 100 → empieza con +30 min.
   * Todo se calcula a partir de lo cargado (no se guarda la diferencia), así que si se corrige un día el arrastre se ajusta solo.
   * Las asignaciones aprobadas (horas extras) nunca se redondean.
   */
  /** Minutos redondeados a horas enteras. Un total que no es positivo se informa como 0. */
  function roundMin(total, dir) {
    if (total <= 0) return 0;
    return (dir === 'up' ? Math.ceil(total / 60) : Math.floor(total / 60)) * 60;
  }
  /** Lo que el mes anterior le deja a este (minutos, con signo): lo hecho menos lo informado. 0 si ese mes no se redondeó. */
  function carryIn(ym) { return carryOut(MS.addMonths(ym, -1)); }
  function carryOut(ym) {
    var r = state.rounds[ym];
    if (!r) return 0;
    var total = monthTotal(ym);
    return total - roundMin(total, r.r);
  }
  /** Total del mes (para la meta y el informe): horas cargadas + arrastre del mes anterior. */
  function monthTotal(ym) { return monthMinutes(ym) + carryIn(ym); }
  /** El arrastre que recibe un mes, para mostrarlo: { min, from: mes anterior, dir } o null si no hay. */
  function carryInfo(ym) {
    var from = MS.addMonths(ym, -1), r = state.rounds[from], min = carryIn(ym);
    return min && r ? { min: min, from: from, dir: r.r } : null;
  }
  /** Opciones de redondeo del mes: horas que se informarían y diferencia (con signo) que quedaría para el mes siguiente. */
  function roundInfo(ym) {
    var total = monthTotal(ym), cur = state.rounds[ym], up = roundMin(total, 'up'), down = roundMin(total, 'down');
    return {
      total: total,
      needsChoice: total > 0 && total % 60 !== 0,      // con horas enteras (o sin horas) no hay nada que redondear
      mode: cur ? cur.r : null,
      up: { h: up / 60, carry: total - up },
      down: { h: down / 60, carry: total - down }
    };
  }
  function getRound(ym) { var r = state.rounds[ym]; return r ? r.r : null; }
  /** Registra cómo se redondeó el informe del mes ('up' | 'down'); con otro valor, lo quita. */
  function setRound(ym, dir) {
    if (!validMonth(ym)) return false;
    if (dir === 'up' || dir === 'down') state.rounds[ym] = { r: dir, u: Date.now() };
    else delete state.rounds[ym];
    save();
    ev.emit('change', { type: 'round', month: ym });
    return true;
  }

  /* ---------- Asignaciones aprobadas ---------- */
  function sortExtras(a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : (a.createdAt || 0) - (b.createdAt || 0); }
  function getExtra(id) {
    for (var i = 0; i < state.extras.length; i++) if (state.extras[i].id === id) return state.extras[i];
    return null;
  }
  function extrasOn(iso) { return state.extras.filter(function (x) { return x.date === iso; }).sort(sortExtras); }
  function extrasInMonth(ym) { return state.extras.filter(function (x) { return x.date.slice(0, 7) === ym; }).sort(sortExtras); }
  function extrasMinutes(ym) {
    return extrasInMonth(ym).reduce(function (s, x) { return s + x.m; }, 0);
  }
  /** Personas distintas a las que se les hizo un estudio en el mes: varias visitas a la misma persona cuentan una sola vez. */
  function studyPeople(ym) {
    var last = MS.daysInMonth(ym), seen = {}, n = 0;
    MS.store.studyVisits(ym + '-01', ym + '-' + (last < 10 ? '0' : '') + last).forEach(function (e) {
      if (!seen[e.person.id]) { seen[e.person.id] = true; n++; }
    });
    return n;
  }
  function plainDur(min) { return MS.formatDuration(min).replace(/\u00a0/g, ' '); }
  /** Horas del informe: redondas (según cómo se redondeó el mes); mientras no se elija el redondeo, las horas exactas como vista previa. */
  function hoursLine(ym) {
    var i = roundInfo(ym);
    if (!i.needsChoice) return String(Math.max(0, i.total) / 60);
    return i.mode ? String(i[i.mode].h) : plainDur(i.total);
  }
  /**
   * Texto del informe del mes para enviar (WhatsApp u otro medio):
   *   INFORME: / mes y año / Horas (redondas) / Estudios (cantidad de personas, no de visitas) / Actividades teocráticas (suma de
   *   las horas extras, sin redondear; si no hay, la línea no aparece).
   */
  function reportText(ym) {
    var extra = extrasMinutes(ym);
    var lines = ['INFORME:', MS.monthLabel(ym), 'Horas: ' + hoursLine(ym), 'Estudios: ' + studyPeople(ym)];
    if (extra > 0) lines.push('Actividades teocráticas: ' + plainDur(extra));
    return lines.join('\n');
  }
  function addExtra(d) {
    var m = cleanMinutes(d.m);
    if (m <= 0) return null;
    var now = Date.now();
    var x = { id: MS.uid(), date: validISO(d.date) ? d.date : MS.todayISO(), m: m, text: cleanText(d.text), createdAt: now, updatedAt: now };
    state.extras.push(x);
    save();
    ev.emit('change', { type: 'extras', id: x.id });
    return x;
  }
  function updateExtra(id, d) {
    var x = getExtra(id);
    if (!x) return null;
    if (validISO(d.date)) x.date = d.date;
    if (d.m != null) { var m = cleanMinutes(d.m); if (m > 0) x.m = m; }
    if (typeof d.text === 'string') x.text = cleanText(d.text);
    x.updatedAt = Date.now();
    save();
    ev.emit('change', { type: 'extras', id: id });
    return x;
  }
  function removeExtra(id) {
    for (var i = 0; i < state.extras.length; i++) {
      if (state.extras[i].id === id) {
        var x = state.extras.splice(i, 1)[0];
        save();
        ev.emit('change', { type: 'extras', id: id });
        return { extra: x, index: i };
      }
    }
    return null;
  }
  function restoreExtra(snap) {
    if (!snap || getExtra(snap.extra.id)) return;
    state.extras.splice(Math.min(snap.index, state.extras.length), 0, snap.extra);
    save();
    ev.emit('change', { type: 'extras', id: snap.extra.id });
  }

  /* ---------- Meta del mes: 15, 30, 50 o 100 horas ---------- */
  /**
   * Meta de un mes: la que se eligió para ese mes o, si no se eligió ninguna, la del último mes anterior que tenga una
   * (para no tener que volver a elegirla cada mes). null si todavía no se eligió nunca.
   */
  function goalFor(ym) {
    var own = state.goals[ym];
    if (own) return { h: own.h, own: true, from: ym };
    var best = '';
    Object.keys(state.goals).forEach(function (k) { if (k < ym && k > best) best = k; });
    return best ? { h: state.goals[best].h, own: false, from: best } : null;
  }
  function setGoal(ym, hrs) {
    hrs = Number(hrs);
    if (!validMonth(ym) || MS.GOALS.indexOf(hrs) < 0) return false;
    state.goals[ym] = { h: hrs, u: Date.now() };
    save();
    ev.emit('change', { type: 'goal', month: ym });
    return true;
  }

  /**
   * Avance de un mes hacia su meta (incluye lo que arrastra del mes anterior). «today» (AAAA-MM-DD) decide cuántos días quedan: si el mes ya pasó, ninguno;
   * si todavía no empezó, todos; en el mes en curso, desde hoy inclusive. perDayMin = lo que habría que hacer cada día restante.
   */
  function progress(ym, today) {
    var g = goalFor(ym), done = monthTotal(ym), goalMin = g ? g.h * 60 : 0;
    var n = MS.daysInMonth(ym), first = ym + '-01', last = ym + '-' + (n < 10 ? '0' : '') + n;
    var daysLeft = today > last ? 0 : today < first ? n : n - Number(today.slice(8, 10)) + 1;
    var remain = Math.max(0, goalMin - done);
    return {
      goal: g, goalMin: goalMin, doneMin: done,
      remainMin: remain, overMin: Math.max(0, done - goalMin),
      pct: goalMin ? Math.max(0, Math.round(done / goalMin * 100)) : 0,
      ratio: goalMin ? Math.max(0, Math.min(1, done / goalMin)) : 0,
      reached: goalMin > 0 && done >= goalMin,
      daysLeft: daysLeft,
      perDayMin: daysLeft > 0 && remain > 0 ? Math.ceil(remain / daysLeft) : 0
    };
  }

  /* ---------- Copia de seguridad ---------- */
  function exportData() {
    return JSON.parse(JSON.stringify({ v: 1, hours: state.hours, extras: state.extras, goals: state.goals, rounds: state.rounds }));
  }
  /** mode: 'merge' (gana lo más reciente de cada día, asignación, meta y redondeo) o 'replace'. Devuelve { days, extras }. */
  function importData(obj, mode) {
    var inc = { hours: cleanHours(obj && obj.hours), extras: cleanExtras(obj && obj.extras), goals: cleanGoals(obj && obj.goals), rounds: cleanRounds(obj && obj.rounds) };
    var res = { days: Object.keys(inc.hours).length, extras: inc.extras.length };
    if (mode === 'replace') {
      state.hours = inc.hours; state.extras = inc.extras; state.goals = inc.goals; state.rounds = inc.rounds;
    } else {
      Object.keys(inc.hours).forEach(function (k) { var cur = state.hours[k]; if (!cur || inc.hours[k].u > cur.u) state.hours[k] = inc.hours[k]; });
      inc.extras.forEach(function (x) {
        var cur = getExtra(x.id);
        if (!cur) state.extras.push(x);
        else if (x.updatedAt > cur.updatedAt) Object.assign(cur, x);
      });
      Object.keys(inc.goals).forEach(function (k) { var cur = state.goals[k]; if (!cur || inc.goals[k].u > cur.u) state.goals[k] = inc.goals[k]; });
      Object.keys(inc.rounds).forEach(function (k) { var cur = state.rounds[k]; if (!cur || inc.rounds[k].u > cur.u) state.rounds[k] = inc.rounds[k]; });
    }
    persistNow();
    ev.emit('change', { type: 'bulk' });
    return res;
  }

  MS.report = {
    on: ev.on,
    load: load,
    flush: flush,
    MAX_DAY: MAX_DAY,
    MAX_TEXT: MAX_TEXT,
    minutesOn: minutesOn,
    setMinutes: setMinutes,
    monthMinutes: monthMinutes,
    monthTotal: monthTotal,
    carryIn: carryIn,
    carryInfo: carryInfo,
    roundInfo: roundInfo,
    getRound: getRound,
    setRound: setRound,
    monthDays: monthDays,
    getExtra: getExtra,
    extrasOn: extrasOn,
    extrasInMonth: extrasInMonth,
    extrasMinutes: extrasMinutes,
    studyPeople: studyPeople,
    reportText: reportText,
    addExtra: addExtra,
    updateExtra: updateExtra,
    removeExtra: removeExtra,
    restoreExtra: restoreExtra,
    goalFor: goalFor,
    setGoal: setGoal,
    progress: progress,
    exportData: exportData,
    importData: importData
  };

})(window.MS = window.MS || {});
