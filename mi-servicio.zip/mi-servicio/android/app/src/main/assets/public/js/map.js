/* Mi Servicio – controlador del mapa (MapLibre): marcadores, pin temporal y ubicación */
(function (MS) {
  'use strict';

  var ev = MS.emitter();
  var map = null;
  var container = null;
  var markers = {};          // id -> { marker, el }
  var tempMarker = null;
  var userMarker = null;
  var selectedId = null;
  var userPos = null;        // { lng, lat, acc }
  var watchId = null;
  var pendingFly = false;
  var followFirstFix = false;
  var theme = 'light';
  var tapTimer = null;
  var EMPTY = { type: 'FeatureCollection', features: [] };

  var PIN_PATH = 'M20 2C10.6 2 3 9.5 3 18.8c0 12.6 14.2 29 16.1 31.1.5.6 1.3.6 1.8 0C22.8 47.8 37 31.4 37 18.8 37 9.5 29.4 2 20 2z';
  function pinSvg() {
    return '<svg class="pin-shape" viewBox="0 0 40 52" width="40" height="52" aria-hidden="true"><path d="' + PIN_PATH + '"/></svg>';
  }

  /* ---------- Marcadores de personas ---------- */
  function makePinEl(p) {
    var el = MS.h('div', { class: 'pin', role: 'button', tabindex: '0' });
    el.innerHTML = '<div class="pin-body">' + pinSvg() + '<span class="pin-ic"></span><span class="pin-badge" aria-hidden="true">' + MS.icon('door-fill', 12) + '</span><span class="pin-label"></span></div>';
    paintPin(el, p);
    var open = function (e) { e.stopPropagation(); ev.emit('select', p.id); };
    el.addEventListener('click', open);
    el.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(e); } });
    return el;
  }
  function paintPin(el, p) {
    var st = MS.stageById(p.stage);
    var nohome = !!MS.store.noHomeInfo(p);          // la última vez no se la encontró: el marcador lo indica con una puerta
    el.dataset.stage = st.id;
    el.classList.toggle('nohome', nohome);
    el.setAttribute('aria-label', p.name + ' – ' + st.label + (nohome ? ' – no estaba en casa la última vez' : ''));
    el.querySelector('.pin-ic').innerHTML = MS.icon(st.icon, 18);
    el.querySelector('.pin-label').textContent = p.name;
  }
  function upsert(p, animate) {
    var m = markers[p.id];
    if (!m) {
      var el = makePinEl(p);
      if (animate) el.classList.add('drop');
      var mk = new maplibregl.Marker({ element: el, anchor: 'bottom' }).setLngLat([p.lng, p.lat]).addTo(map);
      markers[p.id] = { marker: mk, el: el };
      if (p.id === selectedId) el.classList.add('selected');
    } else {
      var changed = m.el.dataset.stage !== p.stage;
      paintPin(m.el, p);
      m.marker.setLngLat([p.lng, p.lat]);
      if (changed) restartClass(m.el, 'pop', 600);
    }
  }
  function restartClass(el, cls, ms) {
    el.classList.remove(cls);
    void el.offsetWidth;          // reinicia la animación
    el.classList.add(cls);
    setTimeout(function () { el.classList.remove(cls); }, ms);
  }
  /** Resalta un marcador un instante (se usa al llegar desde la lista). */
  function ping(id) {
    var m = markers[id];
    if (m) restartClass(m.el, 'ping', 2400);
  }
  function remove(id) {
    var m = markers[id];
    if (m) { m.marker.remove(); delete markers[id]; }
    if (selectedId === id) selectedId = null;
  }
  function syncAll(people) {
    var ids = {};
    people.forEach(function (p) { ids[p.id] = 1; upsert(p, false); });
    Object.keys(markers).forEach(function (id) { if (!ids[id]) remove(id); });
  }
  function setSelected(id) {
    if (selectedId && markers[selectedId]) markers[selectedId].el.classList.remove('selected');
    selectedId = id || null;
    if (selectedId && markers[selectedId]) markers[selectedId].el.classList.add('selected');
  }

  /* ---------- Pin temporal (alta de persona) ---------- */
  function paintTempPin(el, stageId) {
    var st = MS.stageById(stageId), ic = el.querySelector('.pin-ic');
    el.dataset.stage = st.id;
    ic.innerHTML = MS.icon(st.icon, 18);
    restartClass(ic, 'swap', 320);
  }
  function showTempPin(lng, lat, stageId) {
    clearTempPin();
    var el = MS.h('div', { class: 'pin pin-temp' });
    el.innerHTML = '<span class="pin-ring"></span><div class="pin-body">' + pinSvg() + '<span class="pin-ic"></span></div>';
    paintTempPin(el, stageId);
    tempMarker = new maplibregl.Marker({ element: el, anchor: 'bottom' }).setLngLat([lng, lat]).addTo(map);
    MS.vibrate(12);
  }
  /** El pin temporal toma el color e ícono de la categoría elegida en el formulario. */
  function setTempStage(stageId) {
    if (tempMarker) paintTempPin(tempMarker.getElement(), stageId);
  }
  function clearTempPin() {
    if (tempMarker) { tempMarker.remove(); tempMarker = null; }
  }

  /* ---------- Cámara ---------- */
  /** Centra un punto en la zona visible por encima de una hoja inferior de `sheetPx` de alto. */
  function focusAbove(lng, lat, sheetPx, minZoom) {
    if (!map) return;
    var pad = MS.clamp(Math.round(sheetPx), 0, Math.round(window.innerHeight * 0.7));
    var z = Math.max(map.getZoom(), minZoom || 0);
    map.easeTo({ center: [lng, lat], zoom: z, padding: { top: 0, left: 0, right: 0, bottom: pad }, duration: 400 });
  }
  function resetPadding() {
    if (!map) return;
    var p = map.getPadding();
    if (p.bottom || p.top) map.easeTo({ padding: { top: 0, left: 0, right: 0, bottom: 0 }, duration: 300 });
  }
  function flyTo(lng, lat, zoom) {
    if (!map) return;
    map.flyTo({ center: [lng, lat], zoom: zoom, essential: true, speed: 1.5, padding: { top: 0, left: 0, right: 0, bottom: 0 } });
  }
  function flyToPerson(id) {
    var p = MS.store.getPerson(id);
    if (p) flyTo(p.lng, p.lat, Math.max(map ? map.getZoom() : 0, 16.5));
  }
  function fitBoundsArray(b) {
    if (map) map.fitBounds([[b[0], b[1]], [b[2], b[3]]], { padding: 30, duration: 800, maxZoom: 14 });
  }
  function getBounds() {
    var b = map.getBounds();
    return [b.getWest(), b.getSouth(), b.getEast(), b.getNorth()];
  }

  /* ---------- Ubicación del dispositivo ---------- */
  function circle(lng, lat, r) {
    var pts = [], d = r / 6378137, la = lat * Math.PI / 180, lo = lng * Math.PI / 180;
    for (var i = 0; i <= 48; i++) {
      var b = 2 * Math.PI * i / 48;
      var la2 = Math.asin(Math.sin(la) * Math.cos(d) + Math.cos(la) * Math.sin(d) * Math.cos(b));
      var lo2 = lo + Math.atan2(Math.sin(b) * Math.sin(d) * Math.cos(la), Math.cos(d) - Math.sin(la) * Math.sin(la2));
      pts.push([lo2 * 180 / Math.PI, la2 * 180 / Math.PI]);
    }
    return { type: 'Feature', properties: {}, geometry: { type: 'Polygon', coordinates: [pts] } };
  }
  function applyUserAcc() {
    var src = map && map.getSource && map.getSource('user-acc');
    if (!src) return;
    src.setData(userPos ? { type: 'FeatureCollection', features: [circle(userPos.lng, userPos.lat, Math.min(userPos.acc || 0, 3000))] } : EMPTY);
  }
  function ensureOverlays() {
    if (!map.getSource('user-acc')) map.addSource('user-acc', { type: 'geojson', data: EMPTY });
    if (!map.getLayer('user-acc-fill')) map.addLayer({ id: 'user-acc-fill', type: 'fill', source: 'user-acc', paint: { 'fill-color': '#64748b', 'fill-opacity': 0.16 } });
    if (!map.getLayer('user-acc-line')) map.addLayer({ id: 'user-acc-line', type: 'line', source: 'user-acc', paint: { 'line-color': '#64748b', 'line-opacity': 0.5, 'line-width': 1 } });
    applyUserAcc();
  }
  function placeUserMarker() {
    if (!userPos) return;
    if (!userMarker) {
      var el = MS.h('div', { class: 'user-dot', 'aria-hidden': 'true' }, MS.h('span', { class: 'user-dot-pulse' }), MS.h('span', { class: 'user-dot-core' }));
      userMarker = new maplibregl.Marker({ element: el, anchor: 'center' }).setLngLat([userPos.lng, userPos.lat]).addTo(map);
    } else {
      userMarker.setLngLat([userPos.lng, userPos.lat]);
    }
  }
  function onPos(p) {
    var first = !userPos;
    userPos = { lng: p.coords.longitude, lat: p.coords.latitude, acc: p.coords.accuracy, rt: Date.now() };
    placeUserMarker();
    applyUserAcc();
    if (pendingFly || (first && followFirstFix)) {
      pendingFly = false;
      followFirstFix = false;
      flyTo(userPos.lng, userPos.lat, Math.max(map.getZoom(), 16));
    }
    ev.emit('userpos', userPos);
  }
  function onPosError(err) {
    if (err && err.code === 1) stopWatch();
    ev.emit('usererror', err);
  }
  function startWatch() {
    if (!navigator.geolocation) { ev.emit('usererror', { code: 0 }); return false; }
    if (watchId != null) return true;
    watchId = navigator.geolocation.watchPosition(onPos, onPosError, { enableHighAccuracy: true, maximumAge: 4000, timeout: 30000 });
    return true;
  }
  function stopWatch() {
    if (watchId != null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }
  /** Botón "mi ubicación": centra el mapa en el dispositivo (pide el permiso si hace falta). */
  function locate() {
    if (userPos) { flyTo(userPos.lng, userPos.lat, Math.max(map.getZoom(), 16)); if (watchId == null) startWatch(); return; }
    pendingFly = true;
    startWatch();
  }

  /**
   * Botón "Agregar aquí": espera una lectura precisa del GPS y entrega {lat, lng, acc}.
   * Aprovecha la lectura continua (la inicia si hace falta). Acepta de inmediato una lectura de hasta goodAcc m;
   * pasados softMs desde la primera lectura, una de hasta okAcc m; pasados hardMs, la mejor que haya.
   * Falla con {code} (1 permiso denegado, 0 sin GPS, 3 sin lecturas) o {cancelled:true}. La promesa tiene .cancel().
   */
  function preciseFix(opts) {
    opts = opts || {};
    var G = MS.GPS, t0 = Date.now(), best = null, firstAt = 0, finished = false, tick = null, kick = null, offs = [], settle = {};
    var promise = new Promise(function (resolve, reject) { settle.resolve = resolve; settle.reject = reject; });
    function end(fn, value) {
      if (finished) return;
      finished = true;
      clearInterval(tick); clearTimeout(kick);
      offs.forEach(function (off) { off(); });
      fn(value);
    }
    function result(p) { return { lat: p.lat, lng: p.lng, acc: p.acc }; }
    function evaluate() {
      if (finished) return;
      var now = Date.now(), since = now - (firstAt || t0);
      // Sin lecturas nuevas pero con una anterior reciente (la lectura continua pudo quedar quieta): se usa la última conocida.
      var cand = best || ((now - t0 >= 6000 && userPos && now - userPos.rt < 120000) ? userPos : null);
      if (cand) {
        if (cand.acc <= G.goodAcc || (since >= G.softMs && cand.acc <= G.okAcc) || since >= G.hardMs) end(settle.resolve, result(cand));
      } else if (now - t0 >= G.noFixMs) {
        end(settle.reject, { code: 3 });
      }
    }
    function take(p) {
      if (!p || finished) return;
      if (!firstAt) firstAt = Date.now();
      if (!best || p.acc <= best.acc) best = p;
      if (opts.onProgress) opts.onProgress(best.acc);
      evaluate();
    }
    promise.cancel = function () { end(settle.reject, { cancelled: true }); };
    if (!navigator.geolocation) { end(settle.reject, { code: 0 }); return promise; }

    offs.push(ev.on('userpos', take));
    offs.push(ev.on('usererror', function (err) {
      var c = err && err.code;
      if (c === 1 || c === 0) end(settle.reject, { code: c });
      else if (c === 3 && best) end(settle.resolve, result(best));
    }));
    startWatch();
    if (userPos && userPos.rt >= t0 - 3000) take(userPos);
    tick = setInterval(evaluate, 300);
    // Si la lectura continua estuviera detenida, una lectura puntual la despierta.
    kick = setTimeout(function () {
      if (finished || best) return;
      try { navigator.geolocation.getCurrentPosition(onPos, function () { /* lo informa la lectura continua */ }, { enableHighAccuracy: true, maximumAge: 0, timeout: 15000 }); } catch (e) { /* sin GPS */ }
    }, 3500);
    return promise;
  }

  /* ---------- Tema ---------- */
  function setTheme(t) {
    if (!map || t === theme) { theme = t; return; }
    theme = t;
    map.setStyle(MS.mapStyle.build(t), { diff: false });
  }

  /* ---------- Inicio ---------- */
  function init(el, opts) {
    container = el;
    theme = opts.theme || 'light';
    var view = opts.view;
    followFirstFix = !view;
    MS.tiles.register(maplibregl);

    map = new maplibregl.Map({
      container: el,
      style: MS.mapStyle.build(theme),
      center: view ? [view.lng, view.lat] : MS.MAP.defaultCenter,
      zoom: view ? view.zoom : MS.MAP.defaultZoom,
      minZoom: MS.MAP.minZoom,
      maxZoom: MS.MAP.maxZoom,
      attributionControl: false,
      // Se puede girar con dos dedos (el gesto empieza al torcer unos 25° para no confundirlo con el zoom). El mapa no se inclina.
      dragRotate: false,
      pitchWithRotate: false,
      touchPitch: false,
      bearingSnap: 7,                // a menos de 7° del norte, el mapa se acomoda solo al norte
      fadeDuration: 150
    });
    map.addControl(new maplibregl.AttributionControl({ compact: true }), 'bottom-left');
    map.getCanvas().setAttribute('aria-label', 'Mapa interactivo');

    map.on('style.load', ensureOverlays);

    // Tocar el mapa registra una persona; se espera un instante para no confundirlo con el doble toque de zoom.
    map.on('click', function (e) {
      clearTimeout(tapTimer);
      tapTimer = setTimeout(function () { ev.emit('tap', { lng: e.lngLat.lng, lat: e.lngLat.lat }); }, 260);
    });
    map.on('dblclick', function () { clearTimeout(tapTimer); });
    map.on('movestart', function () { clearTimeout(tapTimer); });

    var labels = function () { container.classList.toggle('show-labels', map.getZoom() >= 16); };
    map.on('zoom', labels);
    labels();

    var persist = MS.debounce(function () {
      var c = map.getCenter();
      MS.store.setSetting('view', { lng: +c.lng.toFixed(6), lat: +c.lat.toFixed(6), zoom: +map.getZoom().toFixed(2) });
    }, 700);
    map.on('moveend', function () { persist(); ev.emit('moveend'); });
    // Orientación del mapa (grados respecto del norte): la brújula de la pantalla la sigue y vuelve al norte con un toque.
    map.on('rotate', function () { ev.emit('bearing', map.getBearing()); });

    // Los fallos de teselas/glifos sin conexión son normales: no se muestran como errores.
    map.on('error', function (e) { if (window.console && console.debug) console.debug('[mapa]', e && e.error && e.error.message); });

    if (navigator.permissions && navigator.permissions.query) {
      navigator.permissions.query({ name: 'geolocation' }).then(function (s) {
        if (s.state === 'granted') startWatch();
        s.onchange = function () { if (s.state === 'granted') startWatch(); };
      }).catch(function () { /* sin API de permisos */ });
    }
    map.once('load', function () { ev.emit('ready'); });
  }

  MS.mapCtl = {
    on: ev.on,
    init: init,
    get map() { return map; },
    syncAll: syncAll,
    upsert: upsert,
    remove: remove,
    setSelected: setSelected,
    ping: ping,
    showTempPin: showTempPin,
    setTempStage: setTempStage,
    clearTempPin: clearTempPin,
    focusAbove: focusAbove,
    resetPadding: resetPadding,
    flyTo: flyTo,
    flyToPerson: flyToPerson,
    fitBounds: fitBoundsArray,
    getBounds: getBounds,
    locate: locate,
    preciseFix: preciseFix,
    startWatch: startWatch,
    getUserPos: function () { return userPos; },
    setTheme: setTheme,
    getBearing: function () { return map ? map.getBearing() : 0; },
    resetNorth: function () { if (map) map.resetNorth({ duration: 350 }); },
    resize: function () { if (map) map.resize(); }
  };

})(window.MS = window.MS || {});
