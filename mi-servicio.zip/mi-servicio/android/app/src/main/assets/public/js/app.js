/* Mi Servicio – arranque, pestañas, tema, ubicación y primer uso */
(function (MS) {
  'use strict';

  var h = MS.h, ui = MS.ui, store = MS.store;
  var tab = 'map';
  var peopleLayer = null;
  var els = {};
  var locateAsked = false;
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  /* =====================================================================
   * Tema (claro / oscuro / sistema)
   * ===================================================================== */
  function resolveTheme() {
    var t = store.getSetting('theme');
    if (t === 'light' || t === 'dark') return t;
    return mq && mq.matches ? 'dark' : 'light';
  }
  function applyTheme() {
    var t = resolveTheme();
    document.documentElement.dataset.theme = t;
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'dark' ? '#1f1f21' : '#f1ede9');
    if (MS.isNative()) {
      // DARK = íconos claros (fondo oscuro); LIGHT = íconos oscuros (fondo claro)
      var bars = MS.plugin('SystemBars');
      if (bars && bars.setStyle) {
        try {
          var r = bars.setStyle({ style: t === 'dark' ? 'DARK' : 'LIGHT' });
          if (r && r.catch) r.catch(function () { /* sin barras */ });
        } catch (e) { /* sin barras */ }
      }
    }
    if (MS.mapCtl.map) MS.mapCtl.setTheme(t);
  }
  if (mq) {
    var onScheme = function () { if ((store.getSetting('theme') || 'system') === 'system') applyTheme(); };
    if (mq.addEventListener) mq.addEventListener('change', onScheme); else if (mq.addListener) mq.addListener(onScheme);
  }

  /* =====================================================================
   * Pestañas: Explorar Mapa / Personas
   * ===================================================================== */
  function applyTab(name) {
    tab = name;
    els.viewMap.classList.toggle('active', name === 'map');
    els.viewPeople.classList.toggle('active', name === 'people');
    MS.$$('.nav-item').forEach(function (b) {
      var on = b.dataset.tab === name;
      b.classList.toggle('active', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    MS.views.people.setVisible(name === 'people');
    if (name === 'map') MS.mapCtl.resize();
  }
  /** Cambia de pestaña. "Personas" ocupa una capa del historial para que "atrás" vuelva al mapa. */
  function showTab(name) {
    if (name === tab) return Promise.resolve();
    if (name === 'people') {
      peopleLayer = MS.layers.push({ dismissible: false, teardown: function () { peopleLayer = null; applyTab('map'); } });
      applyTab('people');
      return Promise.resolve();
    }
    if (peopleLayer) return MS.layers.request(peopleLayer, true).then(function () { return true; });
    applyTab('map');
    return Promise.resolve();
  }
  function showOnMap(id) {
    return showTab('map').then(function () {
      MS.mapCtl.flyToPerson(id);
      setTimeout(function () { MS.mapCtl.ping(id); }, 500);
    });
  }

  /* =====================================================================
   * Avisos sobre el mapa: sin conexión y ayuda inicial
   * ===================================================================== */
  function updateNet() { els.net.hidden = navigator.onLine !== false; }
  function updateHint() { els.hint.hidden = store.people.length > 0; }

  /* ---------- Botón "mi ubicación" ---------- */
  function setLocateState(state) {
    els.locate.dataset.state = state;
    var icon = state === 'on' ? 'locating' : state === 'denied' ? 'gps-off' : 'my-location';
    els.locate.innerHTML = MS.icon(icon, 24);
    els.locate.setAttribute('aria-label', state === 'denied' ? 'Ubicación no disponible' : 'Mostrar mi ubicación');
  }
  function wireLocation() {
    els.locate.addEventListener('click', function () {
      locateAsked = true;
      MS.mapCtl.locate();
    });
    MS.mapCtl.on('userpos', function () { locateAsked = false; setLocateState('on'); });
    MS.mapCtl.on('usererror', function (err) {
      var code = err && err.code;
      if (code === 1 || code === 0) setLocateState('denied');
      if (!locateAsked) return;
      locateAsked = false;
      ui.snack(code === 1
        ? 'Permiso de ubicación denegado. Actívelo en los ajustes del teléfono para ver dónde está.'
        : code === 0 ? 'Este dispositivo no permite obtener la ubicación.'
        : 'No se pudo obtener la ubicación. Verifique que el GPS esté activado.', { duration: 6000 });
    });
  }

  /* =====================================================================
   * Primer uso
   * ===================================================================== */
  function showIntro() {
    var wantLocation = false, sheet = null;
    function point(icon, text) {
      return h('li', null, h('span', { class: 'intro-ic', html: MS.icon(icon, 22) }), h('span', null, text));
    }
    var content = h('div', { class: 'intro' },
      h('h2', { class: 'sheet-title intro-title' }, 'Bienvenido a Mi Servicio'),
      h('ul', { class: 'intro-list' },
        point('pin-drop', 'Toque cualquier punto del mapa para registrar a una persona.'),
        point('history', 'Sume una nota con fecha en cada visita y consulte el historial completo.'),
        point('phone', 'Todo se guarda en este teléfono y funciona sin conexión.')),
      h('p', { class: 'muted' }, 'Para mostrar dónde está, la app le pedirá permiso de ubicación. Solo se usa en este dispositivo.'),
      h('div', { class: 'sheet-actions' },
        ui.button({ variant: 'text', label: 'Ahora no', onClick: function () { sheet.close(); } }),
        ui.button({ variant: 'filled', label: 'Usar mi ubicación', icon: 'my-location', onClick: function () { wantLocation = true; sheet.close(); } })));
    sheet = ui.openSheet({
      title: 'Bienvenida', content: content,
      onClose: function () {
        store.setSetting('introSeen', true);
        if (wantLocation) { locateAsked = true; MS.mapCtl.locate(); }
      }
    });
  }

  /* =====================================================================
   * Arranque
   * ===================================================================== */
  function wireMap() {
    MS.mapCtl.on('tap', function (pos) {
      if (MS.layers.size() > 0 || tab !== 'map') return;
      MS.views.openNewPerson(pos);
    });
    MS.mapCtl.on('select', function (id) {
      if (MS.layers.size() > 0 || tab !== 'map') return;
      MS.views.openDetail(id);
    });
  }
  function wireStore() {
    store.on('change', function (e) {
      var p;
      if (e.type === 'bulk') MS.mapCtl.syncAll(store.people);
      else if (e.type === 'remove') MS.mapCtl.remove(e.id);
      else if (e.type === 'add') { p = store.getPerson(e.id); if (p) MS.mapCtl.upsert(p, true); }
      else if (e.type === 'update') { p = store.getPerson(e.id); if (p) MS.mapCtl.upsert(p, false); }
      MS.views.people.refresh();
      updateHint();
    });
  }
  function registerWorker() {
    if (MS.isNative() || !('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
    navigator.serviceWorker.register('sw.js').catch(function (e) { console.debug('[sw]', e && e.message); });
  }

  function boot() {
    MS.$$('[data-icon]').forEach(function (el) {
      el.innerHTML = MS.icon(el.dataset.icon, +el.dataset.size || 24);
    });
    els = {
      viewMap: MS.$('#view-map'), viewPeople: MS.$('#view-people'), map: MS.$('#map'),
      net: MS.$('#net-chip'), hint: MS.$('#hint-chip'), locate: MS.$('#btn-locate'), settings: MS.$('#btn-settings')
    };

    // Pide que el navegador no borre los datos ni los mapas guardados si falta espacio (sin avisos al usuario).
    try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(function () {}); } catch (e) { /* no disponible */ }

    return store.load().catch(function (e) { console.error(e); }).then(function () {
      applyTheme();
      MS.mapCtl.init(els.map, { theme: resolveTheme(), view: store.getSetting('view') });
      MS.mapCtl.syncAll(store.people);
      wireMap(); wireStore(); wireLocation();
      setLocateState('idle');

      MS.views.people.build(els.viewPeople);
      MS.$$('.nav-item').forEach(function (b) { b.addEventListener('click', function () { showTab(b.dataset.tab); }); });
      els.settings.addEventListener('click', function () { MS.settings.open(); });

      document.addEventListener('focusin', function (e) {
        var t = e.target;
        if (t && t.matches && t.matches('input:not([type="radio"]):not([type="checkbox"]):not([type="file"]), textarea')) document.documentElement.classList.add('typing');
      });
      document.addEventListener('focusout', function () {
        setTimeout(function () {
          var a = document.activeElement;
          if (!(a && a.matches && a.matches('input:not([type="radio"]):not([type="checkbox"]), textarea'))) document.documentElement.classList.remove('typing');
        }, 60);
      });
      window.addEventListener('online', updateNet);
      window.addEventListener('offline', updateNet);
      document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') { updateNet(); MS.mapCtl.resize(); }
      });
      updateNet(); updateHint(); applyTab('map');
      document.documentElement.classList.remove('booting');
      registerWorker();
      if (!store.getSetting('introSeen')) setTimeout(showIntro, 700);
    });
  }

  MS.app = { showTab: showTab, showOnMap: showOnMap, applyTheme: applyTheme, boot: boot };
  boot();

})(window.MS = window.MS || {});
