/* Mi Servicio – arranque, pestañas, tema, ubicación y primer uso */
(function (MS) {
  'use strict';

  var h = MS.h, ui = MS.ui, store = MS.store;
  var tab = 'map';
  var peopleLayer = null;
  var els = {};
  var locateAsked = false;
  var mq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  /* =====================================================================
   * Tema (claro / oscuro / sistema)
   * ===================================================================== */
  function resolveTheme() {
    var t = store.getSetting('theme');
    if (t === 'light' || t === 'dark') return t;
    return mq && mq.matches ? 'dark' : 'light';
  }
  function applyTheme() {
    var t = resolveTheme();
    document.documentElement.dataset.theme = t;
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'dark' ? '#1f1f21' : '#f1ede9');
    if (MS.isNative()) {
      // DARK = íconos claros (fondo oscuro); LIGHT = íconos oscuros (fondo claro)
      var bars = MS.plugin('SystemBars');
      if (bars && bars.setStyle) {
        try {
          var r = bars.setStyle({ style: t === 'dark' ? 'DARK' : 'LIGHT' });
          if (r && r.catch) r.catch(function () { /* sin barras */ });
        } catch (e) { /* sin barras */ }
      }
    }
    if (MS.mapCtl.map) MS.mapCtl.setTheme(t);
  }
  if (mq) {
    var onScheme = function () { if ((store.getSetting('theme') || 'system') === 'system') applyTheme(); };
    if (mq.addEventListener) mq.addEventListener('change', onScheme); else if (mq.addListener) mq.addListener(onScheme);
  }

  /* =====================================================================
   * Pestañas: Explorar Mapa / Personas
   * ===================================================================== */
  function applyTab(name) {
    tab = name;
    els.viewMap.classList.toggle('active', name === 'map');
    els.viewPeople.classList.toggle('active', name === 'people');
    MS.$$('.nav-item').forEach(function (b) {
      var on = b.dataset.tab === name;
      b.classList.toggle('active', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    MS.views.people.setVisible(name === 'people');
    if (name === 'map') MS.mapCtl.resize();
  }
  /** Cambia de pestaña. "Personas" ocupa una capa del historial para que "atrás" vuelva al mapa. */
  function showTab(name) {
    if (name === tab) return Promise.resolve();
    if (name === 'people') {
      peopleLayer = MS.layers.push({ dismissible: false, teardown: function () { peopleLayer = null; applyTab('map'); } });
      applyTab('people');
      return Promise.resolve();
    }
    if (peopleLayer) return MS.layers.request(peopleLayer, true).then(function () { return true; });
    applyTab('map');
    return Promise.resolve();
  }
  function showOnMap(id) {
    return showTab('map').then(function () {
      MS.mapCtl.flyToPerson(id);
      setTimeout(function () { MS.mapCtl.ping(id); }, 500);
    });
  }

  /* =====================================================================
   * Avisos sobre el mapa: sin conexión y ayuda inicial
   * ===================================================================== */
  function updateNet() { els.net.hidden = navigator.onLine !== false; }
  function updateHint() { els.hint.hidden = store.people.length > 0; }

  /* ---------- Botón "mi ubicación" ---------- */
  function setLocateState(state) {
    els.locate.dataset.state = state;
    var icon = state === 'on' ? 'locating' : state === 'denied' ? 'gps-off' : 'my-location';
    els.locate.innerHTML = MS.icon(icon, 24);
    els.locate.setAttribute('aria-label', state === 'denied' ? 'Ubicación no disponible' : 'Mostrar mi ubicación');
  }
  /** Texto del aviso según el error de geolocalización (1 permiso denegado, 0 sin soporte, otro: sin señal). */
  function locationErrorText(code) {
    return code === 1
      ? (MS.isIOS()
        ? 'Permiso de ubicación denegado. Revíselo en Ajustes del iPhone (Privacidad y seguridad) y toque de nuevo el botón.'
        : 'Permiso de ubicación denegado. Actívelo en los ajustes del teléfono para ver dónde está.')
      : code === 0 ? 'Este dispositivo no permite obtener la ubicación.'
      : 'No se pudo obtener la ubicación. Verifique que el GPS esté activado.';
  }
  function wireLocation() {
    els.locate.addEventListener('click', function () {
      locateAsked = true;
      MS.mapCtl.locate();
    });
    MS.mapCtl.on('userpos', function () { locateAsked = false; setLocateState('on'); });
    MS.mapCtl.on('usererror', function (err) {
      var code = err && err.code;
      if (code === 1 || code === 0) setLocateState('denied');
      if (!locateAsked) return;
      locateAsked = false;
      ui.snack(locationErrorText(code), { duration: 6000 });
    });
  }

  /* ---------- Botón "Agregar aquí": registra a la persona en la ubicación actual, con la mejor precisión posible ---------- */
  var addHereJob = null;
  function cancelAddHere() { if (addHereJob) addHereJob.cancel(); }
  function wireAddHere() {
    var btn = els.addHere;
    if (!btn) return;
    var status = els.addHereStatus;            // aviso corto junto al botón mientras espera al GPS ("Ubicando… ±12 m")
    function setIdle() {
      addHereJob = null;
      btn.dataset.state = 'idle';
      btn.setAttribute('aria-busy', 'false');
      btn.setAttribute('aria-label', 'Agregar una persona en mi ubicación actual');
      btn.title = 'Agregar una persona en mi ubicación actual';
      if (status) { status.hidden = true; status.textContent = ''; }
    }
    function setBusy(acc) {
      btn.dataset.state = 'busy';
      btn.setAttribute('aria-busy', 'true');
      btn.setAttribute('aria-label', 'Cancelar la búsqueda de ubicación');
      btn.title = 'Cancelar la búsqueda de ubicación';
      if (status) {
        status.textContent = acc ? 'Ubicando… ±' + Math.max(1, Math.round(acc)) + ' m' : 'Ubicando…';
        status.hidden = false;
      }
    }
    btn.addEventListener('click', function () {
      if (addHereJob) {                                   // segundo toque mientras busca: cancela
        if (Date.now() - addHereJob.at >= MS.GPS.minBusyMs) addHereJob.cancel();
        return;
      }
      if (MS.layers.size() > 0 || tab !== 'map') return;
      var job = { at: Date.now(), cancel: null };
      addHereJob = job;
      setBusy(0);
      var p = MS.mapCtl.preciseFix({ onProgress: function (acc) { if (addHereJob === job) setBusy(acc); } });
      job.cancel = p.cancel;
      p.then(function (fix) {
        if (addHereJob !== job) return;
        setIdle();
        if (MS.layers.size() > 0 || tab !== 'map') return;
        MS.vibrate(12);
        MS.views.openNewPerson({ lat: fix.lat, lng: fix.lng, gps: true, acc: fix.acc });
      }, function (err) {
        if (addHereJob !== job) return;
        setIdle();
        if (err && err.cancelled) return;
        ui.snack(err && (err.code === 1 || err.code === 0)
          ? locationErrorText(err.code)
          : 'No se pudo obtener una ubicación precisa. Pruebe en un lugar abierto o toque el punto exacto en el mapa.', { duration: 6000 });
      });
    });
    setIdle();
  }

  /* =====================================================================
   * Primer uso
   * ===================================================================== */
  function showIntro() {
    var wantLocation = false, sheet = null;
    var iosTip = MS.isIOS() && !MS.isNative() && !MS.isStandalone();
    function point(icon, text) {
      return h('li', null, h('span', { class: 'intro-ic', html: MS.icon(icon, 22) }), h('span', null, text));
    }
    var content = h('div', { class: 'intro' },
      h('h2', { class: 'sheet-title intro-title' }, 'Bienvenido a Mi Servicio'),
      h('ul', { class: 'intro-list' },
        point('pin-drop', 'Toque cualquier punto del mapa para registrar a una persona, o use el botón con el pin y el signo + para guardarla en su ubicación actual.'),
        point('person-add', 'Para cargar a alguien que visitó sin tener el teléfono, entre en «Personas» y toque el botón con el signo +: puede escribir la dirección, pegar un enlace de Google Maps o ingresar coordenadas.'),
        point('history', 'Sume una nota con fecha y hora en cada visita y consulte el historial completo.'),
        point('phone', 'Todo se guarda en este teléfono y funciona sin conexión.'),
        iosTip ? point('share', 'Para instalarla, toque Compartir (o los tres puntos y luego Compartir) y elija "Agregar a pantalla de inicio". Ábrala siempre desde ese ícono.') : null),
      h('p', { class: 'muted' }, 'Para mostrar dónde está, la app le pedirá permiso de ubicación. Solo se usa en este dispositivo.'),
      h('div', { class: 'sheet-actions' },
        ui.button({ variant: 'text', label: 'Ahora no', onClick: function () { sheet.close(); } }),
        ui.button({ variant: 'filled', label: 'Usar mi ubicación', icon: 'my-location', onClick: function () { wantLocation = true; sheet.close(); } })));
    sheet = ui.openSheet({
      title: 'Bienvenida', content: content,
      onClose: function () {
        store.setSetting('introSeen', true);
        if (wantLocation) { locateAsked = true; MS.mapCtl.locate(); }
      }
    });
  }

  /* =====================================================================
   * Arranque
   * ===================================================================== */
  function wireMap() {
    MS.mapCtl.on('tap', function (pos) {
      if (MS.layers.size() > 0 || tab !== 'map') return;
      cancelAddHere();
      MS.views.openNewPerson(pos);
    });
    MS.mapCtl.on('select', function (id) {
      if (MS.layers.size() > 0 || tab !== 'map') return;
      cancelAddHere();
      MS.views.openDetail(id);
    });

    // Brújula: solo se muestra con el mapa girado; la aguja sigue al norte y un toque lo vuelve a orientar.
    var compass = MS.$('#btn-compass'), needle = compass && compass.querySelector('.compass-needle');
    if (compass) {
      MS.mapCtl.on('bearing', function (b) {
        compass.hidden = Math.abs(b) < 0.5;
        needle.style.transform = 'rotate(' + (-b).toFixed(1) + 'deg)';
      });
      compass.addEventListener('click', function () { MS.mapCtl.resetNorth(); MS.vibrate(8); });
    }
  }
  function wireStore() {
    store.on('change', function (e) {
      var p;
      if (e.type === 'bulk') MS.mapCtl.syncAll(store.people);
      else if (e.type === 'remove') MS.mapCtl.remove(e.id);
      else if (e.type === 'add') { p = store.getPerson(e.id); if (p) MS.mapCtl.upsert(p, true); }
      else if (e.type === 'update' || e.type === 'notes') { p = store.getPerson(e.id); if (p) MS.mapCtl.upsert(p, false); }
      MS.views.people.refresh();
      updateHint();
    });
  }
  function registerWorker() {
    if (MS.isNative() || !('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
    navigator.serviceWorker.register('sw.js').catch(function (e) { console.debug('[sw]', e && e.message); });
  }

  /* iPhone/iPad: el teclado se superpone a la página en lugar de achicarla; se sube la hoja inferior por encima del teclado. */
  function wireKeyboardIOS() {
    var vv = window.visualViewport;
    if (!vv || !MS.isIOS() || MS.isNative()) return;
    var root = document.documentElement, last = -1;
    function update() {
      var kb = Math.abs(vv.scale - 1) < 0.02 ? Math.round(window.innerHeight - vv.height - vv.offsetTop) : 0;
      if (kb < 80) kb = 0;                       // ignora variaciones chicas (barras del navegador)
      if (kb === last) return;
      last = kb;
      root.style.setProperty('--kb', kb + 'px');
      root.classList.toggle('kb-open', kb > 0);
    }
    vv.addEventListener('resize', update);
    vv.addEventListener('scroll', update);
    document.addEventListener('focusout', function () {
      // Safari a veces deja la página desplazada al cerrar el teclado.
      setTimeout(function () {
        var a = document.activeElement;
        if (!(a && a.matches && a.matches('input, textarea'))) window.scrollTo(0, 0);
      }, 120);
    });
    update();
  }

  /* ---------- Gesto/botón «atrás» ----------
   * En el APK de Android el sistema no cierra las pantallas de la app por sí solo: se las cierra aquí, una por una
   * (hoja, diálogo o pestaña Personas) y, estando en Explorar Mapa, se sale de la app. En iPhone y en el navegador
   * lo resuelve el historial (popstate, ver ui-core.js). */
  function blurField() {
    var a = document.activeElement;
    if (a && a !== document.body && a.matches && a.matches('input, textarea')) a.blur();
  }
  function exitApp() {
    var App = MS.plugin('App');
    try { if (App && App.exitApp) App.exitApp(); } catch (e) { /* sin plugin */ }
  }
  function onBackButton() {
    blurField();                                      // si quedó un campo con el foco (teclado ya oculto), lo suelta
    var top = MS.layers.top();
    if (top) { MS.layers.request(top); return; }
    exitApp();
  }
  function wireBackButton() {
    if (!MS.isNative()) return;
    var App = MS.plugin('App');
    if (!App || !App.addListener) return;
    try {
      var r = App.addListener('backButton', onBackButton);
      if (r && r.catch) r.catch(function (e) { console.debug('[atrás]', e && e.message); });
    } catch (e) { console.debug('[atrás]', e && e.message); }
  }

  /* Android: al ocultar el teclado con el gesto «atrás», el campo conserva el foco y la barra inferior seguía oculta.
   * Se detecta que el teclado se cerró (la ventana vuelve a su alto) y se suelta el foco. */
  function wireKeyboardClose() {
    if (MS.isIOS()) return;                            // iPhone: el teclado se cierra con su propio botón (ver wireKeyboardIOS)
    var vv = window.visualViewport, base = 0, width = 0, open = false;
    function size() { return Math.round(vv ? vv.height : window.innerHeight); }
    function check() {
      var w = window.innerWidth, hh = size();
      if (Math.abs(w - width) > 40) { width = w; base = 0; open = false; }   // giro de pantalla: se recalcula
      if (hh > base) base = hh;
      var isOpen = base - hh > 140 && (!vv || Math.abs(vv.scale - 1) < 0.02);
      if (open && !isOpen) blurField();
      open = isOpen;
    }
    (vv || window).addEventListener('resize', check);
    check();
  }

  function boot() {
    MS.$$('[data-icon]').forEach(function (el) {
      el.innerHTML = MS.icon(el.dataset.icon, +el.dataset.size || 24);
    });
    els = {
      viewMap: MS.$('#view-map'), viewPeople: MS.$('#view-people'), map: MS.$('#map'),
      net: MS.$('#net-chip'), hint: MS.$('#hint-chip'), locate: MS.$('#btn-locate'), addHere: MS.$('#btn-add-here'), addHereStatus: MS.$('#add-here-status'), settings: MS.$('#btn-settings')
    };

    // Pide que el navegador no borre los datos ni los mapas guardados si falta espacio (sin avisos al usuario).
    try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(function () {}); } catch (e) { /* no disponible */ }

    return store.load().catch(function (e) { console.error(e); }).then(function () {
      applyTheme();
      MS.mapCtl.init(els.map, { theme: resolveTheme(), view: store.getSetting('view') });
      MS.mapCtl.syncAll(store.people);
      wireMap(); wireStore(); wireLocation(); wireAddHere();
      setLocateState('idle');

      MS.views.people.build(els.viewPeople);
      MS.$$('.nav-item').forEach(function (b) { b.addEventListener('click', function () { showTab(b.dataset.tab); }); });
      els.settings.addEventListener('click', function () { MS.settings.open(); });

      document.addEventListener('focusin', function (e) {
        var t = e.target;
        if (t && t.matches && t.matches('input:not([type="radio"]):not([type="checkbox"]):not([type="file"]), textarea')) document.documentElement.classList.add('typing');
      });
      document.addEventListener('focusout', function () {
        setTimeout(function () {
          var a = document.activeElement;
          if (!(a && a.matches && a.matches('input:not([type="radio"]):not([type="checkbox"]), textarea'))) document.documentElement.classList.remove('typing');
        }, 60);
      });
      window.addEventListener('online', updateNet);
      window.addEventListener('offline', updateNet);
      document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') { updateNet(); MS.mapCtl.resize(); }
      });
      updateNet(); updateHint(); applyTab('map');
      document.documentElement.classList.remove('booting');
      registerWorker();
      wireKeyboardIOS();
      wireKeyboardClose();
      wireBackButton();
      if (!store.getSetting('introSeen')) setTimeout(showIntro, 700);
    });
  }

  MS.app = { showTab: showTab, showOnMap: showOnMap, applyTheme: applyTheme, boot: boot };
  boot();

})(window.MS = window.MS || {});
