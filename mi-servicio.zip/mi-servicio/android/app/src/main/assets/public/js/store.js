/* Mi Servicio – personas, notas y ajustes (100 % local) */
(function (MS) {
  'use strict';

  var ev = MS.emitter();
  var state = {
    people: [],
    settings: {
      theme: 'system',      // system | light | dark
      notesOrder: 'desc',   // desc = más recientes primero
      peopleSort: 'lastvisit', // lastvisit (últimas visitas) | added (más recientes: por alta) | name (A–Z) | fewest (menos visitadas)
      view: null,           // última vista del mapa {lng, lat, zoom}
      introSeen: false
    }
  };
  var saveTimer = null;

  var SORTS = ['lastvisit', 'added', 'name', 'fewest'];
  /** Orden de la lista de personas. «recent» (valor de versiones anteriores) ordenaba por la última visita: hoy es «lastvisit». */
  function cleanSort(v) {
    if (v === 'recent') return 'lastvisit';
    return SORTS.indexOf(v) >= 0 ? v : 'lastvisit';
  }

  /* ---------- Persistencia ---------- */
  function persistNow() {
    clearTimeout(saveTimer);
    saveTimer = null;
    var payload = { v: 1, savedAt: Date.now(), people: state.people };
    // Copia síncrona en localStorage: sobrevive si la app se cierra antes de terminar la escritura en IndexedDB.
    try { localStorage.setItem('ms:people', JSON.stringify(payload)); } catch (e) { /* sin espacio */ }
    return MS.db.kv.set('people', payload);
  }
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(persistNow, 120);
  }
  function saveSettings() {
    try { localStorage.setItem('ms-theme', state.settings.theme); } catch (e) { /* nada */ }
    return MS.db.kv.set('settings', state.settings);
  }
  function flush() {
    if (saveTimer) persistNow();
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', flush);

  /* ---------- Normalización ---------- */
  function validISO(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !!MS.parseISO(s); }
  function str(v, max) { return (typeof v === 'string' ? v : '').slice(0, max || 5000); }

  function cleanNote(n, now) {
    var o = {
      id: str(n && n.id, 40) || MS.uid(),
      date: validISO(n && n.date) ? n.date : MS.todayISO(),
      text: str(n && n.text),
      createdAt: Number(n && n.createdAt) || now,
      updatedAt: Number(n && n.updatedAt) || now
    };
    // Las visitas comunes no llevan "kind" (así las copias de seguridad anteriores siguen siendo válidas).
    if (n && n.kind === 'nohome') o.kind = 'nohome';
    // Hora (HH:MM). '' = sin hora a propósito. Si el campo no existe (notas de versiones anteriores), se deduce al mostrarla.
    if (n && typeof n.time === 'string') o.time = MS.validTime(n.time) ? n.time : '';
    return o;
  }
  /** Hora de una visita para guardarla: undefined si no se indicó (queda sin el campo), '' si se dejó vacía a propósito. */
  function timeProp(t) { return typeof t === 'string' ? (MS.validTime(t) ? t : '') : undefined; }
  /**
   * Hora de una nota ("HH:MM") o '' si no se sabe. Las notas anteriores a la versión 1.4 no guardaban la hora:
   * si se cargaron el mismo día de la visita, se toma la hora en que se cargaron.
   */
  function noteTime(n) {
    if (!n) return '';
    if (typeof n.time === 'string') return MS.validTime(n.time) ? n.time : '';
    return MS.dateOf(n.createdAt) === n.date ? MS.timeOf(n.createdAt) : '';
  }
  /** Clave para ordenar visitas por momento: fecha + hora (sin hora, va antes que las del mismo día que sí la tienen). */
  function noteStamp(n) { return n.date + ' ' + noteTime(n); }
  function compareNotes(x, y) {
    var a = noteStamp(x), b = noteStamp(y);
    if (a !== b) return a < b ? -1 : 1;
    return (x.createdAt || 0) - (y.createdAt || 0);
  }
  /** Número de territorio: entero de 1 a 99, o null si no hay (o no es válido). */
  function cleanTerritory(v) {
    if (v == null || v === '') return null;
    var n = Math.round(Number(v));
    return isFinite(n) && n >= 1 && n <= 99 ? n : null;
  }
  /** Devuelve una persona válida o null si no se puede rescatar. */
  function cleanPerson(p) {
    var now = Date.now();
    if (!p || typeof p !== 'object') return null;
    var lat = Number(p.lat), lng = Number(p.lng);
    var name = str(p.name, 200).trim();
    if (!name || !isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
    var stageOk = MS.STAGES.some(function (s) { return s.id === p.stage; });
    return {
      id: str(p.id, 40) || MS.uid(),
      name: name,
      ref: str(p.ref, 300).trim(),
      stage: stageOk ? p.stage : 'primera',
      territory: cleanTerritory(p.territory),
      lat: lat,
      lng: lng,
      createdAt: Number(p.createdAt) || now,
      updatedAt: Number(p.updatedAt) || now,
      notes: (Array.isArray(p.notes) ? p.notes : []).map(function (n) { return cleanNote(n, now); })
    };
  }

  function load() {
    return Promise.all([
      MS.db.kv.get('people', null),
      MS.db.kv.get('settings', null)
    ]).then(function (r) {
      var fromIdb = r[0], fromLs = null;
      try { fromLs = JSON.parse(localStorage.getItem('ms:people')); } catch (e) { /* nada */ }
      var best = null;
      [fromIdb, fromLs].forEach(function (c) {
        if (c && Array.isArray(c.people) && (!best || (c.savedAt || 0) > (best.savedAt || 0))) best = c;
      });
      state.people = best ? best.people.map(cleanPerson).filter(Boolean) : [];
      if (r[1] && typeof r[1] === 'object') Object.assign(state.settings, r[1]);
      state.settings.peopleSort = cleanSort(state.settings.peopleSort);
      if (best && best !== fromIdb) persistNow(); // reparar IndexedDB desde la copia
      ev.emit('loaded');
    });
  }

  /* ---------- Personas ---------- */
  function getPerson(id) {
    for (var i = 0; i < state.people.length; i++) if (state.people[i].id === id) return state.people[i];
    return null;
  }

  function addPerson(d) {
    var now = Date.now();
    var p = {
      id: MS.uid(),
      name: d.name.trim(),
      ref: (d.ref || '').trim(),
      stage: d.stage || 'primera',
      territory: cleanTerritory(d.territory),
      lat: d.lat,
      lng: d.lng,
      createdAt: now,
      updatedAt: now,
      // La visita inicial siempre se registra (con su fecha), aunque no lleve texto.
      notes: [{ id: MS.uid(), date: validISO(d.date) ? d.date : MS.todayISO(), text: (d.text || '').trim(), createdAt: now, updatedAt: now }]
    };
    var t0 = timeProp(d.time);
    if (t0 !== undefined) p.notes[0].time = t0;
    state.people.push(p);
    save();
    ev.emit('change', { type: 'add', id: p.id });
    return p;
  }

  function updatePerson(id, patch) {
    var p = getPerson(id);
    if (!p) return null;
    var stageChanged = false;
    if (typeof patch.name === 'string' && patch.name.trim()) p.name = patch.name.trim();
    if (typeof patch.ref === 'string') p.ref = patch.ref.trim();
    if (patch.stage && patch.stage !== p.stage) { p.stage = patch.stage; stageChanged = true; }
    if ('territory' in patch) p.territory = cleanTerritory(patch.territory);
    if (isFinite(patch.lat) && isFinite(patch.lng)) { p.lat = patch.lat; p.lng = patch.lng; }
    p.updatedAt = Date.now();
    save();
    ev.emit('change', { type: 'update', id: id, stageChanged: stageChanged });
    return p;
  }

  function removePerson(id) {
    for (var i = 0; i < state.people.length; i++) {
      if (state.people[i].id === id) {
        var p = state.people.splice(i, 1)[0];
        save();
        ev.emit('change', { type: 'remove', id: id });
        return { person: p, index: i };
      }
    }
    return null;
  }
  function restorePerson(snapshot) {
    if (!snapshot || getPerson(snapshot.person.id)) return;
    state.people.splice(Math.min(snapshot.index, state.people.length), 0, snapshot.person);
    save();
    ev.emit('change', { type: 'add', id: snapshot.person.id });
  }

  /* ---------- Notas ---------- */
  function addNote(personId, d) {
    var p = getPerson(personId);
    if (!p) return null;
    var now = Date.now();
    var n = { id: MS.uid(), date: validISO(d.date) ? d.date : MS.todayISO(), text: (d.text || '').trim(), createdAt: now, updatedAt: now };
    if (d.kind === 'nohome') n.kind = 'nohome';       // se fue a la casa y no se encontró a la persona
    var t1 = timeProp(d.time);
    if (t1 !== undefined) n.time = t1;
    p.notes.push(n);
    p.updatedAt = now;
    save();
    ev.emit('change', { type: 'notes', id: personId });
    return n;
  }
  function updateNote(personId, noteId, d) {
    var p = getPerson(personId);
    if (!p) return null;
    for (var i = 0; i < p.notes.length; i++) {
      if (p.notes[i].id === noteId) {
        var n = p.notes[i];
        if (validISO(d.date)) n.date = d.date;
        if (typeof d.text === 'string') n.text = d.text.trim();
        if (typeof d.time === 'string') n.time = MS.validTime(d.time) ? d.time : '';
        n.updatedAt = Date.now();
        p.updatedAt = n.updatedAt;
        save();
        ev.emit('change', { type: 'notes', id: personId });
        return n;
      }
    }
    return null;
  }
  function removeNote(personId, noteId) {
    var p = getPerson(personId);
    if (!p) return null;
    for (var i = 0; i < p.notes.length; i++) {
      if (p.notes[i].id === noteId) {
        var n = p.notes.splice(i, 1)[0];
        p.updatedAt = Date.now();
        save();
        ev.emit('change', { type: 'notes', id: personId });
        return { note: n, index: i };
      }
    }
    return null;
  }
  function restoreNote(personId, snapshot) {
    var p = getPerson(personId);
    if (!p || !snapshot) return;
    p.notes.splice(Math.min(snapshot.index, p.notes.length), 0, snapshot.note);
    save();
    ev.emit('change', { type: 'notes', id: personId });
  }

  /** Notas ordenadas por fecha y hora de visita (desempate por orden de carga). */
  function sortedNotes(p, dir) {
    var a = p.notes.slice().sort(compareNotes);
    return dir === 'asc' ? a : a.reverse();
  }
  /** El último registro (visita o "No en casa") por fecha y hora; null si no hay ninguno. */
  function lastRecord(p) {
    var best = null;
    p.notes.forEach(function (n) { if (!best || compareNotes(n, best) > 0) best = n; });
    return best;
  }
  /** Fecha del último registro (visita o "No en casa"). */
  function lastVisit(p) {
    var best = '';
    p.notes.forEach(function (n) { if (n.date > best) best = n.date; });
    return best;
  }
  function isNoHome(n) { return !!n && n.kind === 'nohome'; }
  /** Cantidad de visitas en las que sí se encontró a la persona. */
  function visitCount(p) {
    return p.notes.filter(function (n) { return !isNoHome(n); }).length;
  }
  /**
   * Si el último registro es "No en casa": { count, date } con las veces seguidas que no se la encontró
   * y la fecha del último intento. Si la última vez sí se la encontró (o no hay registros): null.
   */
  function noHomeInfo(p) {
    var list = sortedNotes(p, 'desc');
    if (!list.length || !isNoHome(list[0])) return null;
    var count = 0;
    while (count < list.length && isNoHome(list[count])) count++;
    return { count: count, date: list[0].date };
  }

  /* ---------- Búsqueda y filtros ---------- */
  function search(query, stage) {
    var tokens = MS.norm(query).split(/\s+/).filter(Boolean);
    var out = [];
    state.people.forEach(function (p) {
      if (stage && stage !== 'all' && p.stage !== stage) return;
      var snippet = null;
      if (tokens.length) {
        // También se busca por número de territorio ("territorio 33") y por "no en casa".
        var head = MS.norm(p.name + ' ' + p.ref + (p.territory ? ' territorio ' + p.territory : ''));
        var notesNorm = p.notes.map(function (n) { return MS.norm((isNoHome(n) ? 'no en casa ' : '') + n.text); });
        var all = head + ' ' + notesNorm.join(' ');
        var ok = tokens.every(function (t) { return all.indexOf(t) >= 0; });
        if (!ok) return;
        // Si la coincidencia viene de una nota, se muestra un fragmento
        var inHead = tokens.every(function (t) { return head.indexOf(t) >= 0; });
        if (!inHead) {
          // Se muestra la nota que coincide con más palabras de la búsqueda (a igualdad, la primera).
          var bestScore = 0;
          for (var i = 0; i < p.notes.length; i++) {
            var score = tokens.filter(function (t) { return notesNorm[i].indexOf(t) >= 0; }).length;
            if (score > bestScore) { bestScore = score; snippet = p.notes[i]; }
          }
        }
      }
      out.push({ person: p, snippet: snippet });
    });
    var sort = cleanSort(state.settings.peopleSort);
    // Cada persona se prepara una sola vez: último registro (fecha + hora) y cantidad de visitas en las que se la encontró.
    out.forEach(function (it) {
      var last = lastRecord(it.person);
      it.stamp = last ? noteStamp(last) : '';
      it.lastAt = last ? (last.createdAt || 0) : 0;
      it.visits = visitCount(it.person);
    });
    function byName(a, b) { return a.person.name.localeCompare(b.person.name, 'es', { sensitivity: 'base' }); }
    out.sort(function (a, b) {
      if (sort === 'name') return byName(a, b);
      if (sort === 'added') return (b.person.createdAt - a.person.createdAt) || byName(a, b);
      if (sort === 'fewest') {
        // De menos a más visitas; a igualdad, primero la que hace más tiempo que no se visita.
        if (a.visits !== b.visits) return a.visits - b.visits;
        if (a.stamp !== b.stamp) return a.stamp < b.stamp ? -1 : 1;
        return byName(a, b);
      }
      // 'lastvisit': lo último que se registró (visita o «No en casa») primero.
      if (a.stamp !== b.stamp) return a.stamp < b.stamp ? 1 : -1;
      if (a.lastAt !== b.lastAt) return b.lastAt - a.lastAt;
      return byName(a, b);
    });
    return out;
  }
  function countByStage() {
    var c = { all: state.people.length };
    MS.STAGES.forEach(function (s) { c[s.id] = 0; });
    state.people.forEach(function (p) { c[p.stage] = (c[p.stage] || 0) + 1; });
    return c;
  }

  /* ---------- Copia de seguridad ---------- */
  function exportData() {
    return {
      app: 'mi-servicio',
      version: 1,
      exportedAt: new Date().toISOString(),
      people: state.people,
      settings: { notesOrder: state.settings.notesOrder, peopleSort: state.settings.peopleSort }
    };
  }
  /** mode: 'merge' (combina por id) o 'replace' (reemplaza todo). Devuelve conteos. */
  function importData(obj, mode) {
    if (!obj || obj.app !== 'mi-servicio' || !Array.isArray(obj.people)) throw new Error('El archivo no es una copia de Mi Servicio.');
    var incoming = obj.people.map(cleanPerson).filter(Boolean);
    var res = { added: 0, updated: 0, skipped: obj.people.length - incoming.length };
    if (mode === 'replace') {
      state.people = incoming;
      res.added = incoming.length;
    } else {
      incoming.forEach(function (inc) {
        var cur = getPerson(inc.id);
        if (!cur) { state.people.push(inc); res.added++; return; }
        var seen = {};
        cur.notes.forEach(function (n) { seen[n.id] = 1; });
        var grew = false;
        inc.notes.forEach(function (n) { if (!seen[n.id]) { cur.notes.push(n); grew = true; } });
        if (inc.updatedAt > cur.updatedAt) {
          cur.name = inc.name; cur.ref = inc.ref; cur.stage = inc.stage; cur.territory = inc.territory; cur.lat = inc.lat; cur.lng = inc.lng; cur.updatedAt = inc.updatedAt;
          grew = true;
        }
        if (grew) res.updated++;
      });
    }
    if (obj.settings && mode === 'replace') {
      if (obj.settings.notesOrder) state.settings.notesOrder = obj.settings.notesOrder;
      if (obj.settings.peopleSort) state.settings.peopleSort = cleanSort(obj.settings.peopleSort);
      saveSettings();
    }
    persistNow();
    ev.emit('change', { type: 'bulk' });
    return res;
  }

  /* ---------- Ajustes ---------- */
  function getSetting(k) { return state.settings[k]; }
  function setSetting(k, v) {
    state.settings[k] = k === 'peopleSort' ? cleanSort(v) : v;
    return saveSettings();
  }

  MS.store = {
    on: ev.on,
    load: load,
    flush: flush,
    get people() { return state.people; },
    getPerson: getPerson,
    addPerson: addPerson,
    updatePerson: updatePerson,
    removePerson: removePerson,
    restorePerson: restorePerson,
    addNote: addNote,
    updateNote: updateNote,
    removeNote: removeNote,
    restoreNote: restoreNote,
    sortedNotes: sortedNotes,
    noteTime: noteTime,
    lastRecord: lastRecord,
    lastVisit: lastVisit,
    isNoHome: isNoHome,
    visitCount: visitCount,
    noHomeInfo: noHomeInfo,
    search: search,
    countByStage: countByStage,
    exportData: exportData,
    importData: importData,
    getSetting: getSetting,
    setSetting: setSetting
  };

})(window.MS = window.MS || {});
