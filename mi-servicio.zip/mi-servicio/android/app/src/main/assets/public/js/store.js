/* Mi Servicio – personas, notas y ajustes (100 % local) */
(function (MS) {
  'use strict';

  var ev = MS.emitter();
  var state = {
    people: [],
    settings: {
      theme: 'system',      // system | light | dark
      notesOrder: 'desc',   // desc = más recientes primero
      peopleSort: 'lastvisit', // lastvisit (últimas visitas) | added (más recientes: por alta) | name (A–Z) | most (más visitadas) | fewest (menos visitadas)
      view: null,           // última vista del mapa {lng, lat, zoom}
      introSeen: false
    }
  };
  var saveTimer = null;

  var SORTS = ['lastvisit', 'added', 'name', 'most', 'fewest'];
  /** Orden de la lista de personas. «recent» (valor de versiones anteriores) ordenaba por la última visita: hoy es «lastvisit». */
  function cleanSort(v) {
    if (v === 'recent') return 'lastvisit';
    return SORTS.indexOf(v) >= 0 ? v : 'lastvisit';
  }

  /* ---------- Persistencia ---------- */
  function persistNow() {
    clearTimeout(saveTimer);
    saveTimer = null;
    var payload = { v: 2, savedAt: Date.now(), people: state.people };
    // Copia síncrona en localStorage: sobrevive si la app se cierra antes de terminar la escritura en IndexedDB.
    try { localStorage.setItem('ms:people', JSON.stringify(payload)); } catch (e) { /* sin espacio */ }
    return MS.db.kv.set('people', payload);
  }
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(persistNow, 120);
  }
  function saveSettings() {
    try { localStorage.setItem('ms-theme', state.settings.theme); } catch (e) { /* nada */ }
    return MS.db.kv.set('settings', state.settings);
  }
  function flush() {
    if (saveTimer) persistNow();
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', flush);

  /* ---------- Normalización ---------- */
  function validISO(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !!MS.parseISO(s); }
  function str(v, max) { return (typeof v === 'string' ? v : '').slice(0, max || 5000); }

  function cleanNote(n, now) {
    var o = {
      id: str(n && n.id, 40) || MS.uid(),
      date: validISO(n && n.date) ? n.date : MS.todayISO(),
      text: str(n && n.text),
      createdAt: Number(n && n.createdAt) || now,
      updatedAt: Number(n && n.updatedAt) || now
    };
    // Las visitas comunes no llevan "kind" (así las copias de seguridad anteriores siguen siendo válidas).
    if (n && n.kind === 'nohome') o.kind = 'nohome';
    // Visita a un estudio bíblico: cuenta en «Mi informe». Solo se guarda cuando es verdadera, y nunca en un «No en casa».
    if (n && n.study === true && o.kind !== 'nohome') o.study = true;
    // Hora (HH:MM). '' = sin hora a propósito. Si el campo no existe (notas de versiones anteriores), se deduce al mostrarla.
    if (n && typeof n.time === 'string') o.time = MS.validTime(n.time) ? n.time : '';
    return o;
  }
  /** Hora de una visita para guardarla: undefined si no se indicó (queda sin el campo), '' si se dejó vacía a propósito. */
  function timeProp(t) { return typeof t === 'string' ? (MS.validTime(t) ? t : '') : undefined; }
  /**
   * Hora de una nota ("HH:MM") o '' si no se sabe. Las notas anteriores a la versión 1.4 no guardaban la hora:
   * si se cargaron el mismo día de la visita, se toma la hora en que se cargaron.
   */
  function noteTime(n) {
    if (!n) return '';
    if (typeof n.time === 'string') return MS.validTime(n.time) ? n.time : '';
    return MS.dateOf(n.createdAt) === n.date ? MS.timeOf(n.createdAt) : '';
  }
  /** Clave para ordenar visitas por momento: fecha + hora (sin hora, va antes que las del mismo día que sí la tienen). */
  function noteStamp(n) { return n.date + ' ' + noteTime(n); }
  function compareNotes(x, y) {
    var a = noteStamp(x), b = noteStamp(y);
    if (a !== b) return a < b ? -1 : 1;
    return (x.createdAt || 0) - (y.createdAt || 0);
  }
  /** Número de territorio: entero de 1 a 99, o null si no hay (o no es válido). */
  function cleanTerritory(v) {
    if (v == null || v === '') return null;
    var n = Math.round(Number(v));
    return isFinite(n) && n >= 1 && n <= 99 ? n : null;
  }
  /** Devuelve una persona válida o null si no se puede rescatar. */
  function cleanPerson(p) {
    var now = Date.now();
    if (!p || typeof p !== 'object') return null;
    var lat = Number(p.lat), lng = Number(p.lng);
    var name = str(p.name, 200).trim();
    if (!name || !isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
    var stageOk = MS.STAGES.some(function (s) { return s.id === p.stage; });
    return {
      id: str(p.id, 40) || MS.uid(),
      name: name,
      ref: str(p.ref, 300).trim(),
      stage: stageOk ? p.stage : 'primera',
      territory: cleanTerritory(p.territory),
      lat: lat,
      lng: lng,
      createdAt: Number(p.createdAt) || now,
      updatedAt: Number(p.updatedAt) || now,
      notes: (Array.isArray(p.notes) ? p.notes : []).map(function (n) { return cleanNote(n, now); })
    };
  }

  function load() {
    return Promise.all([
      MS.db.kv.get('people', null),
      MS.db.kv.get('settings', null)
    ]).then(function (r) {
      var fromIdb = r[0], fromLs = null;
      try { fromLs = JSON.parse(localStorage.getItem('ms:people')); } catch (e) { /* nada */ }
      var best = null;
      [fromIdb, fromLs].forEach(function (c) {
        if (c && Array.isArray(c.people) && (!best || (c.savedAt || 0) > (best.savedAt || 0))) best = c;
      });
      state.people = best ? best.people.map(cleanPerson).filter(Boolean) : [];
      // Hasta la versión 1.4 las visitas no se marcaban como estudio: se marcan una sola vez, al pasar a la 1.5.
      var migrate = !!best && !(best.v >= 2);
      if (migrate) state.people.forEach(migrateStudy);
      if (r[1] && typeof r[1] === 'object') Object.assign(state.settings, r[1]);
      state.settings.peopleSort = cleanSort(state.settings.peopleSort);
      if ((best && best !== fromIdb) || migrate) persistNow(); // reparar IndexedDB desde la copia / guardar la migración
      ev.emit('loaded');
    });
  }

  /** Visita a un estudio bíblico (la que cuenta en «Mi informe»). Un «No en casa» nunca lo es. */
  function isStudy(n) { return !!n && n.study === true && n.kind !== 'nohome'; }
  /** Copias y datos de versiones anteriores a la 1.5: las visitas de quien está hoy en la etapa Estudio cuentan como estudio. */
  function migrateStudy(p) {
    if (!p || p.stage !== 'estudio') return;
    p.notes.forEach(function (n) { if (n.kind !== 'nohome') n.study = true; });
  }

  /* ---------- Personas ---------- */
  function getPerson(id) {
    for (var i = 0; i < state.people.length; i++) if (state.people[i].id === id) return state.people[i];
    return null;
  }

  function addPerson(d) {
    var now = Date.now();
    var p = {
      id: MS.uid(),
      name: d.name.trim(),
      ref: (d.ref || '').trim(),
      stage: d.stage || 'primera',
      territory: cleanTerritory(d.territory),
      lat: d.lat,
      lng: d.lng,
      createdAt: now,
      updatedAt: now,
      // La visita inicial siempre se registra (con su fecha), aunque no lleve texto.
      notes: [{ id: MS.uid(), date: validISO(d.date) ? d.date : MS.todayISO(), text: (d.text || '').trim(), createdAt: now, updatedAt: now }]
    };
    var t0 = timeProp(d.time);
    if (t0 !== undefined) p.notes[0].time = t0;
    // Si la persona se carga directamente como estudio, la primera visita cuenta como estudio (salvo que se indique lo contrario).
    if (d.study !== undefined ? !!d.study : p.stage === 'estudio') p.notes[0].study = true;
    state.people.push(p);
    save();
    ev.emit('change', { type: 'add', id: p.id });
    return p;
  }

  function updatePerson(id, patch) {
    var p = getPerson(id);
    if (!p) return null;
    var stageChanged = false;
    if (typeof patch.name === 'string' && patch.name.trim()) p.name = patch.name.trim();
    if (typeof patch.ref === 'string') p.ref = patch.ref.trim();
    if (patch.stage && patch.stage !== p.stage) { p.stage = patch.stage; stageChanged = true; }
    if ('territory' in patch) p.territory = cleanTerritory(patch.territory);
    if (isFinite(patch.lat) && isFinite(patch.lng)) { p.lat = patch.lat; p.lng = patch.lng; }
    p.updatedAt = Date.now();
    save();
    ev.emit('change', { type: 'update', id: id, stageChanged: stageChanged });
    return p;
  }

  function removePerson(id) {
    for (var i = 0; i < state.people.length; i++) {
      if (state.people[i].id === id) {
        var p = state.people.splice(i, 1)[0];
        save();
        ev.emit('change', { type: 'remove', id: id });
        return { person: p, index: i };
      }
    }
    return null;
  }
  function restorePerson(snapshot) {
    if (!snapshot || getPerson(snapshot.person.id)) return;
    state.people.splice(Math.min(snapshot.index, state.people.length), 0, snapshot.person);
    save();
    ev.emit('change', { type: 'add', id: snapshot.person.id });
  }

  /* ---------- Notas ---------- */
  function addNote(personId, d) {
    var p = getPerson(personId);
    if (!p) return null;
    var now = Date.now();
    var n = { id: MS.uid(), date: validISO(d.date) ? d.date : MS.todayISO(), text: (d.text || '').trim(), createdAt: now, updatedAt: now };
    if (d.kind === 'nohome') n.kind = 'nohome';       // se fue a la casa y no se encontró a la persona
    var t1 = timeProp(d.time);
    if (t1 !== undefined) n.time = t1;
    // Visita a un estudio: por defecto lo es cuando la persona está en la etapa Estudio. Un «No en casa» nunca cuenta.
    if (n.kind !== 'nohome' && (d.study !== undefined ? !!d.study : p.stage === 'estudio')) n.study = true;
    p.notes.push(n);
    p.updatedAt = now;
    save();
    ev.emit('change', { type: 'notes', id: personId });
    return n;
  }
  function updateNote(personId, noteId, d) {
    var p = getPerson(personId);
    if (!p) return null;
    for (var i = 0; i < p.notes.length; i++) {
      if (p.notes[i].id === noteId) {
        var n = p.notes[i];
        if (validISO(d.date)) n.date = d.date;
        if (typeof d.text === 'string') n.text = d.text.trim();
        if (typeof d.time === 'string') n.time = MS.validTime(d.time) ? d.time : '';
        if (typeof d.study === 'boolean') { if (d.study && n.kind !== 'nohome') n.study = true; else delete n.study; }
        n.updatedAt = Date.now();
        p.updatedAt = n.updatedAt;
        save();
        ev.emit('change', { type: 'notes', id: personId });
        return n;
      }
    }
    return null;
  }
  function removeNote(personId, noteId) {
    var p = getPerson(personId);
    if (!p) return null;
    for (var i = 0; i < p.notes.length; i++) {
      if (p.notes[i].id === noteId) {
        var n = p.notes.splice(i, 1)[0];
        p.updatedAt = Date.now();
        save();
        ev.emit('change', { type: 'notes', id: personId });
        return { note: n, index: i };
      }
    }
    return null;
  }
  function restoreNote(personId, snapshot) {
    var p = getPerson(personId);
    if (!p || !snapshot) return;
    p.notes.splice(Math.min(snapshot.index, p.notes.length), 0, snapshot.note);
    save();
    ev.emit('change', { type: 'notes', id: personId });
  }

  /**
   * Visitas a estudios entre dos fechas (AAAA-MM-DD, ambas incluidas; sin la segunda, solo ese día):
   * [{ person, note }] ordenadas por fecha y hora. «Mi informe» no guarda copia: lee siempre estas visitas.
   */
  function studyVisits(from, to) {
    var last = to || from, out = [];
    state.people.forEach(function (p) {
      p.notes.forEach(function (n) {
        if (isStudy(n) && n.date >= from && n.date <= last) out.push({ person: p, note: n });
      });
    });
    out.sort(function (a, b) { return compareNotes(a.note, b.note) || a.person.name.localeCompare(b.person.name, 'es', { sensitivity: 'base' }); });
    return out;
  }

  /** Notas ordenadas por fecha y hora de visita (desempate por orden de carga). */
  function sortedNotes(p, dir) {
    var a = p.notes.slice().sort(compareNotes);
    return dir === 'asc' ? a : a.reverse();
  }
  /** El último registro (visita o "No en casa") por fecha y hora; null si no hay ninguno. */
  function lastRecord(p) {
    var best = null;
    p.notes.forEach(function (n) { if (!best || compareNotes(n, best) > 0) best = n; });
    return best;
  }
  function isNoHome(n) { return !!n && n.kind === 'nohome'; }
  /** La última visita en la que sí se encontró a la persona, por fecha y hora («No en casa» no cuenta); null si no hubo ninguna. */
  function lastRealVisit(p) {
    var best = null;
    p.notes.forEach(function (n) { if (!isNoHome(n) && (!best || compareNotes(n, best) > 0)) best = n; });
    return best;
  }
  /** Fecha de la última visita en la que sí se encontró a la persona («No en casa» no cuenta); '' si no hubo ninguna. */
  function lastVisit(p) {
    var n = lastRealVisit(p);
    return n ? n.date : '';
  }
  /** Cantidad de visitas en las que sí se encontró a la persona. */
  function visitCount(p) {
    return p.notes.filter(function (n) { return !isNoHome(n); }).length;
  }
  /**
   * Si el último registro es "No en casa": { count, date } con las veces seguidas que no se la encontró
   * y la fecha del último intento. Si la última vez sí se la encontró (o no hay registros): null.
   */
  function noHomeInfo(p) {
    var list = sortedNotes(p, 'desc');
    if (!list.length || !isNoHome(list[0])) return null;
    var count = 0;
    while (count < list.length && isNoHome(list[count])) count++;
    return { count: count, date: list[0].date };
  }

  /* ---------- Búsqueda y filtros ---------- */
  /**
   * La búsqueda de personas filtra solo por nombre o por territorio (nunca por notas ni referencias).
   * Un número solo («33») filtra únicamente por territorio; las palabras filtran por nombre, sin tildes ni mayúsculas;
   * «territorio 33» también sirve. Se pueden combinar: «ana 33».
   */
  function parseQuery(query) {
    var q = { words: [], nums: [], terr: false };
    MS.norm(query).split(/\s+/).filter(Boolean).forEach(function (t) {
      if (/^\d+$/.test(t)) q.nums.push(Number(t));
      else if (t === 'territorio' || t === 'terr.') q.terr = true;
      else q.words.push(t);
    });
    return q;
  }
  function matchesQuery(p, q) {
    if (q.nums.length && !q.nums.every(function (n) { return p.territory === n; })) return false;
    if (q.terr && !p.territory) return false;
    if (q.words.length) {
      var name = MS.norm(p.name);
      if (!q.words.every(function (w) { return name.indexOf(w) >= 0; })) return false;
    }
    return true;
  }
  function search(query, stage) {
    var q = parseQuery(query);
    var out = [];
    state.people.forEach(function (p) {
      if (stage && stage !== 'all' && p.stage !== stage) return;
      if (!matchesQuery(p, q)) return;
      out.push({ person: p });
    });
    var sort = cleanSort(state.settings.peopleSort);
    // Cada persona se prepara una sola vez: su última visita real (fecha + hora) y la cantidad de visitas en las que se la encontró.
    // Los «No en casa» no cuentan como visita: ni en la cantidad ni en la fecha.
    out.forEach(function (it) {
      var last = lastRealVisit(it.person);
      it.stamp = last ? noteStamp(last) : '';
      it.lastAt = last ? (last.createdAt || 0) : 0;
      it.visits = visitCount(it.person);
    });
    function byName(a, b) { return a.person.name.localeCompare(b.person.name, 'es', { sensitivity: 'base' }); }
    out.sort(function (a, b) {
      if (sort === 'name') return byName(a, b);
      if (sort === 'added') return (b.person.createdAt - a.person.createdAt) || byName(a, b);
      if (sort === 'fewest') {
        // De menos a más visitas; a igualdad, primero la que hace más tiempo que no se visita.
        if (a.visits !== b.visits) return a.visits - b.visits;
        if (a.stamp !== b.stamp) return a.stamp < b.stamp ? -1 : 1;
        return byName(a, b);
      }
      if (sort === 'most') {
        // De más a menos visitas; a igualdad, primero la que se visitó hace menos tiempo.
        if (a.visits !== b.visits) return b.visits - a.visits;
        if (a.stamp !== b.stamp) return a.stamp < b.stamp ? 1 : -1;
        return byName(a, b);
      }
      // 'lastvisit': la visita más reciente primero (quien nunca fue encontrado, al final).
      if (a.stamp !== b.stamp) return a.stamp < b.stamp ? 1 : -1;
      if (a.lastAt !== b.lastAt) return b.lastAt - a.lastAt;
      return byName(a, b);
    });
    return out;
  }
  function countByStage() {
    var c = { all: state.people.length };
    MS.STAGES.forEach(function (s) { c[s.id] = 0; });
    state.people.forEach(function (p) { c[p.stage] = (c[p.stage] || 0) + 1; });
    return c;
  }

  /* ---------- Copia de seguridad ---------- */
  function exportData() {
    var out = {
      app: 'mi-servicio',
      version: 2,
      exportedAt: new Date().toISOString(),
      people: state.people,
      settings: { notesOrder: state.settings.notesOrder, peopleSort: state.settings.peopleSort }
    };
    // Horas, asignaciones y metas de «Mi informe» (las visitas a estudios ya viajan dentro de las personas).
    if (MS.report && MS.report.exportData) out.report = MS.report.exportData();
    return out;
  }
  /** mode: 'merge' (combina por id) o 'replace' (reemplaza todo). Devuelve conteos. */
  function importData(obj, mode) {
    if (!obj || obj.app !== 'mi-servicio' || !Array.isArray(obj.people)) throw new Error('El archivo no es una copia de Mi Servicio.');
    var incoming = obj.people.map(cleanPerson).filter(Boolean);
    if (!(obj.version >= 2)) incoming.forEach(migrateStudy);   // copia hecha con una versión anterior a la 1.5
    var res = { added: 0, updated: 0, skipped: obj.people.length - incoming.length, report: null };
    if (mode === 'replace') {
      state.people = incoming;
      res.added = incoming.length;
    } else {
      incoming.forEach(function (inc) {
        var cur = getPerson(inc.id);
        if (!cur) { state.people.push(inc); res.added++; return; }
        var seen = {};
        cur.notes.forEach(function (n) { seen[n.id] = 1; });
        var grew = false;
        inc.notes.forEach(function (n) { if (!seen[n.id]) { cur.notes.push(n); grew = true; } });
        if (inc.updatedAt > cur.updatedAt) {
          cur.name = inc.name; cur.ref = inc.ref; cur.stage = inc.stage; cur.territory = inc.territory; cur.lat = inc.lat; cur.lng = inc.lng; cur.updatedAt = inc.updatedAt;
          grew = true;
        }
        if (grew) res.updated++;
      });
    }
    if (obj.settings && mode === 'replace') {
      if (obj.settings.notesOrder) state.settings.notesOrder = obj.settings.notesOrder;
      if (obj.settings.peopleSort) state.settings.peopleSort = cleanSort(obj.settings.peopleSort);
      saveSettings();
    }
    // Una copia anterior a la 1.5 no trae «Mi informe»: en ese caso las horas actuales se dejan como están.
    if (obj.report && MS.report && MS.report.importData) res.report = MS.report.importData(obj.report, mode);
    persistNow();
    ev.emit('change', { type: 'bulk' });
    return res;
  }

  /* ---------- Ajustes ---------- */
  function getSetting(k) { return state.settings[k]; }
  function setSetting(k, v) {
    state.settings[k] = k === 'peopleSort' ? cleanSort(v) : v;
    return saveSettings();
  }

  MS.store = {
    on: ev.on,
    load: load,
    flush: flush,
    get people() { return state.people; },
    getPerson: getPerson,
    addPerson: addPerson,
    updatePerson: updatePerson,
    removePerson: removePerson,
    restorePerson: restorePerson,
    addNote: addNote,
    updateNote: updateNote,
    removeNote: removeNote,
    restoreNote: restoreNote,
    sortedNotes: sortedNotes,
    studyVisits: studyVisits,
    isStudy: isStudy,
    noteTime: noteTime,
    lastRecord: lastRecord,
    lastVisit: lastVisit,
    lastRealVisit: lastRealVisit,
    parseQuery: parseQuery,
    isNoHome: isNoHome,
    visitCount: visitCount,
    noHomeInfo: noHomeInfo,
    search: search,
    countByStage: countByStage,
    exportData: exportData,
    importData: importData,
    getSetting: getSetting,
    setSetting: setSetting
  };

})(window.MS = window.MS || {});
