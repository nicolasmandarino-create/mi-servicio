/* Mi Servicio – personas, notas y ajustes (100 % local) */
(function (MS) {
  'use strict';

  var ev = MS.emitter();
  var state = {
    people: [],
    settings: {
      theme: 'system',      // system | light | dark
      notesOrder: 'desc',   // desc = más recientes primero
      peopleSort: 'recent', // recent | name
      view: null,           // última vista del mapa {lng, lat, zoom}
      introSeen: false
    }
  };
  var saveTimer = null;

  /* ---------- Persistencia ---------- */
  function persistNow() {
    clearTimeout(saveTimer);
    saveTimer = null;
    var payload = { v: 1, savedAt: Date.now(), people: state.people };
    // Copia síncrona en localStorage: sobrevive si la app se cierra antes de terminar la escritura en IndexedDB.
    try { localStorage.setItem('ms:people', JSON.stringify(payload)); } catch (e) { /* sin espacio */ }
    return MS.db.kv.set('people', payload);
  }
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(persistNow, 120);
  }
  function saveSettings() {
    try { localStorage.setItem('ms-theme', state.settings.theme); } catch (e) { /* nada */ }
    return MS.db.kv.set('settings', state.settings);
  }
  function flush() {
    if (saveTimer) persistNow();
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', flush);

  /* ---------- Normalización ---------- */
  function validISO(s) { return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !!MS.parseISO(s); }
  function str(v, max) { return (typeof v === 'string' ? v : '').slice(0, max || 5000); }

  function cleanNote(n, now) {
    return {
      id: str(n && n.id, 40) || MS.uid(),
      date: validISO(n && n.date) ? n.date : MS.todayISO(),
      text: str(n && n.text),
      createdAt: Number(n && n.createdAt) || now,
      updatedAt: Number(n && n.updatedAt) || now
    };
  }
  /** Devuelve una persona válida o null si no se puede rescatar. */
  function cleanPerson(p) {
    var now = Date.now();
    if (!p || typeof p !== 'object') return null;
    var lat = Number(p.lat), lng = Number(p.lng);
    var name = str(p.name, 200).trim();
    if (!name || !isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
    var stageOk = MS.STAGES.some(function (s) { return s.id === p.stage; });
    return {
      id: str(p.id, 40) || MS.uid(),
      name: name,
      ref: str(p.ref, 300).trim(),
      stage: stageOk ? p.stage : 'primera',
      lat: lat,
      lng: lng,
      createdAt: Number(p.createdAt) || now,
      updatedAt: Number(p.updatedAt) || now,
      notes: (Array.isArray(p.notes) ? p.notes : []).map(function (n) { return cleanNote(n, now); })
    };
  }

  function load() {
    return Promise.all([
      MS.db.kv.get('people', null),
      MS.db.kv.get('settings', null)
    ]).then(function (r) {
      var fromIdb = r[0], fromLs = null;
      try { fromLs = JSON.parse(localStorage.getItem('ms:people')); } catch (e) { /* nada */ }
      var best = null;
      [fromIdb, fromLs].forEach(function (c) {
        if (c && Array.isArray(c.people) && (!best || (c.savedAt || 0) > (best.savedAt || 0))) best = c;
      });
      state.people = best ? best.people.map(cleanPerson).filter(Boolean) : [];
      if (r[1] && typeof r[1] === 'object') Object.assign(state.settings, r[1]);
      if (best && best !== fromIdb) persistNow(); // reparar IndexedDB desde la copia
      ev.emit('loaded');
    });
  }

  /* ---------- Personas ---------- */
  function getPerson(id) {
    for (var i = 0; i < state.people.length; i++) if (state.people[i].id === id) return state.people[i];
    return null;
  }

  function addPerson(d) {
    var now = Date.now();
    var p = {
      id: MS.uid(),
      name: d.name.trim(),
      ref: (d.ref || '').trim(),
      stage: d.stage || 'primera',
      lat: d.lat,
      lng: d.lng,
      createdAt: now,
      updatedAt: now,
      // La visita inicial siempre se registra (con su fecha), aunque no lleve texto.
      notes: [{ id: MS.uid(), date: validISO(d.date) ? d.date : MS.todayISO(), text: (d.text || '').trim(), createdAt: now, updatedAt: now }]
    };
    state.people.push(p);
    save();
    ev.emit('change', { type: 'add', id: p.id });
    return p;
  }

  function updatePerson(id, patch) {
    var p = getPerson(id);
    if (!p) return null;
    var stageChanged = false;
    if (typeof patch.name === 'string' && patch.name.trim()) p.name = patch.name.trim();
    if (typeof patch.ref === 'string') p.ref = patch.ref.trim();
    if (patch.stage && patch.stage !== p.stage) { p.stage = patch.stage; stageChanged = true; }
    if (isFinite(patch.lat) && isFinite(patch.lng)) { p.lat = patch.lat; p.lng = patch.lng; }
    p.updatedAt = Date.now();
    save();
    ev.emit('change', { type: 'update', id: id, stageChanged: stageChanged });
    return p;
  }

  function removePerson(id) {
    for (var i = 0; i < state.people.length; i++) {
      if (state.people[i].id === id) {
        var p = state.people.splice(i, 1)[0];
        save();
        ev.emit('change', { type: 'remove', id: id });
        return { person: p, index: i };
      }
    }
    return null;
  }
  function restorePerson(snapshot) {
    if (!snapshot || getPerson(snapshot.person.id)) return;
    state.people.splice(Math.min(snapshot.index, state.people.length), 0, snapshot.person);
    save();
    ev.emit('change', { type: 'add', id: snapshot.person.id });
  }

  /* ---------- Notas ---------- */
  function addNote(personId, d) {
    var p = getPerson(personId);
    if (!p) return null;
    var now = Date.now();
    var n = { id: MS.uid(), date: validISO(d.date) ? d.date : MS.todayISO(), text: (d.text || '').trim(), createdAt: now, updatedAt: now };
    p.notes.push(n);
    p.updatedAt = now;
    save();
    ev.emit('change', { type: 'notes', id: personId });
    return n;
  }
  function updateNote(personId, noteId, d) {
    var p = getPerson(personId);
    if (!p) return null;
    for (var i = 0; i < p.notes.length; i++) {
      if (p.notes[i].id === noteId) {
        var n = p.notes[i];
        if (validISO(d.date)) n.date = d.date;
        if (typeof d.text === 'string') n.text = d.text.trim();
        n.updatedAt = Date.now();
        p.updatedAt = n.updatedAt;
        save();
        ev.emit('change', { type: 'notes', id: personId });
        return n;
      }
    }
    return null;
  }
  function removeNote(personId, noteId) {
    var p = getPerson(personId);
    if (!p) return null;
    for (var i = 0; i < p.notes.length; i++) {
      if (p.notes[i].id === noteId) {
        var n = p.notes.splice(i, 1)[0];
        p.updatedAt = Date.now();
        save();
        ev.emit('change', { type: 'notes', id: personId });
        return { note: n, index: i };
      }
    }
    return null;
  }
  function restoreNote(personId, snapshot) {
    var p = getPerson(personId);
    if (!p || !snapshot) return;
    p.notes.splice(Math.min(snapshot.index, p.notes.length), 0, snapshot.note);
    save();
    ev.emit('change', { type: 'notes', id: personId });
  }

  /** Notas ordenadas por fecha de visita (desempate por orden de carga). */
  function sortedNotes(p, dir) {
    var a = p.notes.slice().sort(function (x, y) {
      if (x.date !== y.date) return x.date < y.date ? -1 : 1;
      return x.createdAt - y.createdAt;
    });
    return dir === 'asc' ? a : a.reverse();
  }
  function lastVisit(p) {
    var best = '';
    p.notes.forEach(function (n) { if (n.date > best) best = n.date; });
    return best;
  }

  /* ---------- Búsqueda y filtros ---------- */
  function search(query, stage) {
    var tokens = MS.norm(query).split(/\s+/).filter(Boolean);
    var out = [];
    state.people.forEach(function (p) {
      if (stage && stage !== 'all' && p.stage !== stage) return;
      var snippet = null;
      if (tokens.length) {
        var head = MS.norm(p.name + ' ' + p.ref);
        var notesNorm = p.notes.map(function (n) { return MS.norm(n.text); });
        var all = head + ' ' + notesNorm.join(' ');
        var ok = tokens.every(function (t) { return all.indexOf(t) >= 0; });
        if (!ok) return;
        // Si la coincidencia viene de una nota, se muestra un fragmento
        var inHead = tokens.every(function (t) { return head.indexOf(t) >= 0; });
        if (!inHead) {
          for (var i = 0; i < p.notes.length; i++) {
            if (tokens.some(function (t) { return notesNorm[i].indexOf(t) >= 0; })) { snippet = p.notes[i]; break; }
          }
        }
      }
      out.push({ person: p, snippet: snippet });
    });
    var sort = state.settings.peopleSort;
    out.sort(function (a, b) {
      if (sort === 'name') return a.person.name.localeCompare(b.person.name, 'es', { sensitivity: 'base' });
      var la = lastVisit(a.person), lb = lastVisit(b.person);
      if (la !== lb) return la < lb ? 1 : -1;
      return b.person.createdAt - a.person.createdAt;
    });
    return out;
  }
  function countByStage() {
    var c = { all: state.people.length };
    MS.STAGES.forEach(function (s) { c[s.id] = 0; });
    state.people.forEach(function (p) { c[p.stage] = (c[p.stage] || 0) + 1; });
    return c;
  }

  /* ---------- Copia de seguridad ---------- */
  function exportData() {
    return {
      app: 'mi-servicio',
      version: 1,
      exportedAt: new Date().toISOString(),
      people: state.people,
      settings: { notesOrder: state.settings.notesOrder, peopleSort: state.settings.peopleSort }
    };
  }
  /** mode: 'merge' (combina por id) o 'replace' (reemplaza todo). Devuelve conteos. */
  function importData(obj, mode) {
    if (!obj || obj.app !== 'mi-servicio' || !Array.isArray(obj.people)) throw new Error('El archivo no es una copia de Mi Servicio.');
    var incoming = obj.people.map(cleanPerson).filter(Boolean);
    var res = { added: 0, updated: 0, skipped: obj.people.length - incoming.length };
    if (mode === 'replace') {
      state.people = incoming;
      res.added = incoming.length;
    } else {
      incoming.forEach(function (inc) {
        var cur = getPerson(inc.id);
        if (!cur) { state.people.push(inc); res.added++; return; }
        var seen = {};
        cur.notes.forEach(function (n) { seen[n.id] = 1; });
        var grew = false;
        inc.notes.forEach(function (n) { if (!seen[n.id]) { cur.notes.push(n); grew = true; } });
        if (inc.updatedAt > cur.updatedAt) {
          cur.name = inc.name; cur.ref = inc.ref; cur.stage = inc.stage; cur.lat = inc.lat; cur.lng = inc.lng; cur.updatedAt = inc.updatedAt;
          grew = true;
        }
        if (grew) res.updated++;
      });
    }
    if (obj.settings && mode === 'replace') {
      if (obj.settings.notesOrder) state.settings.notesOrder = obj.settings.notesOrder;
      if (obj.settings.peopleSort) state.settings.peopleSort = obj.settings.peopleSort;
      saveSettings();
    }
    persistNow();
    ev.emit('change', { type: 'bulk' });
    return res;
  }

  /* ---------- Ajustes ---------- */
  function getSetting(k) { return state.settings[k]; }
  function setSetting(k, v) { state.settings[k] = v; return saveSettings(); }

  MS.store = {
    on: ev.on,
    load: load,
    flush: flush,
    get people() { return state.people; },
    getPerson: getPerson,
    addPerson: addPerson,
    updatePerson: updatePerson,
    removePerson: removePerson,
    restorePerson: restorePerson,
    addNote: addNote,
    updateNote: updateNote,
    removeNote: removeNote,
    restoreNote: restoreNote,
    sortedNotes: sortedNotes,
    lastVisit: lastVisit,
    search: search,
    countByStage: countByStage,
    exportData: exportData,
    importData: importData,
    getSetting: getSetting,
    setSetting: setSetting
  };

})(window.MS = window.MS || {});
