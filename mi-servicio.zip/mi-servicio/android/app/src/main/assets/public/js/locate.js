/* Mi Servicio – ubicar a una persona por dirección escrita, enlace de Google Maps o coordenadas.
 *
 * Coordenadas y enlaces largos se leen en el propio teléfono (sin conexión). Los enlaces cortos de Google Maps
 * (maps.app.goo.gl) se resuelven solo en la APK, con una petición HTTP nativa. Una dirección escrita se busca
 * con Nominatim (OpenStreetMap) y por eso necesita internet: ver MS.GEO en config.js y su política de uso
 * https://operations.osmfoundation.org/policies/nominatim/ */
(function (MS) {
  'use strict';

  var h = MS.h, ui = MS.ui;

  /* =====================================================================
   * Lectura de coordenadas y enlaces (funciones puras)
   * ===================================================================== */
  function validPair(lat, lng) {
    return isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && !(lat === 0 && lng === 0);
  }
  function num(s) { return parseFloat(String(s).replace(/[−–]/g, '-').replace(',', '.')); }
  function pair(lat, lng) {
    lat = num(lat); lng = num(lng);
    return validPair(lat, lng) ? { lat: Math.round(lat * 1e6) / 1e6, lng: Math.round(lng * 1e6) / 1e6 } : null;
  }

  // Grados decimales: "-34.6037, -58.3816", "-34,6037 -58,3816", "34.6037° S, 58.3816° O". Los números llevan decimales.
  var NUM = '[-+−]?\\d{1,3}[.,]\\d+';
  var HEM = '[NSEWOnsewo]';
  var SEP = '(?:\\s*[,;]\\s*|\\s+)';
  var RE_PAIR = new RegExp('^[\\s(\\[]*(' + NUM + ')\\s*°?\\s*(' + HEM + ')?' + SEP + '(' + NUM + ')\\s*°?\\s*(' + HEM + ')?[\\s)\\]]*$');
  // Grados, minutos y segundos (como los muestra Google Maps): 34°36'13.3"S 58°22'53.8"W
  var DMS_ONE = '(\\d{1,3})\\s*[°º]\\s*(\\d{1,2})\\s*[\'′’]\\s*(\\d{1,2}(?:[.,]\\d+)?)\\s*(?:"|″|”|\'\'|’’)?\\s*([NSEWOnsewo])';

  function neg(hem) { return /[SsWwOo]/.test(hem || ''); }
  function parseCoords(text) {
    text = String(text || '').trim().replace(/^loc:/i, '');
    var m = RE_PAIR.exec(text);
    if (m) {
      var a = num(m[1]), ha = m[2], b = num(m[3]), hb = m[4];
      if (neg(ha)) a = -Math.abs(a);
      if (neg(hb)) b = -Math.abs(b);
      // Si la primera lleva E/O/W (longitud) y la segunda N/S (o nada), vienen invertidas.
      var swapped = !!ha && /[EWOewo]/.test(ha) && (!hb || /[NSns]/.test(hb));
      return swapped ? pair(b, a) : pair(a, b);
    }
    var re = new RegExp(DMS_ONE, 'g'), found = [], d;
    while ((d = re.exec(text)) && found.length < 2) found.push(d);
    if (found.length === 2) {
      var v = found.map(function (x) {
        var val = parseFloat(x[1]) + parseFloat(x[2]) / 60 + num(x[3]) / 3600;
        return { val: neg(x[4]) ? -val : val, isLat: /[NSns]/.test(x[4]) };
      });
      if (v[0].isLat !== v[1].isLat) return v[0].isLat ? pair(v[0].val, v[1].val) : pair(v[1].val, v[0].val);
    }
    return null;
  }
  /** Coordenadas escritas dentro de un texto más largo ("Ubicación: -34.6037, -58.3816 (casa verde)"). */
  function findCoordsIn(text) {
    var m = /(-?\d{1,2}\.\d{3,})\s*[,;]?\s*(-?\d{1,3}\.\d{3,})/.exec(text);
    return m ? pair(m[1], m[2]) : null;
  }

  var SHORT_HOST = /^(?:maps\.app\.goo\.gl|goo\.gl|g\.co|share\.google)$/i;

  function decode(s) {
    var t = String(s).replace(/\+/g, ' ');
    try { return decodeURIComponent(t); } catch (e) { return t; }
  }
  /** Coordenadas dentro de un enlace de Google Maps, Apple Maps u OpenStreetMap. */
  function coordsFromUrl(u) {
    var s = decode(u), m, c;
    // El punto marcado del lugar (!3d…!4d…) es más exacto que el centro de la pantalla (@…).
    m = /!3d(-?\d{1,2}(?:\.\d+)?)!4d(-?\d{1,3}(?:\.\d+)?)/.exec(s);
    if (m && (c = pair(m[1], m[2]))) return c;
    var url = null;
    try { url = new URL(u); } catch (e) { url = null; }
    if (url) {
      var keys = ['q', 'query', 'll', 'destination', 'daddr', 'center', 'sll', 'coordinate', 'viewpoint'];
      for (var i = 0; i < keys.length; i++) {
        var v = url.searchParams.get(keys[i]);
        if (v && (c = parseCoords(v))) return c;
      }
      var la = url.searchParams.get('mlat'), lo = url.searchParams.get('mlon');
      if (la && lo && (c = pair(la, lo))) return c;
    }
    m = /#map=\d+\/(-?\d+(?:\.\d+)?)\/(-?\d+(?:\.\d+)?)/.exec(u);
    if (m && (c = pair(m[1], m[2]))) return c;
    m = /@(-?\d{1,2}(?:\.\d+)?),(-?\d{1,3}(?:\.\d+)?)/.exec(s);
    if (m && (c = pair(m[1], m[2]))) return c;
    m = /\/maps\/(?:place|search)\/([^\/?#@]+)/.exec(s);          // /place/34°36'13.3"S+58°22'53.8"W
    if (m && (c = parseCoords(m[1]))) return c;
    return null;
  }
  /** Texto de lugar de un enlace de Google Maps sin coordenadas (/place/Av.+Corrientes+1234 o ?q=…). */
  function textFromUrl(u) {
    var url;
    try { url = new URL(u); } catch (e) { return ''; }
    var q = url.searchParams.get('q') || url.searchParams.get('query') || url.searchParams.get('destination') || url.searchParams.get('daddr') || '';
    if (!q) {
      var m = /\/maps\/(?:place|search)\/([^\/?#@]+)/.exec(url.pathname);
      if (m) q = decode(m[1]);
    }
    return q.replace(/\s+/g, ' ').trim();
  }

  /**
   * Interpreta lo que escribió o pegó la persona. Devuelve:
   *   { kind: 'coords', lat, lng }      ubicación lista (sin conexión)
   *   { kind: 'short', url }            enlace corto de Google Maps: hay que abrirlo para leerlo
   *   { kind: 'address', text }         dirección escrita: se busca con internet
   *   { kind: 'badurl' }                enlace sin ubicación
   *   { kind: 'empty' }
   */
  function parse(text) {
    text = String(text == null ? '' : text).trim();
    if (!text) return { kind: 'empty' };
    var c = parseCoords(text);
    if (c) return { kind: 'coords', lat: c.lat, lng: c.lng };
    var m = /https?:\/\/[^\s<>"'`]+/i.exec(text);
    if (m) {
      var u = m[0].replace(/[).,;!?]+$/, ''), url = null;
      try { url = new URL(u); } catch (e) { return { kind: 'badurl' }; }
      if (/(^|\.)consent\.google\./i.test(url.hostname) && url.searchParams.get('continue')) return parse(url.searchParams.get('continue'));
      if (SHORT_HOST.test(url.hostname)) return { kind: 'short', url: u };
      c = coordsFromUrl(u);
      if (c) return { kind: 'coords', lat: c.lat, lng: c.lng };
      var t = textFromUrl(u);
      return t ? { kind: 'address', text: t } : { kind: 'badurl' };
    }
    c = findCoordsIn(text);
    if (c) return { kind: 'coords', lat: c.lat, lng: c.lng };
    return { kind: 'address', text: text.replace(/\s+/g, ' ') };
  }

  /* =====================================================================
   * Enlaces cortos de Google Maps (solo APK: la web no puede leer la redirección)
   * ===================================================================== */
  function headerGet(headers, name) {
    if (!headers) return '';
    var low = name.toLowerCase();
    for (var k in headers) {
      if (Object.prototype.hasOwnProperty.call(headers, k) && k.toLowerCase() === low) {
        var v = headers[k];
        return String(Array.isArray(v) ? v[0] : v || '');
      }
    }
    return '';
  }
  /** Sigue las redirecciones del enlace corto (hasta 6) y devuelve el mismo resultado que parse(). */
  function resolveShort(url) {
    var Http = MS.isNative() ? MS.plugin('CapacitorHttp') : null;
    if (!Http || typeof Http.request !== 'function') return Promise.reject({ code: 'unsupported' });
    var hops = 0;
    function step(u) {
      if (++hops > 6) return Promise.reject({ code: 'loop' });
      return Promise.resolve(Http.request({
        method: 'GET', url: u, disableRedirects: true, connectTimeout: 9000, readTimeout: 9000, responseType: 'text',
        headers: { 'User-Agent': navigator.userAgent }
      })).then(function (r) {
        var loc = headerGet(r && r.headers, 'location');
        if (r && r.status >= 300 && r.status < 400 && loc) {
          var next;
          try { next = new URL(loc, u).href; } catch (e) { throw { code: 'badlink' }; }
          var got = parse(next);
          if (got.kind === 'coords' || got.kind === 'address') return got;
          if (got.kind === 'short') return step(got.url);
          return step(next);                                         // otro salto (p. ej. de goo.gl a google.com)
        }
        // Sin redirección: se buscan las coordenadas en la propia página.
        var body = r && typeof r.data === 'string' ? r.data : '';
        var m = /@(-?\d{1,2}\.\d+),(-?\d{1,3}\.\d+)/.exec(body) || /!3d(-?\d{1,2}\.\d+)!4d(-?\d{1,3}\.\d+)/.exec(body);
        var c = m ? pair(m[1], m[2]) : null;
        if (c) return { kind: 'coords', lat: c.lat, lng: c.lng };
        throw { code: 'nocoords' };
      });
    }
    return step(url);
  }

  /* =====================================================================
   * Búsqueda de direcciones escritas (Nominatim de OpenStreetMap)
   * Solo se consulta cuando la persona toca «Buscar» (nunca mientras escribe), como máximo una vez por segundo,
   * y las búsquedas repetidas se resuelven con la copia en memoria.
   * ===================================================================== */
  var cache = {}, lastCall = 0;

  /** Zona aproximada del mapa (redondeada a 0,1°) para que las direcciones de la zona salgan primero. */
  function mapViewbox() {
    try {
      var b = MS.mapCtl.getBounds();                                  // [oeste, sur, este, norte]
      if (!b || b[2] - b[0] > 4) return '';                            // mapa muy alejado: no sirve de pista
      var cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2, d = 0.4;
      return [cx - d, cy + d, cx + d, cy - d].map(function (n) { return (Math.round(n * 10) / 10).toFixed(1); }).join(',');
    } catch (e) { return ''; }
  }

  function geocode(query) {
    var G = MS.GEO;
    if (!G || !G.enabled) return Promise.reject({ code: 'disabled' });
    var box = mapViewbox(), key = MS.norm(query) + '|' + box;
    if (cache[key]) return Promise.resolve(cache[key]);
    var wait = Math.max(0, lastCall + G.minGapMs - Date.now());
    return new Promise(function (r) { setTimeout(r, wait); }).then(function () {
      lastCall = Date.now();
      var qs = 'format=jsonv2&dedupe=1&accept-language=es&limit=' + G.limit + '&q=' + encodeURIComponent(query) + (box ? '&bounded=0&viewbox=' + box : '');
      var ctl = window.AbortController ? new AbortController() : null;
      var timer = setTimeout(function () { if (ctl) ctl.abort(); }, G.timeoutMs);
      return fetch(G.url + '?' + qs, { headers: { Accept: 'application/json' }, signal: ctl ? ctl.signal : undefined }).then(function (res) {
        clearTimeout(timer);
        if (res.status === 429 || res.status === 403) throw { code: 'blocked' };
        if (!res.ok) throw { code: 'http' };
        return res.json();
      }, function () { clearTimeout(timer); throw { code: 'network' }; }).then(function (rows) {
        var out = [];
        (Array.isArray(rows) ? rows : []).forEach(function (r) {
          var c = pair(r.lat, r.lon);
          if (c) out.push({ lat: c.lat, lng: c.lng, label: String(r.display_name || '') });
        });
        cache[key] = out;
        return out;
      });
    });
  }

  /* =====================================================================
   * Hoja «Agregar por dirección»
   * ===================================================================== */
  var ERRORS = {
    offline: 'Sin conexión: una dirección escrita necesita internet. Con coordenadas o con un enlace largo de Google Maps puede cargarla sin conexión.',
    blocked: 'El servicio de búsqueda de direcciones no está disponible en este momento. Pruebe más tarde, o use un enlace de Google Maps o coordenadas.',
    network: 'No se pudo conectar con el servicio de búsqueda. Verifique la conexión e intente de nuevo.',
    disabled: 'La búsqueda de direcciones escritas no está habilitada. Use un enlace de Google Maps o coordenadas.',
    notfound: 'No se encontró esa dirección. Pruebe agregando la ciudad o la provincia, o búsquela en Google Maps y pegue aquí su enlace.',
    badurl: 'No se encontró una ubicación en ese enlace. Pruebe con las coordenadas o con la dirección escrita.',
    unsupported: 'Los enlaces cortos (maps.app.goo.gl) solo se pueden leer desde la app de Android. Ábralo, copie el enlace largo o las coordenadas, y péguelos aquí.',
    shortfail: 'No se pudo leer el enlace corto. Ábralo en Google Maps, copie las coordenadas o la dirección, y péguelas aquí.'
  };

  function open() {
    var sheet = null, busy = false, token = 0;
    var f = ui.field({
      label: 'Dirección, enlace o coordenadas', multiline: true, rows: 2, maxlength: 500, autocapitalize: 'sentences',
      placeholder: 'Ej.: Av. Corrientes 1234, CABA', enterkeyhint: 'search'
    });
    var out = h('div', { class: 'locate-out', 'aria-live': 'polite' });
    var goBtn = ui.button({ variant: 'filled', label: 'Buscar', icon: 'search', type: 'submit', class: 'btn-locate-go' });

    function clearOut() { out.textContent = ''; }
    function setBusy(on, text) {
      busy = on;
      goBtn.disabled = on;
      goBtn.setAttribute('aria-busy', on ? 'true' : 'false');
      if (on) { clearOut(); out.append(h('p', { class: 'locate-busy' }, h('span', { class: 'locate-spin', 'aria-hidden': 'true' }), text)); }
    }
    function showError(code, actions) {
      clearOut();
      out.append(h('p', { class: 'locate-error', role: 'alert' }, h('span', { html: MS.icon('warning', 18) }), h('span', null, ERRORS[code] || ERRORS.network)));
      if (actions) out.append(h('div', { class: 'locate-actions' }, actions));
    }
    function openUrlBtn(label, url) {
      return ui.button({ variant: 'tonal', label: label, icon: 'map', onClick: function () { MS.openUrl(url); } });
    }

    /** La ubicación ya está: se cierra la hoja, se pasa al mapa y se abre el alta con el pin puesto. */
    function pick(pos) {
      token++;
      sheet.close(true).then(function () { return MS.app.showTab('map'); }).then(function () {
        MS.views.openNewPerson({ lat: pos.lat, lng: pos.lng, ref: pos.ref || '', source: pos.source, zoom: 17 });
      });
    }

    function searchAddress(text) {
      if (navigator.onLine === false) { showError('offline'); return; }
      var my = ++token;
      setBusy(true, 'Buscando la dirección…');
      geocode(text).then(function (list) {
        if (my !== token) return;
        setBusy(false);
        if (!list.length) {
          showError('notfound', [openUrlBtn('Buscar en Google Maps', 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(text))]);
          return;
        }
        if (list.length === 1) { pick({ lat: list[0].lat, lng: list[0].lng, ref: text, source: 'address' }); return; }
        clearOut();
        out.append(
          h('div', { class: 'form-label' }, 'Elija el lugar correcto'),
          h('div', { class: 'locate-list' }, list.map(function (r) {
            return h('button', { type: 'button', class: 'locate-opt ripple', onclick: function () { pick({ lat: r.lat, lng: r.lng, ref: text, source: 'address' }); } },
              h('span', { class: 'locate-opt-ic', html: MS.icon('place', 22) }),
              h('span', { class: 'locate-opt-text' }, r.label));
          })),
          h('p', { class: 'locate-attr' }, 'Resultados de OpenStreetMap · ',
            h('a', { href: 'https://www.openstreetmap.org/copyright', onclick: function (e) { e.preventDefault(); MS.openUrl('https://www.openstreetmap.org/copyright'); } }, '© colaboradores de OpenStreetMap')));
      }, function (err) {
        if (my !== token) return;
        setBusy(false);
        var code = err && err.code;
        showError(code === 'blocked' || code === 'disabled' ? code : 'network');
      });
    }

    function searchShort(url) {
      var my = ++token;
      if (!MS.isNative()) { showError('unsupported', [openUrlBtn('Abrir enlace', url)]); return; }
      setBusy(true, 'Leyendo el enlace de Google Maps…');
      resolveShort(url).then(function (r) {
        if (my !== token) return;
        setBusy(false);
        if (r.kind === 'coords') pick({ lat: r.lat, lng: r.lng, ref: '', source: 'coords' });
        else if (r.kind === 'address') searchAddress(r.text);
        else showError('shortfail', [openUrlBtn('Abrir enlace', url)]);
      }, function (err) {
        if (my !== token) return;
        setBusy(false);
        showError(err && err.code === 'unsupported' ? 'unsupported' : 'shortfail', [openUrlBtn('Abrir enlace', url)]);
      });
    }

    function submit() {
      if (busy) return;
      clearOut();
      var r = parse(f.value);
      if (r.kind === 'empty') { f.setError('Escriba una dirección, pegue un enlace de Google Maps o ingrese coordenadas.'); f.input.focus(); return; }
      if (r.kind === 'coords') { pick({ lat: r.lat, lng: r.lng, ref: '', source: 'coords' }); return; }
      if (r.kind === 'short') { searchShort(r.url); return; }
      if (r.kind === 'badurl') { showError('badurl'); return; }
      searchAddress(r.text);
    }

    f.input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); }
    });

    var form = h('form', { class: 'sheet-form locate', novalidate: true, onsubmit: function (e) { e.preventDefault(); submit(); } },
      ui.sheetHead('Agregar por dirección', function () { sheet.close(); }),
      h('p', { class: 'muted' }, 'Escriba una dirección, pegue un enlace de Google Maps o ingrese las coordenadas (latitud, longitud). Luego completará los datos de la persona sobre el mapa.'),
      f.el,
      out,
      h('p', { class: 'locate-note' }, 'Las coordenadas y los enlaces largos de Google Maps se leen en el teléfono, sin conexión. Una dirección escrita se envía a OpenStreetMap (Nominatim), con la zona aproximada del mapa, para encontrarla; el nombre y las notas nunca se envían. Un enlace corto (maps.app.goo.gl) se abre en Google para leer su ubicación.'),
      h('div', { class: 'sheet-actions sticky' },
        ui.button({ variant: 'text', label: 'Cancelar', onClick: function () { sheet.close(); } }),
        goBtn));

    sheet = ui.openSheet({ title: 'Agregar por dirección', content: form, className: 'sheet-locate', onClose: function () { token++; } });
    setTimeout(function () { try { f.input.focus({ preventScroll: true }); } catch (e) { /* nada */ } }, 380);
    return sheet;
  }

  MS.locate = { open: open, parse: parse, parseCoords: parseCoords, geocode: geocode, resolveShort: resolveShort };

})(window.MS = window.MS || {});
