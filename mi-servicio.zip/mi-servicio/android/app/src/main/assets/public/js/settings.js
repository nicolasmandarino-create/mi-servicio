/* Mi Servicio – ajustes: tema, mapas sin conexión, copia de seguridad y datos de la app */
(function (MS) {
  'use strict';

  var h = MS.h, ui = MS.ui, store = MS.store;

  var LEVELS = [
    { z: 14, label: 'Calles', hint: 'Máximo detalle' },
    { z: 13, label: 'Barrios', hint: 'Detalle medio' },
    { z: 12, label: 'Región', hint: 'Zonas amplias' }
  ];
  var THEMES = [
    { id: 'system', label: 'Sistema' },
    { id: 'light', label: 'Claro' },
    { id: 'dark', label: 'Oscuro' }
  ];

  var sheet = null;
  var view = 'main';       // main | offline
  var download = null;     // { ctl } mientras hay una descarga en curso

  function nf(n) { return Math.round(n).toLocaleString('es-AR'); }
  function plural(n, one, many) { return nf(n) + ' ' + (n === 1 ? one : many); }
  function levelLabel(z) {
    for (var i = 0; i < LEVELS.length; i++) if (LEVELS[i].z === z) return LEVELS[i].label.toLowerCase();
    return 'nivel ' + z;
  }

  /* ---------- Piezas comunes ---------- */
  function group(title, children) {
    return h('section', { class: 'group' }, title ? h('h3', { class: 'group-title' }, title) : null, children);
  }
  function listItem(o) {
    var tag = o.onClick ? 'button' : 'div';
    var el = h(tag, { type: o.onClick ? 'button' : null, class: 'list-item' + (o.onClick ? ' ripple' : '') },
      o.icon ? h('span', { class: 'li-ic', html: MS.icon(o.icon, 24) }) : null,
      h('span', { class: 'li-text' },
        h('span', { class: 'li-title' }, o.title),
        o.sub ? h('span', { class: 'li-sub', dataset: { role: 'sub' } }, o.sub) : null),
      o.trail || null);
    if (o.onClick) el.addEventListener('click', o.onClick);
    return el;
  }
  function segmented(options, value, onChange, label, withHints) {
    var wrap = h('div', { class: 'segmented', role: 'radiogroup', 'aria-label': label });
    function set(v) {
      value = v;
      MS.$$('.seg', wrap).forEach(function (b) {
        var on = b.dataset.v === String(v);
        b.classList.toggle('on', on);
        b.setAttribute('aria-checked', on ? 'true' : 'false');
      });
    }
    options.forEach(function (o) {
      var id = o.id != null ? o.id : o.z;
      var b = h('button', { type: 'button', class: 'seg ripple', role: 'radio', 'aria-checked': 'false', dataset: { v: String(id) } });
      b.innerHTML = '<span class="seg-ic">' + MS.icon('check', 18) + '</span><span>' + MS.esc(o.label) + '</span>';
      b.addEventListener('click', function () {
        if (String(value) === String(id)) return;
        set(id);
        onChange(id);
      });
      wrap.appendChild(b);
    });
    set(value);
    return wrap;
  }
  function link(text, url) {
    return h('a', { href: url, target: '_blank', rel: 'noopener' }, text);
  }
  function closeAll() {
    if (!sheet) return;
    if (download) sheet.close();      // beforeClose pregunta si se cancela la descarga
    else sheet.close(true);
  }

  /* =====================================================================
   * Pantalla principal
   * ===================================================================== */
  function peopleSummary() {
    var visits = 0;
    store.people.forEach(function (p) { visits += store.visitCount(p); });   // sin contar los "No en casa"
    return plural(store.people.length, 'persona', 'personas') + ' y ' + plural(visits, 'visita', 'visitas');
  }

  /** Pasos para instalar la versión web en la pantalla de inicio del iPhone. */
  function showInstallHelp() {
    ui.dialog({
      title: 'Instalar en el iPhone',
      content: h('div', null,
        h('ol', { class: 'install-steps' },
          h('li', null, 'Abra esta página en Safari.'),
          h('li', null, 'Toque Compartir (el cuadrado con una flecha hacia arriba). Si no lo ve, toque los tres puntos y luego Compartir.'),
          h('li', null, 'Elija "Agregar a pantalla de inicio". Si aparece "Abrir como app web", déjelo activado. Luego toque "Agregar".'),
          h('li', null, 'Abra Mi Servicio siempre desde ese ícono.')),
        h('p', { class: 'dialog-text install-note' },
          'Los datos cargados en Safari no pasan a la app instalada. Si ya registró personas, exporte antes una copia de seguridad e impórtela después.')),
      confirmLabel: 'Entendido', cancelLabel: null
    });
  }

  function buildMain() {
    var theme = segmented(THEMES, store.getSetting('theme') || 'system', function (v) {
      store.setSetting('theme', v);
      MS.app.applyTheme();
    }, 'Tema de la aplicación');

    var offItem = listItem({
      icon: 'cloud-download', title: 'Mapas sin conexión', sub: 'Guarde zonas del mapa para usarlas sin internet',
      trail: h('span', { class: 'li-trail', html: MS.icon('chevron', 24) }), onClick: showOffline
    });
    Promise.all([MS.tiles.listAreas(), MS.tiles.stats()]).then(function (r) {
      var sub = offItem.querySelector('[data-role="sub"]');
      if (!sub) return;
      sub.textContent = r[0].length
        ? plural(r[0].length, 'zona guardada', 'zonas guardadas') + ' (' + MS.formatBytes(r[1].pinned.bytes) + ')'
        : 'Guarde zonas del mapa para usarlas sin internet';
    });

    return h('div', { class: 'settings' },
      ui.sheetHead('Ajustes', closeAll),
      group('Apariencia', [
        h('p', { class: 'group-hint' }, 'Tema de colores de la aplicación y del mapa.'),
        theme
      ]),
      group('Mapa', offItem),
      group('Datos', [
        listItem({ icon: 'share', title: 'Exportar copia de seguridad', sub: peopleSummary(), onClick: exportBackup }),
        listItem({ icon: 'upload', title: 'Importar copia de seguridad', sub: 'Desde un archivo .json de Mi Servicio', onClick: importBackup })
      ]),
      (MS.isIOS() && !MS.isNative() && !MS.isStandalone())
        ? group('Instalación', listItem({
            icon: 'phone', title: 'Instalar en el iPhone',
            sub: 'Para usarla sin conexión y que sus datos no se borren', onClick: showInstallHelp }))
        : null,
      group('Acerca de', h('div', { class: 'about' },
        h('p', { class: 'about-name' }, 'Mi Servicio', h('span', { class: 'about-ver' }, 'versión ' + MS.VERSION)),
        h('p', { class: 'about-privacy' }, h('span', { html: MS.icon('lock', 18) }),
          'Sus datos se guardan solo en este teléfono. La app no usa cuentas ni servidores propios y solo se conecta a internet para descargar mapas.'),
        h('p', { class: 'about-credits' },
          'Teselas de ', link('OpenFreeMap', 'https://openfreemap.org'), ' (', link('© OpenMapTiles', 'https://www.openmaptiles.org/'),
          ') con datos de los ', link('colaboradores de OpenStreetMap', 'https://www.openstreetmap.org/copyright'),
          '. Mapa dibujado con ', link('MapLibre GL JS', 'https://maplibre.org'),
          '. Tipografías Atkinson Hyperlegible Next y Noto Sans (licencia SIL OFL). Íconos de Material Symbols (licencia Apache 2.0).')
      ))
    );
  }

  function showMain() {
    view = 'main';
    if (sheet) sheet.setContent(buildMain());
  }

  /* =====================================================================
   * Mapas sin conexión
   * ===================================================================== */
  function defaultName() { return 'Zona del ' + MS.formatDateShort(MS.todayISO()); }

  function buildOffline() {
    var OFF = MS.MAP.offline;
    var level = LEVELS[0].z;
    var bounds = MS.mapCtl.getBounds();

    var nameF = ui.field({ label: 'Nombre de la zona', value: defaultName(), maxlength: 60, enterkeyhint: 'done' });
    var est = h('div', { class: 'estimate', 'aria-live': 'polite' });
    var notice = h('div', { class: 'notice', hidden: true, role: 'status' });
    var bar = h('div', { class: 'progress-bar' });
    var track = h('div', { class: 'progress', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': '0' }, bar);
    var progText = h('p', { class: 'progress-text' });
    var cancelBtn = ui.button({ variant: 'text', label: 'Cancelar descarga', danger: true, onClick: function () { if (download) download.ctl.abort(); } });
    var progress = h('div', { class: 'dl', hidden: true }, track, progText, cancelBtn);
    var go = ui.button({ variant: 'filled', label: 'Descargar esta zona', icon: 'cloud-download', onClick: start });
    var areasEl = h('div', { class: 'areas' });
    var cacheEl = h('div', { class: 'cache' });

    var levels = segmented(LEVELS.map(function (l) { return { z: l.z, label: l.label }; }), level, function (z) {
      level = z; renderEstimate();
    }, 'Nivel de detalle');

    function renderEstimate() {
      var count = MS.tiles.countTiles(bounds, OFF.minZoom, level);
      var bytes = MS.tiles.estimateBytes(bounds, OFF.minZoom, level);
      var tooMany = count > OFF.maxTiles;
      var online = MS.tiles.isOnline();
      est.textContent = '';
      est.append(
        (count === 1 ? 'Una tesela' : 'Unas ' + nf(count) + ' teselas') + ', cerca de ' + MS.formatBytes(bytes) + '.',
        h('span', { class: 'est-size' }, 'Es una estimación: el tamaño real depende de cuántas calles y edificios tenga la zona.'));
      var msg = '';
      if (!online) msg = 'No hay conexión a internet. Conéctese para descargar la zona.';
      else if (tooMany) msg = 'La zona es demasiado grande: el máximo es de ' + nf(OFF.maxTiles) + ' teselas por descarga. Acerque el mapa o elija menos detalle.';
      else if (bytes > OFF.maxBytes) msg = 'Es probable que se guarde solo una parte de la zona: el límite es de ' + Math.round(OFF.maxBytes / 1048576) + ' MB por descarga.';
      notice.hidden = !msg;
      notice.textContent = msg;
      notice.classList.toggle('warn', !!msg && (tooMany || !online));
      go.disabled = tooMany || !online || !!download;
    }

    function setBusy(on) {
      progress.hidden = !on;
      go.hidden = on;
      nameF.input.disabled = on;
      MS.$$('.seg', levels).forEach(function (b) { b.disabled = on; });
      if (on) { bar.style.width = '0%'; progText.textContent = 'Preparando la descarga…'; track.setAttribute('aria-valuenow', '0'); }
      renderEstimate();
    }
    var raf = 0, last = null;
    function onProgress(p) {
      last = p;
      if (raf) return;
      raf = requestAnimationFrame(function () {
        raf = 0;
        var pct = Math.round(last.done / Math.max(1, last.total) * 100);
        bar.style.width = pct + '%';
        track.setAttribute('aria-valuenow', String(pct));
        progText.textContent = nf(last.done) + ' de ' + nf(last.total) + ' teselas (' + MS.formatBytes(last.bytes) + ')';
      });
    }

    function start() {
      var ctl = new AbortController();
      download = { ctl: ctl };
      setBusy(true);
      MS.tiles.downloadArea({ name: nameF.value.trim() || defaultName(), bounds: bounds, maxZoom: level }, onProgress, ctl.signal)
        .then(function (r) {
          download = null; setBusy(false);
          ui.snack(r.area.partial ? 'Zona guardada en parte: se alcanzó el límite de la descarga.' : 'Zona guardada para usar sin conexión.', { duration: 6000 });
          renderLists();
        })
        .catch(function (e) {
          download = null; setBusy(false);
          var code = e && e.code;
          ui.snack(code === 'aborted' ? 'Descarga cancelada.'
            : code === 'offline' ? 'No hay conexión a internet.'
            : code === 'too-big' ? 'La zona es demasiado grande.'
            : 'No se pudo descargar la zona. Revise la conexión e intente de nuevo.');
        });
    }

    function renderLists() {
      Promise.all([MS.tiles.listAreas(), MS.tiles.stats()]).then(function (r) {
        var areas = r[0], st = r[1];
        areasEl.textContent = '';
        if (!areas.length) {
          areasEl.appendChild(h('p', { class: 'muted' }, 'Todavía no hay zonas guardadas.'));
        }
        areas.slice().reverse().forEach(function (a) {
          areasEl.appendChild(h('div', { class: 'area' },
            h('span', { class: 'li-ic', html: MS.icon('map', 24) }),
            h('div', { class: 'li-text' },
              h('span', { class: 'li-title' }, a.name),
              h('span', { class: 'li-sub' }, plural(a.tiles, 'tesela', 'teselas') + ', ' + MS.formatBytes(a.bytes) + (a.partial ? ' (parcial)' : '')),
              h('span', { class: 'li-sub' }, 'Detalle de ' + levelLabel(a.maxZoom) + ', guardada el ' + new Date(a.date).toLocaleDateString('es-AR'))),
            h('div', { class: 'area-actions' },
              ui.iconButton({ icon: 'map', label: 'Ver "' + a.name + '" en el mapa', onClick: function () {
                sheet.close(true).then(function () { MS.mapCtl.fitBounds(a.bounds); });
              } }),
              ui.iconButton({ icon: 'delete', label: 'Eliminar "' + a.name + '"', onClick: function () {
                ui.dialog({
                  title: '¿Eliminar "' + a.name + '"?',
                  text: 'Se borrarán las teselas guardadas de esta zona. Podrá volver a descargarla cuando tenga conexión.',
                  confirmLabel: 'Eliminar', danger: true
                }).then(function (ok) {
                  if (!ok) return;
                  MS.tiles.removeArea(a.id).then(function () { ui.snack('Zona eliminada.'); renderLists(); });
                });
              } }))));
        });
        cacheEl.textContent = '';
        cacheEl.appendChild(listItem({
          icon: 'storage', title: 'Mapas vistos recientemente',
          sub: plural(st.auto.count, 'tesela', 'teselas') + ' (' + MS.formatBytes(st.auto.bytes) + '). Se guardan solas al navegar con conexión.',
          trail: ui.button({ variant: 'text', label: 'Vaciar', onClick: function () {
            if (!st.auto.count) { ui.snack('No hay mapas para vaciar.'); return; }
            ui.dialog({
              title: '¿Vaciar los mapas vistos?', text: 'Se borrarán las teselas guardadas automáticamente. Las zonas descargadas no se tocan.',
              confirmLabel: 'Vaciar', danger: true
            }).then(function (ok) {
              if (!ok) return;
              MS.tiles.clearAuto().then(function () { ui.snack('Mapas vistos eliminados.'); renderLists(); });
            });
          } })
        }));
      });
    }

    var root = h('div', { class: 'settings offline' },
      ui.sheetHead('Mapas sin conexión', closeAll, { back: function () { sheet.close(); } }),
      h('p', { class: 'lead' }, 'Se guarda toda la zona que se ve en el mapa. Antes de descargar, acerque el mapa a la zona que necesita.'),
      group(null, [
        h('div', { class: 'form-label' }, 'Nivel de detalle'),
        levels,
        h('p', { class: 'group-hint' }, 'Calles sirve para ubicar direcciones. Barrios y Región cubren áreas más grandes con menos detalle.'),
        est, notice,
        nameF.el,
        h('div', { class: 'sheet-actions' }, go),
        progress,
        h('p', { class: 'group-hint' }, 'Las descargas usan los servidores gratuitos de OpenFreeMap, que permiten hasta ' + nf(OFF.maxTiles) + ' teselas y ' + Math.round(OFF.maxBytes / 1048576) + ' MB por descarga. Para cubrir una zona mayor, descárguela en varias partes.')
      ]),
      group('Zonas guardadas', areasEl),
      group('Caché automática', cacheEl)
    );
    renderEstimate();
    renderLists();
    function onNet() {
      if (!root.isConnected && sheet) { /* la vista ya se reemplazó */ }
      if (!root.isConnected) {
        window.removeEventListener('online', onNet);
        window.removeEventListener('offline', onNet);
        return;
      }
      renderEstimate();
    }
    window.addEventListener('online', onNet);
    window.addEventListener('offline', onNet);
    return root;
  }

  function showOffline() {
    view = 'offline';
    if (sheet) sheet.setContent(buildOffline());
  }

  /* =====================================================================
   * Copia de seguridad
   * ===================================================================== */
  function exportBackup() {
    var json = JSON.stringify(store.exportData(), null, 1);
    var name = 'mi-servicio-copia-' + MS.todayISO() + '.json';
    if (MS.isNative()) {
      var FS = MS.plugin('Filesystem'), Share = MS.plugin('Share');
      if (!FS || !Share) { ui.snack('No se pudo preparar la copia en este dispositivo.'); return; }
      FS.writeFile({ path: name, data: json, directory: 'CACHE', encoding: 'utf8' })
        .then(function (r) { return Share.share({ title: 'Copia de seguridad de Mi Servicio', url: r.uri, dialogTitle: 'Guardar copia de seguridad' }); })
        .catch(function (e) {
          if (!/cancel/i.test(String(e && (e.message || e)))) ui.snack('No se pudo exportar la copia de seguridad.');
        });
      return;
    }
    // iPhone/iPad: la descarga directa no es confiable; se usa el menú Compartir ("Guardar en Archivos").
    if (MS.isIOS() && navigator.share && navigator.canShare && window.File) {
      var file = null;
      try { file = new File([json], name, { type: 'application/json' }); } catch (e) { file = null; }
      if (file && navigator.canShare({ files: [file] })) {
        navigator.share({ files: [file], title: 'Copia de seguridad de Mi Servicio' })
          .catch(function (e) {
            if (!(e && e.name === 'AbortError')) ui.snack('No se pudo exportar la copia de seguridad.');
          });
        return;
      }
    }
    var url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
    var a = h('a', { href: url, download: name });
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1500);
    ui.snack('Copia de seguridad descargada.');
  }

  function importBackup() {
    var input = h('input', { type: 'file', accept: 'application/json,.json', hidden: true });
    document.body.appendChild(input);
    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      input.remove();
      if (!file) return;
      file.text().then(function (txt) {
        var obj = JSON.parse(txt);
        if (!obj || obj.app !== 'mi-servicio' || !Array.isArray(obj.people)) throw new Error('formato');
        askImport(obj);
      }).catch(function () {
        ui.snack('El archivo no es una copia de seguridad de Mi Servicio.');
      });
    });
    input.click();
  }

  function askImport(obj) {
    var mode = 'merge';
    function radio(value, title, sub) {
      var id = 'imp-' + value;
      var input = h('input', { type: 'radio', name: 'imp-mode', id: id, value: value, checked: value === 'merge' ? true : null });
      input.addEventListener('change', function () { mode = value; });
      return h('label', { class: 'radio-row', for: id }, input,
        h('span', { class: 'li-text' }, h('span', { class: 'li-title' }, title), h('span', { class: 'li-sub' }, sub)));
    }
    var list = h('div', { class: 'radio-list' },
      radio('merge', 'Combinar con los datos actuales', 'Agrega lo nuevo y conserva lo que ya tiene. Recomendado.'),
      radio('replace', 'Reemplazar todo', 'Borra los datos actuales y deja solo los de la copia.'));
    ui.dialog({
      title: 'Importar copia de seguridad',
      text: 'La copia contiene ' + plural(obj.people.length, 'persona', 'personas') + '.',
      content: list, confirmLabel: 'Importar'
    }).then(function (ok) {
      if (!ok) return;
      var before = JSON.parse(JSON.stringify(store.exportData()));
      var r;
      try { r = store.importData(obj, mode); } catch (e) { ui.snack('No se pudo importar la copia de seguridad.'); return; }
      var msg = mode === 'replace'
        ? 'Copia importada: ' + plural(r.added, 'persona', 'personas') + '.'
        : 'Copia importada: ' + plural(r.added, 'persona nueva', 'personas nuevas') + ' y ' + plural(r.updated, 'actualizada', 'actualizadas') + '.';
      ui.snack(msg, { duration: 8000, action: { label: 'Deshacer', onClick: function () { store.importData(before, 'replace'); ui.snack('Importación deshecha.'); } } });
      if (sheet && view === 'main') showMain();
    });
  }

  /* =====================================================================
   * Apertura
   * ===================================================================== */
  function open() {
    if (sheet) return;
    view = 'main';
    sheet = ui.openSheet({
      title: 'Ajustes', content: buildMain(), className: 'sheet-settings',
      beforeClose: function () {
        if (download) {
          return ui.dialog({
            title: '¿Cancelar la descarga?', text: 'Se descartarán las teselas descargadas hasta ahora.',
            confirmLabel: 'Cancelar descarga', cancelLabel: 'Seguir descargando', danger: true
          }).then(function (ok) { if (ok && download) download.ctl.abort(); return ok; });
        }
        if (view !== 'main') { showMain(); return false; }
        return true;
      },
      onClose: function () { sheet = null; view = 'main'; }
    });
  }

  MS.settings = { open: open };

})(window.MS = window.MS || {});
