/* Ajusta el proyecto Android generado por Capacitor (carpeta android/).
 * Es idempotente: se puede ejecutar después de cada `cap sync` sin duplicar cambios.
 *   - Manifiesto: permisos de ubicación, teclado, sin copias automáticas de datos.
 *   - Gradle: versión (desde package.json) y firma de release leída de variables de entorno.
 *   - Recursos: íconos, colores de arranque, y elimina los recursos de ejemplo de Capacitor.
 * Nunca se escriben contraseñas ni claves: la firma usa MS_KEYSTORE_FILE, MS_KEYSTORE_PASSWORD,
 * MS_KEY_ALIAS y MS_KEY_PASSWORD (variables de entorno o secretos de GitHub). */
import { readFileSync, writeFileSync, existsSync, cpSync, rmSync, readdirSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const droid = join(root, 'android');
const app = join(droid, 'app');
const main = join(app, 'src/main');

function fail(msg) { console.error('✖ ' + msg); process.exit(1); }
if (!existsSync(droid)) fail('No existe la carpeta android/. Ejecute primero: npx cap add android');

const rd = (p) => readFileSync(p, 'utf8');
const pkg = JSON.parse(rd(join(root, 'package.json')));
const changes = [];

function edit(file, label, fn) {
  const before = rd(file);
  const after = fn(before);
  if (after !== before) { writeFileSync(file, after); changes.push(label); }
}

/* ---------- AndroidManifest.xml ---------- */
const manifest = join(main, 'AndroidManifest.xml');
edit(manifest, 'AndroidManifest.xml', (x) => {
  x = x.replace(/android:allowBackup="true"/, 'android:allowBackup="false"');
  if (!/android:windowSoftInputMode=/.test(x)) {
    if (!/android:launchMode="singleTask"/.test(x)) fail('AndroidManifest.xml: no se encontró la actividad principal.');
    x = x.replace(/(android:launchMode="singleTask")/, '$1\n            android:windowSoftInputMode="adjustResize"');
  }
  if (!/ACCESS_FINE_LOCATION/.test(x)) {
    const anchor = '<uses-permission android:name="android.permission.INTERNET" />';
    if (!x.includes(anchor)) fail('AndroidManifest.xml: no se encontró el permiso INTERNET.');
    x = x.replace(anchor, anchor + `
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-feature android:name="android.hardware.location" android:required="false" />
    <uses-feature android:name="android.hardware.location.gps" android:required="false" />`);
  }
  return x;
});

/* ---------- app/build.gradle ---------- */
const [maj, min, pat] = String(pkg.version).split('.').map((n) => parseInt(n, 10) || 0);
const versionCode = maj * 10000 + min * 100 + pat;
edit(join(app, 'build.gradle'), 'app/build.gradle', (x) => {
  x = x.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`).replace(/versionName\s+"[^"]*"/, `versionName "${pkg.version}"`);
  if (!x.includes('MS-FIRMA')) {
    if (!/buildTypes\s*\{\s*release\s*\{/.test(x)) fail('app/build.gradle: no se encontró buildTypes.release.');
    x = x.replace(/(\n\s*)buildTypes\s*\{\s*release\s*\{/, `$1// MS-FIRMA: la clave se toma de variables de entorno; nunca se guarda en el repositorio.
    signingConfigs {
        release {
            def ksFile = System.getenv('MS_KEYSTORE_FILE')
            if (ksFile) {
                storeFile file(ksFile)
                storePassword System.getenv('MS_KEYSTORE_PASSWORD')
                keyAlias System.getenv('MS_KEY_ALIAS')
                keyPassword System.getenv('MS_KEY_PASSWORD')
            }
        }
    }
    buildTypes {
        release {
            if (System.getenv('MS_KEYSTORE_FILE')) { signingConfig signingConfigs.release }`);
  }
  return x;
});

/* ---------- Recursos: se copian los propios y se quitan los de ejemplo ---------- */
const res = join(main, 'res');
const ownRes = join(root, 'resources/android/res');
if (!existsSync(ownRes)) fail('Falta resources/android/res.');
cpSync(ownRes, res, { recursive: true, force: true });

const leftovers = ['drawable/ic_launcher_background.xml', 'drawable-v24/ic_launcher_foreground.xml', 'values/ic_launcher_background.xml'];
leftovers.forEach((f) => { const p = join(res, f); if (existsSync(p)) { rmSync(p); changes.push('quitado ' + f); } });
readdirSync(res).filter((d) => d.startsWith('drawable')).forEach((d) => {
  const p = join(res, d, 'splash.png');
  if (existsSync(p) && statSync(p).isFile()) { rmSync(p); if (!changes.includes('quitado splash.png')) changes.push('quitado splash.png'); }
});

edit(join(res, 'values/styles.xml'), 'values/styles.xml', (x) => {
  if (!/NoActionBarLaunch/.test(x)) fail('styles.xml: no se encontró AppTheme.NoActionBarLaunch.');
  x = x.replace(/<item name="android:background">@drawable\/splash<\/item>/, '<item name="android:background">@color/ms_splash_background</item>');
  if (!/windowSplashScreenBackground/.test(x)) {
    x = x.replace(/(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)/, '$1\n        <item name="windowSplashScreenBackground">@color/ms_splash_background</item>');
  }
  return x;
});

console.log(changes.length ? '✔ Android ajustado:\n  - ' + changes.join('\n  - ') : '✔ Android: sin cambios pendientes.');
