/* Genera los íconos de Android a partir de www/icons/*.svg (requiere `rsvg-convert`).
 * Solo hace falta volver a correrlo si cambia el diseño del ícono; los PNG ya están en resources/android/res. */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const src = (n) => readFileSync(join(root, 'www/icons', n), 'utf8');
const out = join(root, 'resources/android/res');
const inner = (svg) => svg.replace(/^[\s\S]*?<svg[^>]*>/, '').replace(/<\/svg>\s*$/, '');

const DENSITIES = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
const NS = 'xmlns="http://www.w3.org/2000/svg"';
const full = inner(src('icon.svg'));

// Íconos clásicos (Android 7.x): se recorta la zona central de 72×72 del lienzo adaptativo.
const legacySquare = `<svg ${NS} viewBox="18 18 72 72"><defs><clipPath id="c"><rect x="18" y="18" width="72" height="72" rx="15"/></clipPath></defs><g clip-path="url(#c)">${full}</g></svg>`;
const legacyRound = `<svg ${NS} viewBox="18 18 72 72"><defs><clipPath id="c"><circle cx="54" cy="54" r="36"/></clipPath></defs><g clip-path="url(#c)">${full}</g></svg>`;

const jobs = [
  ['ic_launcher', legacySquare, 48],
  ['ic_launcher_round', legacyRound, 48],
  ['ic_launcher_foreground', src('icon-foreground.svg'), 108],
  ['ic_launcher_background', src('icon-background.svg'), 108],
  ['ic_launcher_monochrome', src('icon-monochrome.svg'), 108]
];

for (const [dens, k] of Object.entries(DENSITIES)) {
  const dir = join(out, 'mipmap-' + dens);
  mkdirSync(dir, { recursive: true });
  for (const [name, svg, base] of jobs) {
    const px = Math.round(base * k);
    const tmp = join('/tmp', `ms-${name}.svg`);
    writeFileSync(tmp, svg);
    execFileSync('rsvg-convert', ['-w', String(px), '-h', String(px), '-o', join(dir, name + '.png'), tmp]);
  }
}

const adaptive = (mono) => `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@mipmap/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
    <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>
</adaptive-icon>
`;
mkdirSync(join(out, 'mipmap-anydpi-v26'), { recursive: true });
writeFileSync(join(out, 'mipmap-anydpi-v26/ic_launcher.xml'), adaptive());
writeFileSync(join(out, 'mipmap-anydpi-v26/ic_launcher_round.xml'), adaptive());
console.log('Íconos generados en resources/android/res');
