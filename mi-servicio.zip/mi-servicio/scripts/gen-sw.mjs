// Genera la lista de archivos y la versión del service worker a partir del contenido de www/.
// Uso: node scripts/gen-sw.mjs
import { readdirSync, readFileSync, writeFileSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join, relative, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(fileURLToPath(new URL('..', import.meta.url)), 'www');
const skip = new Set(['sw.js']);
const files = [];
(function walk(dir) {
  for (const name of readdirSync(dir).sort()) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) { walk(p); continue; }
    const rel = relative(root, p).split(sep).join('/');
    if (!skip.has(rel) && !rel.endsWith('.map')) files.push(rel);
  }
})(root);

const hash = createHash('sha1');
for (const f of files) { hash.update(f); hash.update(readFileSync(join(root, f))); }
const version = 'ms-' + hash.digest('hex').slice(0, 10);
const list = ['./', ...files.map((f) => encodeURI(f))];

const swPath = join(root, 'sw.js');
const src = readFileSync(swPath, 'utf8');
const block = `/*PRECACHE-START*/\nconst VERSION = '${version}';\nconst FILES = ${JSON.stringify(list, null, 1)};\n/*PRECACHE-END*/`;
const out = src.replace(/\/\*PRECACHE-START\*\/[\s\S]*?\/\*PRECACHE-END\*\//, block);
writeFileSync(swPath, out);
console.log(`sw.js: ${version}, ${list.length} archivos`);
