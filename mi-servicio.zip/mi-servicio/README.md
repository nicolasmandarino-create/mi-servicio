# Mi Servicio

Aplicación móvil para registrar personas en un mapa y llevar el seguimiento cronológico de visitas. Funciona 100 % en el teléfono: sin cuentas, sin servidores propios y sin servicios pagos.

- Diseño Material Design 3, modo claro y oscuro (sigue al sistema o se elige en Ajustes).
- Mapa interactivo con ubicación actual y mapas descargables para usar sin internet.
- Alta tocando el mapa, historial de notas con fecha, filtros y buscador en tiempo real.
- Botón **Ir / Maps** que abre la aplicación de Google Maps con las coordenadas de destino.
- Tecnología: HTML/CSS/JavaScript sin paso de compilación, [MapLibre GL JS](https://maplibre.org) y [Capacitor](https://capacitorjs.com) para generar el APK.

## 1. Probar en el navegador

Requiere Node.js 22 o superior.

```bash
npm install
npm run serve          # http://localhost:8080
```

La ubicación del dispositivo solo funciona en `localhost` o en sitios `https`. Para probar desde el celular sin generar el APK, publique la carpeta `www/` en cualquier hosting estático con HTTPS (por ejemplo GitHub Pages): también se instala como PWA.

## 2. Generar el APK (gratis)

### Opción A: GitHub Actions (no requiere instalar nada)

1. Suba este proyecto a un repositorio de GitHub.
2. Configure la firma una única vez (ver sección 3).
3. Entre en **Actions → Compilar APK → Run workflow**.
4. Al terminar (unos 5 a 10 minutos), descargue **mi-servicio-apk** desde la sección *Artifacts* de la ejecución.
5. Copie el `.apk` al teléfono e instálelo (Android pedirá permitir instalaciones de este origen).

### Opción B: Android Studio

1. Instale Node.js 22+ y Android Studio (incluye JDK 21).
2. En la carpeta del proyecto: `npm install` y luego `npm run android:sync`.
3. `npm run android:open`, y en Android Studio: **Build → Build APK(s)**. También puede conectar el teléfono por USB y presionar **Run**.

Si la carpeta `android/` no existiera, `npx cap add android` la crea y `npm run android:sync` la ajusta (permisos de ubicación, íconos, versión y firma).

## 3. Firma y actualizaciones (importante para no perder datos)

Android solo permite actualizar una app si la nueva versión está firmada con **la misma clave**. Con una clave distinta hay que desinstalar la anterior, y **al desinstalar se borran los datos locales**. Por eso conviene firmar siempre con una clave propia:

1. Genere la clave una sola vez (el comando pide las contraseñas por pantalla):
   ```bash
   keytool -genkeypair -v -keystore miservicio.jks -alias miservicio -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Guarde `miservicio.jks` y sus contraseñas en su gestor de contraseñas. Si se pierden, no se pueden recuperar.
3. Convierta el archivo a texto: `base64 -w0 miservicio.jks` (Linux), `base64 -i miservicio.jks` (macOS) o, en PowerShell, `[Convert]::ToBase64String([IO.File]::ReadAllBytes("miservicio.jks"))`.
4. En GitHub: **Settings → Secrets and variables → Actions → New repository secret**, y cree estos cuatro secretos:

   | Secreto | Contenido |
   |---|---|
   | `ANDROID_KEYSTORE_BASE64` | El texto del paso 3 |
   | `ANDROID_KEYSTORE_PASSWORD` | Contraseña del almacén de claves |
   | `ANDROID_KEY_ALIAS` | `miservicio` |
   | `ANDROID_KEY_PASSWORD` | Contraseña de la clave |

Nunca suba el `.jks` ni las contraseñas al repositorio (el `.gitignore` ya excluye `*.jks`). Sin estos secretos el flujo compila un APK de depuración con clave temporal: sirve para probar, pero no se instala como actualización.

Para publicar una versión nueva, suba el número de `version` en `package.json` (el código de versión de Android se calcula solo) y vuelva a ejecutar el flujo.

## 4. Mapas sin conexión

- Los mapas vienen de [OpenFreeMap](https://openfreemap.org) (gratuito, sin clave ni registro). Cada vez que se mira una zona con internet, las teselas quedan guardadas automáticamente en el teléfono.
- Para dejar una zona completa: **Ajustes → Mapas sin conexión**. Primero acerque el mapa a la zona, elija el nivel de detalle (Calles, Barrios o Región) y descargue. La pantalla muestra la estimación de teselas y tamaño antes de empezar.
- OpenFreeMap permite descargas manuales de hasta **3.000 teselas y 50 MB**, con 4 solicitudes simultáneas. La aplicación respeta esos límites; para cubrir una zona mayor, descárguela en varias partes.
- La atribución («OpenFreeMap © OpenMapTiles, datos de OpenStreetMap») debe permanecer visible en el mapa.
- Para usar otro proveedor de teselas con el esquema OpenMapTiles, cambie los valores de `MS.MAP` en `www/js/config.js`.

## 5. Datos y privacidad

- Todo se guarda en el teléfono (IndexedDB). La app solo usa internet para descargar mapas.
- Android no hace copias automáticas de los datos (`allowBackup` desactivado). Haga una copia manual en **Ajustes → Exportar copia de seguridad**, que genera un archivo `.json` para guardar o compartir. **Importar** admite combinar o reemplazar.
- La ubicación se usa solo para mostrar el punto en el mapa: no se envía a ningún servidor ni se guarda como registro. La app únicamente recuerda la última vista del mapa (centro y zoom) para retomarla al abrir.

## 6. Estructura

```
www/                  Aplicación web (index.html, css/, js/, fonts/, sprites/, icons/, sw.js)
resources/android/    Íconos y colores de arranque que se aplican al proyecto Android
scripts/              serve.mjs, gen-sw.mjs (caché PWA), patch-android.mjs, gen-android-icons.mjs
android/              Proyecto nativo generado por Capacitor
.github/workflows/    build-apk.yml
licenses/             Licencias de componentes de terceros
```

Después de editar archivos de `www/`, ejecute `npm run android:sync` para copiarlos al proyecto Android (también regenera la lista de archivos del service worker).

## 7. Estado de verificación

- La aplicación se probó en un navegador móvil emulado (tema claro y oscuro, alta, historial, filtros, buscador, copias de seguridad, descarga de zonas y uso sin conexión) con teselas sintéticas, no con las de OpenFreeMap real.
- El APK no pudo compilarse en el entorno de desarrollo por falta de acceso a los repositorios de Android; la compilación se realiza en GitHub Actions o Android Studio. Conviene probar en un teléfono real la ubicación, el botón **Ir / Maps** y la descarga de una zona pequeña.

## Licencias y atribuciones

Teselas © [OpenFreeMap](https://openfreemap.org) / [OpenMapTiles](https://www.openmaptiles.org), datos © colaboradores de [OpenStreetMap](https://www.openstreetmap.org/copyright). Mapa dibujado con MapLibre GL JS (BSD-3-Clause). Estilo derivado de «Positron» (CARTO, BSD-3-Clause / CC-BY 3.0). Tipografías Atkinson Hyperlegible Next y Noto Sans (SIL OFL 1.1). Íconos Material Symbols (Apache 2.0). Los textos completos están en `licenses/`.
