# Mi Servicio

Aplicación móvil para registrar personas en un mapa y llevar el seguimiento cronológico de visitas. Funciona 100 % en el teléfono: sin cuentas, sin servidores propios y sin servicios pagos.

- Diseño Material Design 3, modo claro y oscuro (sigue al sistema o se elige en Ajustes).
- Mapa interactivo con ubicación actual y mapas descargables para usar sin internet.
- Alta tocando el mapa, historial de notas con fecha, filtros y buscador en tiempo real.
- Botón **Agregar aquí**: espera la mejor lectura del GPS (acepta enseguida una de ±12 m o menos; si no llega, usa la mejor que haya tras unos segundos y lo avisa) y abre el alta en el lugar donde está parado/a, mostrando la precisión. Tocar cualquier punto del mapa sigue funcionando.
- **No en casa**: con un toque queda registrada la fecha en que se fue y no se encontró a la persona (con «Deshacer»); el marcador del mapa muestra una puerta hasta la próxima visita. El botón está en la ficha y también junto a «Agregar nota» (usa la fecha elegida y, si se escribió algo, lo guarda como comentario), tanto desde Explorar Mapa como desde Personas.
- Gesto o botón **atrás** (Android): cierra la pantalla abierta; desde Personas vuelve a Explorar Mapa y, estando en Explorar Mapa, sale de la app.
- **Territorio** (número del 1 al 99) en cada lugar: se ve en la ficha y en el listado, y se puede buscar («territorio 33»).
- El mapa se gira con dos dedos; una brújula debajo del botón de ajustes lo vuelve al norte.
- Botón **Ir / Maps** que abre la aplicación de Google Maps con las coordenadas de destino.
- También se instala en el iPhone como app web, sin App Store ni costo (sección 7).
- Tecnología: HTML/CSS/JavaScript sin paso de compilación, [MapLibre GL JS](https://maplibre.org) y [Capacitor](https://capacitorjs.com) para generar el APK.

## 1. Probar en el navegador

Requiere Node.js 22 o superior.

```bash
npm install
npm run serve          # http://localhost:8080
```

La ubicación del dispositivo solo funciona en `localhost` o en sitios `https`. Para probar desde el celular sin generar el APK, publique la carpeta `www/` en cualquier hosting estático con HTTPS (por ejemplo GitHub Pages): también se instala como PWA (ver sección 7).

## 2. Generar el APK (gratis)

### Opción A: GitHub Actions (no requiere instalar nada)

1. Suba este proyecto a un repositorio de GitHub.
2. Configure la firma una única vez (ver sección 3).
3. Entre en **Actions → Compilar APK → Run workflow**.
4. Al terminar (unos 5 a 10 minutos), descargue **mi-servicio-apk** desde la sección *Artifacts* de la ejecución.
5. Copie el `.apk` al teléfono e instálelo (Android pedirá permitir instalaciones de este origen).

### Opción B: Android Studio

1. Instale Node.js 22+ y Android Studio (incluye JDK 21).
2. En la carpeta del proyecto: `npm install` y luego `npm run android:sync`.
3. `npm run android:open`, y en Android Studio: **Build → Build APK(s)**. También puede conectar el teléfono por USB y presionar **Run**.

Si la carpeta `android/` no existiera, `npx cap add android` la crea y `npm run android:sync` la ajusta (permisos de ubicación, íconos, versión y firma).

## 3. Firma y actualizaciones (importante para no perder datos)

Android solo permite actualizar una app si la nueva versión está firmada con **la misma clave**. Con una clave distinta hay que desinstalar la anterior, y **al desinstalar se borran los datos locales**. Por eso conviene firmar siempre con una clave propia:

1. Genere la clave una sola vez (el comando pide las contraseñas por pantalla):
   ```bash
   keytool -genkeypair -v -keystore miservicio.jks -alias miservicio -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Guarde `miservicio.jks` y sus contraseñas en su gestor de contraseñas. Si se pierden, no se pueden recuperar.
3. Convierta el archivo a texto: `base64 -w0 miservicio.jks` (Linux), `base64 -i miservicio.jks` (macOS) o, en PowerShell, `[Convert]::ToBase64String([IO.File]::ReadAllBytes("miservicio.jks"))`.
4. En GitHub: **Settings → Secrets and variables → Actions → New repository secret**, y cree estos cuatro secretos:

   | Secreto | Contenido |
   |---|---|
   | `ANDROID_KEYSTORE_BASE64` | El texto del paso 3 |
   | `ANDROID_KEYSTORE_PASSWORD` | Contraseña del almacén de claves |
   | `ANDROID_KEY_ALIAS` | `miservicio` |
   | `ANDROID_KEY_PASSWORD` | Contraseña de la clave |

Nunca suba el `.jks` ni las contraseñas al repositorio (el `.gitignore` ya excluye `*.jks`). Sin estos secretos el flujo compila un APK de depuración con clave temporal: sirve para probar, pero no se instala como actualización.

Para publicar una versión nueva, suba el número de `version` en `package.json` (el código de versión de Android se calcula solo) y vuelva a ejecutar el flujo.

### Firma automática sin secretos (flujo `apk.yml`, pensado para usar solo desde el teléfono)

El archivo `docs/apk.yml` es el flujo que se usa cuando el repositorio contiene solo `mi-servicio.zip` y `.github/workflows/apk.yml`: cada vez que se sube un zip nuevo (a cualquier carpeta del repositorio; se usa el más reciente) compila el APK y publica la web. Para que cada APK se instale **encima** del anterior sin borrar datos, guarda la clave de depuración en la caché de GitHub (no en el repositorio):

- La primera compilación crea la clave y la guarda; las siguientes la reutilizan y la ejecución lo indica («Firma del APK»). En los ejecutores de GitHub Android crea la clave en `~/.config/.android/debug.keystore` (no en `~/.android`); si algún día cambiara, el paso «Estado de la firma» avisa con «Firma del APK sin guardar».
- Si GitHub Pages no está activado, la web de iPhone no se publica y se deja un aviso amarillo; el APK no se ve afectado.
- Las compilaciones se ejecutan de a una (si se suben dos archivos seguidos, la segunda espera a la primera), para que ambas usen la misma clave.
- GitHub borra las cachés que pasan 7 días sin usarse. Una ejecución programada (cada 3 días, `mantener-firma`) la mantiene viva sin compilar nada. En repositorios públicos GitHub pausa las ejecuciones programadas tras 60 días sin actividad (se reactivan con el botón «Enable workflow» en la pestaña Actions; GitHub suele avisar por correo antes de pausarlas).
- Si la firma se pierde o se cambia el nombre de la clave (`mi-servicio-firma-v1`), el siguiente APK tendrá una firma nueva: **antes de desinstalar haga la copia de seguridad** (Ajustes → Exportar), instale el APK nuevo e importe la copia.
- Es una clave de depuración: sirve para actualizar la app en su teléfono, pero no para publicar en Google Play (para eso use la clave propia de arriba).

## 4. Mapas sin conexión

- Los mapas vienen de [OpenFreeMap](https://openfreemap.org) (gratuito, sin clave ni registro). Cada vez que se mira una zona con internet, las teselas quedan guardadas automáticamente en el teléfono.
- Para dejar una zona completa: **Ajustes → Mapas sin conexión**. Primero acerque el mapa a la zona, elija el nivel de detalle (Calles, Barrios o Región) y descargue. La pantalla muestra la estimación de teselas y tamaño antes de empezar.
- OpenFreeMap permite descargas manuales de hasta **3.000 teselas y 50 MB**, con 4 solicitudes simultáneas. La aplicación respeta esos límites; para cubrir una zona mayor, descárguela en varias partes.
- La atribución («OpenFreeMap © OpenMapTiles, datos de OpenStreetMap») debe permanecer visible en el mapa.
- Para usar otro proveedor de teselas con el esquema OpenMapTiles, cambie los valores de `MS.MAP` en `www/js/config.js`.

## 5. Datos y privacidad

- Todo se guarda en el teléfono (IndexedDB). La app solo usa internet para descargar mapas.
- Android no hace copias automáticas de los datos (`allowBackup` desactivado). Haga una copia manual en **Ajustes → Exportar copia de seguridad**, que genera un archivo `.json` para guardar o compartir. **Importar** admite combinar o reemplazar. Las copias hechas con versiones anteriores se importan sin problema (los lugares quedan sin territorio).
- La ubicación se usa solo para mostrar el punto en el mapa: no se envía a ningún servidor ni se guarda como registro. La app únicamente recuerda la última vista del mapa (centro y zoom) para retomarla al abrir.

## 6. Estructura

```
www/                  Aplicación web (index.html, css/, js/, fonts/, sprites/, icons/, sw.js)
resources/android/    Íconos y colores de arranque que se aplican al proyecto Android
scripts/              serve.mjs, gen-sw.mjs (caché PWA), patch-android.mjs, gen-android-icons.mjs
android/              Proyecto nativo generado por Capacitor
.github/workflows/    build-apk.yml (APK) y publicar-web.yml (sitio para iPhone)
docs/                 apk.yml: flujo combinado (APK + web) para usar solo desde el teléfono
licenses/             Licencias de componentes de terceros
```

Después de editar archivos de `www/`, ejecute `npm run android:sync` para copiarlos al proyecto Android (también regenera la lista de archivos del service worker).

## 7. iPhone (app web gratuita)

Apple no permite instalar un APK ni apps propias sin pasar por su programa de desarrollador, que es de pago. La alternativa sin costo es publicar `www/` como sitio web y agregarlo a la pantalla de inicio: se abre a pantalla completa, funciona sin conexión y guarda los datos en el teléfono, como en Android.

### Publicar el sitio (una sola vez)

1. En el repositorio de GitHub entre en **Settings → Pages** y, en **Source**, elija **GitHub Actions**.
2. Ejecute **Actions → Publicar web (iPhone y navegador) → Run workflow**. Desde entonces se vuelve a publicar solo con cada cambio en la rama `main`.
3. La dirección queda como `https://<usuario>.github.io/<repositorio>/` y figura en la ejecución terminada.

### Instalar en el iPhone

1. Abra la dirección en **Safari** (solo Safari instala la app).
2. Toque **Compartir** (si no lo ve, toque los tres puntos y luego **Compartir**) y elija **Agregar a pantalla de inicio**.
3. Si aparece **Abrir como app web** (iOS 26), déjelo activado. Toque **Agregar**.
4. Abra Mi Servicio siempre desde el ícono nuevo, permita la ubicación y descargue su zona en **Ajustes → Mapas sin conexión**.

### Diferencias con Android

- La app instalada guarda sus datos aparte de los de Safari. Para pasar datos entre equipos (por ejemplo desde Android) use **Exportar copia de seguridad** y **Importar copia de seguridad**. En el iPhone el archivo `.json` se envía con el menú Compartir (Guardar en Archivos, AirDrop, WhatsApp, correo).
- Safari borra los datos de los sitios web que no se usan durante 7 días, pero no los de las apps agregadas a la pantalla de inicio. Conviene exportar una copia de vez en cuando.
- **Ir / Maps** pregunta con qué aplicación abrir la ruta: Google Maps o Apple Maps.
- iOS puede volver a pedir el permiso de ubicación. Si el punto no aparece, revise los permisos en Ajustes del iPhone (Privacidad y seguridad) y toque de nuevo el botón de ubicación.
- El teclado del iPhone se superpone a la página; la app sube el formulario para que siga visible.
- La vibración puede no estar disponible en Safari.
- Para publicar una versión nueva, vuelva a ejecutar el flujo. La app instalada la descarga al abrirse con conexión y la muestra la siguiente vez que se abre.

## 8. Estado de verificación

- La aplicación se probó en un navegador móvil emulado (tema claro y oscuro, alta, historial, filtros, buscador, copias de seguridad, descarga de zonas y uso sin conexión) con teselas sintéticas, no con las de OpenFreeMap real.
- El giro del mapa se probó con gestos de dos dedos simulados (rotar, pellizcar para hacer zoom, tocar marcadores y el mapa estando girado), no con un teléfono real; en un teléfono el gesto empieza al torcer unos 25° para no confundirse con el zoom.
- El APK no pudo compilarse en el entorno de desarrollo por falta de acceso a los repositorios de Android; la compilación se realiza en GitHub Actions o Android Studio. Conviene probar en un teléfono real la ubicación, el botón **Ir / Maps** y la descarga de una zona pequeña.
- La versión para iPhone se probó en Chromium con el agente de usuario de iPhone y funciones simuladas (menú Compartir, teclado, permiso de ubicación, instalación en pantalla de inicio, uso en una subcarpeta de GitHub Pages y sin conexión). No se pudo probar en Safari ni en un iPhone real: conviene verificar allí la instalación, la ubicación, el teclado y el uso sin conexión.

## Licencias y atribuciones

Teselas © [OpenFreeMap](https://openfreemap.org) / [OpenMapTiles](https://www.openmaptiles.org), datos © colaboradores de [OpenStreetMap](https://www.openstreetmap.org/copyright). Mapa dibujado con MapLibre GL JS (BSD-3-Clause). Estilo derivado de «Positron» (CARTO, BSD-3-Clause / CC-BY 3.0). Tipografías Atkinson Hyperlegible Next y Noto Sans (SIL OFL 1.1). Íconos Material Symbols (Apache 2.0). Los textos completos están en `licenses/`.
