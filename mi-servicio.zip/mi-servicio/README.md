# Mi Servicio

Aplicación móvil para registrar personas en un mapa y llevar el seguimiento cronológico de visitas. Funciona 100 % en el teléfono: sin cuentas, sin servidores propios y sin servicios pagos.

- Diseño Material Design 3 en violeta, modo claro y oscuro (sigue al sistema o se elige en Ajustes).
- **Mi informe** (tercera pestaña, junto a Explorar Mapa y Personas): el tiempo del mes en un solo total, sin clasificarlo.
  - **Meta del mes** de **15, 30, 50 o 100 horas** (solo esas cuatro opciones): barra de avance, porcentaje, lo que falta, los días que quedan y cuánto habría que hacer por día. La meta se mantiene en los meses siguientes hasta que se cambie.
  - **Calendario** del mes (la semana empieza el lunes): cada día muestra sus horas (H:MM) con un color más intenso cuanto más tiempo, un punto verde si hubo un estudio y un punto ciruela si hay una asignación aprobada. Al tocar un día se ve su detalle.
  - **Cargar horas**: fecha, **horas** y **minutos** (el total del día; si el día ya tenía horas se muestran y el nuevo total las reemplaza) y, opcionalmente, «Hice un estudio este día» eligiendo de la lista de personas en etapa Estudio, con una nota para cada visita.
  - **Horas extras**: no suman a la meta; quedan anotadas como **asignaciones aprobadas** con una descripción corta (hasta 80 caracteres), editables y con «Deshacer».
  - **Enviar informe**: tarjeta «Informe de [mes]» al final del Resumen, con el texto tal como se envía y el botón «Enviar informe», que abre el menú de compartir del teléfono (WhatsApp, correo, etc.); si el teléfono no lo tiene, el texto queda copiado. Sirve para el mes que se está viendo (a fin de mes, o en el mes anterior). El texto es: `INFORME:`, mes y año, `Horas:` (horas **redondas**, ver más abajo), `Estudios:` (cantidad de **personas** con estudio en el mes: varias visitas a la misma persona cuentan una sola vez) y `Actividades teocráticas:` (suma de las horas extras, **sin redondear**; si no hay, esa línea no aparece).
  - **Redondeo de las horas**: si el total del mes no son horas enteras, al tocar «Enviar informe» la app pide elegir **«Hacia arriba»** o **«Hacia abajo»** y muestra qué horas se informarían y cómo empieza el mes siguiente. Ejemplo: el mes termina con 100 h 30 min. Hacia arriba se informan 101 h y el mes siguiente empieza con **−30 min**; hacia abajo se informan 100 h y el mes siguiente empieza **30 min adelantado (+30 min)**. Con horas enteras se envía directo, sin preguntar. El redondeo solo queda registrado si el informe se envía (si se cancela el menú de compartir, no se registra).
  - **Arrastre**: el total del mes siguiente (el de «Mi informe», el avance de la meta y el texto del informe) incluye esa diferencia, y el Resumen lo aclara («Arrastre de noviembre: −30 min»). No se guarda como un número aparte: se calcula con lo cargado y con la opción elegida, así que si se corrige un día del mes anterior el arrastre se ajusta solo. Los redondeos van incluidos en la copia de seguridad.
  - **Todo en sintonía**: un estudio es una sola visita con una sola nota. Si usted anota una visita a una persona en etapa Estudio desde el mapa o desde Personas, aparece sola en Mi informe; si carga un estudio en Mi informe, la visita (con su nota) se agrega a la ficha de la persona. Editar la nota en un lado la cambia en el otro. En cada visita de una persona en Estudio hay un interruptor «Fue un estudio» (activado de entrada) para destildarlo; «No en casa» nunca cuenta.
- Mapa interactivo con ubicación actual y mapas descargables para usar sin internet.
- Alta tocando el mapa, historial de visitas con fecha y hora, filtros y buscador en tiempo real.
- Botón flotante de **ubicación precisa** (solo ícono, debajo del de ubicación): espera la mejor lectura del GPS (acepta enseguida una de ±12 m o menos; si no llega, usa la mejor que haya tras unos segundos y lo avisa) y abre el alta en el lugar donde está parado/a, mostrando la precisión. Mientras espera muestra «Ubicando… ±N m» a su izquierda. Tocar cualquier punto del mapa sigue funcionando.
- **Ficha** de cada persona: arriba los datos y «Ir / Maps»; debajo solo dos botones, **No en casa** y **Nueva visita**, y el historial a la vista. El formulario de visita (fecha, hora y detalle) aparece únicamente al tocar «Nueva visita»; si no se escribe ningún detalle, la visita queda registrada solo con su fecha y hora.
- **No en casa**: con un toque queda registrada la fecha y la hora en que se fue y no se encontró a la persona (con «Deshacer»); el marcador del mapa muestra una puerta hasta la próxima visita. Está en la ficha, tanto desde Explorar Mapa como desde Personas, y no cuenta como visita en el contador.
- **Hora** de cada visita: se propone la hora actual y se puede corregir al cargar o al editar una nota; el historial la muestra junto a la fecha. Las notas cargadas con versiones anteriores muestran su hora solo si se cargaron el mismo día de la visita.
- **Compartir visita** (al final de la ficha): abre el menú de compartir del teléfono (WhatsApp, correo, etc.) con un texto que incluye el nombre, el enlace a Google Maps, la descripción de la casa, el número de territorio, la fecha de la última visita (sin la nota escrita; si la última vez no estaba en casa, esa fecha va en una línea aparte, «No estaba en casa») y si es Primera conversación, Revisita o Estudio. Las líneas que no se completaron se omiten.
- **Orden de Personas**: Últimas visitas (la visita más reciente primero), Más visitadas, Menos visitadas, Más recientes (por fecha de alta) y A–Z. Un **«No en casa» no cuenta como visita** en ningún orden: ni en la cantidad de visitas ni en la fecha de la última visita (la fecha de cada tarjeta es la de la última vez que sí se encontró a la persona; quien nunca fue encontrado queda al final de «Últimas visitas»). Cuenta cuando se ve a la persona y la visita queda en el historial.
- **Agregar por dirección** (en **Ajustes**, la rueda dentada, primer grupo «Personas»): permite cargar a una persona escribiendo una dirección, pegando un enlace de Google Maps o ingresando coordenadas. Se abre el mapa en ese punto con el formulario de alta, listo para completar la fecha y la hora de una visita ya hecha. Ver «Datos y privacidad» para saber qué se consulta por internet.
- Gesto o botón **atrás** (Android): cierra la pantalla abierta; desde Personas o Mi informe vuelve a Explorar Mapa y, estando en Explorar Mapa, sale de la app.
- **Territorio** (número del 1 al 99) en cada lugar: se ve en la ficha y en el listado.
- **Buscador de Personas**: filtra solo por **nombre** o por **territorio** (no busca en notas ni en direcciones). Un número solo («33») filtra únicamente por territorio; también sirven «territorio 33» y combinaciones como «ana 33». Sin tildes ni mayúsculas.
- El mapa se gira con dos dedos; una brújula debajo del botón de ajustes lo vuelve al norte.
- Botón **Ir / Maps** que abre la aplicación de Google Maps con las coordenadas de destino.
- También se instala en el iPhone como app web, sin App Store ni costo (sección 7).
- Tecnología: HTML/CSS/JavaScript sin paso de compilación, [MapLibre GL JS](https://maplibre.org) y [Capacitor](https://capacitorjs.com) para generar el APK.

## 1. Probar en el navegador

Requiere Node.js 22 o superior.

```bash
npm install
npm run serve          # http://localhost:8080
```

La ubicación del dispositivo solo funciona en `localhost` o en sitios `https`. Para probar desde el celular sin generar el APK, publique la carpeta `www/` en cualquier hosting estático con HTTPS (por ejemplo GitHub Pages): también se instala como PWA (ver sección 7).

## 2. Generar el APK (gratis)

### Opción A: GitHub Actions (no requiere instalar nada)

1. Suba este proyecto a un repositorio de GitHub.
2. Configure la firma una única vez (ver sección 3).
3. Entre en **Actions → Compilar APK → Run workflow**.
4. Al terminar (unos 5 a 10 minutos), descargue **mi-servicio-apk** desde la sección *Artifacts* de la ejecución.
5. Copie el `.apk` al teléfono e instálelo (Android pedirá permitir instalaciones de este origen).

### Opción B: Android Studio

1. Instale Node.js 22+ y Android Studio (incluye JDK 21).
2. En la carpeta del proyecto: `npm install` y luego `npm run android:sync`.
3. `npm run android:open`, y en Android Studio: **Build → Build APK(s)**. También puede conectar el teléfono por USB y presionar **Run**.

Si la carpeta `android/` no existiera, `npx cap add android` la crea y `npm run android:sync` la ajusta (permisos de ubicación, íconos, versión y firma).

## 3. Firma y actualizaciones (importante para no perder datos)

Android solo permite actualizar una app si la nueva versión está firmada con **la misma clave**. Con una clave distinta hay que desinstalar la anterior, y **al desinstalar se borran los datos locales**. Por eso conviene firmar siempre con una clave propia:

1. Genere la clave una sola vez (el comando pide las contraseñas por pantalla):
   ```bash
   keytool -genkeypair -v -keystore miservicio.jks -alias miservicio -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Guarde `miservicio.jks` y sus contraseñas en su gestor de contraseñas. Si se pierden, no se pueden recuperar.
3. Convierta el archivo a texto: `base64 -w0 miservicio.jks` (Linux), `base64 -i miservicio.jks` (macOS) o, en PowerShell, `[Convert]::ToBase64String([IO.File]::ReadAllBytes("miservicio.jks"))`.
4. En GitHub: **Settings → Secrets and variables → Actions → New repository secret**, y cree estos cuatro secretos:

   | Secreto | Contenido |
   |---|---|
   | `ANDROID_KEYSTORE_BASE64` | El texto del paso 3 |
   | `ANDROID_KEYSTORE_PASSWORD` | Contraseña del almacén de claves |
   | `ANDROID_KEY_ALIAS` | `miservicio` |
   | `ANDROID_KEY_PASSWORD` | Contraseña de la clave |

Nunca suba el `.jks` ni las contraseñas al repositorio (el `.gitignore` ya excluye `*.jks`). Sin estos secretos el flujo compila un APK de depuración con clave temporal: sirve para probar, pero no se instala como actualización.

Para publicar una versión nueva, suba el número de `version` en `package.json` (el código de versión de Android se calcula solo) y vuelva a ejecutar el flujo.

### Firma automática sin secretos (flujo `apk.yml`, pensado para usar solo desde el teléfono)

El archivo `docs/apk.yml` es el flujo que se usa cuando el repositorio contiene solo `mi-servicio.zip` y `.github/workflows/apk.yml`: cada vez que se sube un zip nuevo (a cualquier carpeta del repositorio; se usa el más reciente) compila el APK y publica la web. Para que cada APK se instale **encima** del anterior sin borrar datos, guarda la clave de depuración en la caché de GitHub (no en el repositorio):

- La primera compilación crea la clave y la guarda; las siguientes la reutilizan y la ejecución lo indica («Firma del APK»). En los ejecutores de GitHub Android crea la clave en `~/.config/.android/debug.keystore` (no en `~/.android`); si algún día cambiara, el paso «Estado de la firma» avisa con «Firma del APK sin guardar».
- Si GitHub Pages no está activado, la web de iPhone no se publica y se deja un aviso amarillo; el APK no se ve afectado.
- Las compilaciones se ejecutan de a una (si se suben dos archivos seguidos, la segunda espera a la primera), para que ambas usen la misma clave.
- GitHub borra las cachés que pasan 7 días sin usarse. Una ejecución programada (cada 3 días, `mantener-firma`) la mantiene viva sin compilar nada. En repositorios públicos GitHub pausa las ejecuciones programadas tras 60 días sin actividad (se reactivan con el botón «Enable workflow» en la pestaña Actions; GitHub suele avisar por correo antes de pausarlas).
- Si la firma se pierde o se cambia el nombre de la clave (`mi-servicio-firma-v1`), el siguiente APK tendrá una firma nueva: **antes de desinstalar haga la copia de seguridad** (Ajustes → Exportar), instale el APK nuevo e importe la copia.
- Es una clave de depuración: sirve para actualizar la app en su teléfono, pero no para publicar en Google Play (para eso use la clave propia de arriba).

## 4. Mapas sin conexión

- Los mapas vienen de [OpenFreeMap](https://openfreemap.org) (gratuito, sin clave ni registro). Cada vez que se mira una zona con internet, las teselas quedan guardadas automáticamente en el teléfono.
- Para dejar una zona completa: **Ajustes → Mapas sin conexión**. Primero acerque el mapa a la zona, elija el nivel de detalle (Calles, Barrios o Región) y descargue. La pantalla muestra la estimación de teselas y tamaño antes de empezar.
- OpenFreeMap permite descargas manuales de hasta **3.000 teselas y 50 MB**, con 4 solicitudes simultáneas. La aplicación respeta esos límites; para cubrir una zona mayor, descárguela en varias partes.
- La atribución («OpenFreeMap © OpenMapTiles, datos de OpenStreetMap») debe permanecer visible en el mapa.
- Para usar otro proveedor de teselas con el esquema OpenMapTiles, cambie los valores de `MS.MAP` en `www/js/config.js`.

## 5. Datos y privacidad

- Todo se guarda en el teléfono (IndexedDB). La app usa internet para descargar mapas y, solo cuando usted lo pide, para dos cosas de «Agregar por dirección»:
  - **Dirección escrita**: se envía el texto de la dirección (y la zona aproximada del mapa, como pista) al servicio gratuito Nominatim de OpenStreetMap; nunca se envían nombres ni notas. Las coordenadas y los enlaces largos de Google Maps se leen en el teléfono, sin conexión. Los resultados son aproximados: conviene verificar el pin en el mapa antes de guardar.
  - **Enlace corto de Google Maps** (`maps.app.goo.gl`): solo en la APK de Android se abre el enlace para leer a dónde apunta, por lo que Google ve ese pedido. En la versión web (iPhone) no se lee: se ofrece abrir el enlace para copiar desde allí las coordenadas o el enlace largo.
  - Nominatim es un servicio compartido con una [política de uso](https://operations.osmfoundation.org/policies/nominatim/) estricta: como máximo 1 pedido por segundo, sin autocompletar, se guardan los resultados repetidos y se muestra la atribución. La app lo cumple, pero está pensada para un uso personal y liviano: para un uso intensivo cambie `MS.GEO.url` en `www/js/config.js` por un proveedor propio, o ponga `enabled: false` para desactivar la búsqueda de direcciones.
- Android no hace copias automáticas de los datos (`allowBackup` desactivado). Haga una copia manual en **Ajustes → Exportar copia de seguridad**, que genera un archivo `.json` para guardar o compartir. **Importar** admite combinar o reemplazar. Desde la versión 1.5 la copia incluye también **Mi informe** (horas, asignaciones aprobadas, metas y el redondeo elegido en cada informe); una copia anterior a Mi informe no toca las horas ya cargadas. Al actualizar desde la 1.4, las visitas de las personas que hoy están en etapa Estudio pasan a contar como estudios (se pueden destildar una por una desde «Editar nota»). Las copias hechas con versiones anteriores se importan sin problema (los lugares quedan sin territorio y las notas antiguas sin hora propia).
- La ubicación se usa solo para mostrar el punto en el mapa: no se envía a ningún servidor ni se guarda como registro. La app únicamente recuerda la última vista del mapa (centro y zoom) para retomarla al abrir.

## 6. Estructura

```
www/                  Aplicación web (index.html, css/, js/, fonts/, sprites/, icons/, sw.js)
resources/android/    Íconos y colores de arranque que se aplican al proyecto Android
scripts/              serve.mjs, gen-sw.mjs (caché PWA), patch-android.mjs, gen-android-icons.mjs
android/              Proyecto nativo generado por Capacitor
.github/workflows/    build-apk.yml (APK) y publicar-web.yml (sitio para iPhone)
docs/                 apk.yml: flujo combinado (APK + web) para usar solo desde el teléfono
licenses/             Licencias de componentes de terceros
```

Después de editar archivos de `www/`, ejecute `npm run android:sync` para copiarlos al proyecto Android (también regenera la lista de archivos del service worker).

## 7. iPhone (app web gratuita)

Apple no permite instalar un APK ni apps propias sin pasar por su programa de desarrollador, que es de pago. La alternativa sin costo es publicar `www/` como sitio web y agregarlo a la pantalla de inicio: se abre a pantalla completa, funciona sin conexión y guarda los datos en el teléfono, como en Android.

### Publicar el sitio (una sola vez)

1. En el repositorio de GitHub entre en **Settings → Pages** y, en **Source**, elija **GitHub Actions**.
2. Ejecute **Actions → Publicar web (iPhone y navegador) → Run workflow**. Desde entonces se vuelve a publicar solo con cada cambio en la rama `main`.
3. La dirección queda como `https://<usuario>.github.io/<repositorio>/` y figura en la ejecución terminada.

### Instalar en el iPhone

1. Abra la dirección en **Safari** (solo Safari instala la app).
2. Toque **Compartir** (si no lo ve, toque los tres puntos y luego **Compartir**) y elija **Agregar a pantalla de inicio**.
3. Si aparece **Abrir como app web** (iOS 26), déjelo activado. Toque **Agregar**.
4. Abra Mi Servicio siempre desde el ícono nuevo, permita la ubicación y descargue su zona en **Ajustes → Mapas sin conexión**.

### Diferencias con Android

- La app instalada guarda sus datos aparte de los de Safari. Para pasar datos entre equipos (por ejemplo desde Android) use **Exportar copia de seguridad** y **Importar copia de seguridad**. En el iPhone el archivo `.json` se envía con el menú Compartir (Guardar en Archivos, AirDrop, WhatsApp, correo).
- Safari borra los datos de los sitios web que no se usan durante 7 días, pero no los de las apps agregadas a la pantalla de inicio. Conviene exportar una copia de vez en cuando.
- **Ir / Maps** pregunta con qué aplicación abrir la ruta: Google Maps o Apple Maps.
- iOS puede volver a pedir el permiso de ubicación. Si el punto no aparece, revise los permisos en Ajustes del iPhone (Privacidad y seguridad) y toque de nuevo el botón de ubicación.
- El teclado del iPhone se superpone a la página; la app sube el formulario para que siga visible.
- La vibración puede no estar disponible en Safari.
- Para publicar una versión nueva, vuelva a ejecutar el flujo. La app instalada la descarga al abrirse con conexión y la muestra la siguiente vez que se abre.

## 8. Estado de verificación

- La aplicación se probó en un navegador móvil emulado (tema claro y oscuro, alta, historial, filtros, buscador, copias de seguridad, descarga de zonas y uso sin conexión) con teselas sintéticas, no con las de OpenFreeMap real.
- El giro del mapa se probó con gestos de dos dedos simulados (rotar, pellizcar para hacer zoom, tocar marcadores y el mapa estando girado), no con un teléfono real; en un teléfono el gesto empieza al torcer unos 25° para no confundirse con el zoom.
- El APK no pudo compilarse en el entorno de desarrollo por falta de acceso a los repositorios de Android; la compilación se realiza en GitHub Actions o Android Studio. Conviene probar en un teléfono real la ubicación, el botón **Ir / Maps** y la descarga de una zona pequeña.
- Las funciones de la versión 1.4 (botón de ubicación, órdenes, hora, ficha, compartir y «Agregar por dirección») se probaron en el navegador móvil emulado, en claro y oscuro y desde 320 px de ancho, con un servicio de direcciones simulado y una conexión nativa simulada para los enlaces cortos. No se probaron con un teléfono real: el menú Compartir del sistema, la lectura de enlaces cortos de Google Maps y una búsqueda real en Nominatim.
- Las funciones de la versión 1.5 (Mi informe, meta de 15/30/50/100 h, calendario, horas extras y estudios sincronizados con las fichas) se probaron en el navegador móvil emulado con el reloj fijado (viernes 27 de noviembre de 2026), en claro y oscuro; incluyen la copia de seguridad, la migración de visitas anteriores y el funcionamiento sin conexión. No se probaron en un teléfono real.
- Los cambios de la versión 1.5 sobre Personas y Ajustes (buscador por nombre o territorio, «No en casa» fuera de los órdenes, «Más visitadas», «Agregar por dirección» dentro de Ajustes, el envío del informe del mes y su redondeo de horas con arrastre al mes siguiente) se probaron en el mismo navegador móvil emulado, en claro y oscuro y desde 320 px de ancho; el menú de compartir se simuló, no se probó con WhatsApp real.
- La versión para iPhone se probó en Chromium con el agente de usuario de iPhone y funciones simuladas (menú Compartir, teclado, permiso de ubicación, instalación en pantalla de inicio, uso en una subcarpeta de GitHub Pages y sin conexión). No se pudo probar en Safari ni en un iPhone real: conviene verificar allí la instalación, la ubicación, el teclado y el uso sin conexión.

## Licencias y atribuciones

Teselas © [OpenFreeMap](https://openfreemap.org) / [OpenMapTiles](https://www.openmaptiles.org), datos © colaboradores de [OpenStreetMap](https://www.openstreetmap.org/copyright). Mapa dibujado con MapLibre GL JS (BSD-3-Clause). Estilo derivado de «Positron» (CARTO, BSD-3-Clause / CC-BY 3.0). Tipografías Atkinson Hyperlegible Next y Noto Sans (SIL OFL 1.1). Íconos Material Symbols (Apache 2.0). La búsqueda de direcciones usa Nominatim, de la Fundación OpenStreetMap, con datos © colaboradores de OpenStreetMap (ODbL). Los textos completos están en `licenses/`.
